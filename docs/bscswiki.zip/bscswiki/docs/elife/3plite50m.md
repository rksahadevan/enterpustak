## eLife 3P Lite – 50 Mbps – 12 Months contract

## CRM Package Structure

Package Code: MKTP3P50MBLITE

|    Components                                         |    Production RP    |    Amount           |    Comments                                                                                                                                                                                                                                                 |
|-------------------------------------------------------|---------------------|--------------------:|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|    Broadband 50 Mbps Speed                            |    RP645265         |    544              |    This component is added automatically while selecting the package, no   need to display in the screen for agent to select. If the screen is   displaying the charges for broadband separately, it should display the cost   of     RP645265+ RP636661    |
|    eLife Basic (HD TV Box)   installment discount)    |    RP636661         |    25               |    This component is added automatically at the backend, no need to   display in the screen for agent to select                                                                                                                                             |
|    eLife On                                           |    RP622732         |    30               |    This is given by default and cannot be removed                                                                                                                                                                                                           |
|    Wireless Phone                                     |    RP647057         |    10               |    RP647057- Should be selected by default:   Should have an option to choose from any of the below phones as well:   RPGIGAA220TRIO1   RPPANASONICPH1                                                                                                      |
|    Bundled Router                                     |    RPDLINK803R12    |    20               |    RPDLINK803R12- Should be selected by default:   Should have an option to choose from any of the below routers as well:   RPDLINK868R12                                                                                                                   |
|    Bundle Rental                                      |                     |    AED 599          |                                                                                                                                                                                                                                                             |


## BSCS Package Structure

|  			 			Plan 			Monthly Rental-eLife Lite with 50Mbps (01/05/15 – 31/05/15) 		 |  			 			  			 		                                        |                |
|---------------------------------------------------------------------|----------------------------------------------|----------------|
|  			 			                         			Components 		                              |  			 			                            			Amount  (AED) 		 |  			 			Description 		 |
|  			 			eLife - Lite 			- 50Mbps speed 		                                      |  			 			569 		                                       |  			 			HardCoded 		   |
|  			 			eLife main 			set top box 		                                           |  			 			40 		                                        |  			 			HardCoded 		   |
|  			 			Router Model 			Name 		                                                |  			 			xx 		                                        |  			 			SncodeDesc 		  |
|  			 			eLife On 		                                                         |  			 			30 		                                        |  			 			SncodeDesc 		  |
|  			 			Unlimited 			National Calls 		                                         |  			 			0 		                                         |  			 			HardCoded 		   |
|  			 			Wireless 			Phone 		                                                   |  			 			10 		                                        |  			 			SncodeDesc 		  |
|  			 			Total 			component Value 		                                            |  			 			649 		                                       |  			 			  			 		          |
|  			 			Bundle 			Rental 		                                                    |  			 			599 		                                       |  			 			  			 		          |

## StreamServ Presentation

|  			Offer 		          |  			Description 		                |  			TMCdoe 		 |  			SPCode 		 |  			SnCode 		                          |  			Clubbed SN 		             |  			PARAM 		        |
|------------------|------------------------------|----------|----------|-----------------------------------|--------------------------|----------------|
|  			MKTP3P50MBLITE 		 |  			eLife Lite - 50 Mbps speed 		 |  			RPEL3 		  |  			E3LSP 		  |  			WWC03  			 		                         |  			RPEL3->SPE3S->WWE02   			 		 |  			WWP03-> 50MB 		 |
|  			MKTP3P50MBLITE 		 |  			eLife main set top box 		     |  			RPEL3 		  |  			STESP 		  |  			XT058/XT057 		                     |  			  			 		                     |  			  			 		           |
|  			MKTP3P50MBLITE 		 |  			Router Model Name 		          |  			RPEL3 		  |  			STESP 		  |  			XT096/XT097/ 			XT101/XT103/ 			XT106 		 |  			  			 		                     |  			  			 		           |
|  			MKTP3P50MBLITE 		 |  			eLife On 		                   |  			RPEL3 		  |  			SPE3S 		  |  			WWE01 		                           |  			  			 		                     |  			  			 		           |
|  			MKTP3P50MBLITE 		 |  			Wireless Phone 		             |  			RPEL3 		  |  			SPE3S 		  |  			WWC04/ WWC06/ WWC05 		             |  			  			 		                     |  			  			 		           |

!!! notes "Key points of Invoice package structure"
    * SNCODEs/Rateplans clubbed together for presenting package structure.  CRM have separate rate plans that needs to be merged in invoice presentation purpose.

## Sample Invoice

!!! info "Sample Invoice"
    ![Sample Invoice](../img/invLite50MB.PNG)
