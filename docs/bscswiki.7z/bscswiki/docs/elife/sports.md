## Elife 3.0/Elife 4.0 Sports

## CRM Package Structure

Package Code: MKTP3P20MBSPORTS

|    Components                                       |    Production RP     |    Amount           |    Comments                                                                                                                                                                                                                                      |
|-----------------------------------------------------|----------------------|--------------------:|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|    Broadband   50 Mbps Speed                        |    RP636665          |    293              |    This   component is added automatically in the backend, no need to display in the   screen for agent to select.  If the   screen is displaying the charges for broadband separately, it should display   the cost of  RP636665 +  RP636662    |
|    eLife Basic (HD TV Box) installment discount)    |    RP636662          |    35               |    This   component is added automatically in the backend, no need to display in the   screen for agent to select                                                                                                                                |
|    Choice   Basic                                   |    RP564671          |    30               |    This   is given by default and cannot be removed                                                                                                                                                                                              |
|    eLife   On                                       |    RP622732          |    30               |    This is   given by default and cannot be removed                                                                                                                                                                                              |
|    beIN   Sports                                    |    RPBEINSPORTS90    |    90               |    This   is given by default and cannot be removed                                                                                                                                                                                              |
|    eLife TV - SPORTS - Abu Dhabi SPORTS             |    RP636656          |    14               |    This   is given by default and cannot be removed                                                                                                                                                                                              |
|    Extreme   Sports                                 |    RPEXTREMSPORT     |    7                |    This   is given by default and cannot be removed                                                                                                                                                                                              |
|    eLife   main set top box                         |    RP636539          |    30               |    This   should be the default recorder STB                                                                                                                                                                                                     |
|    Wireless   Phone                                 |    RP636658          |    5                |    RP636658 - Should be selected by default:   Should   have an option to choose from any of the below phones as well:   RPGIGAA220TRIO2   RPPANASONICPH2                                                                                      |
|    Bundled   Router                                 |    RPDLINK803R24     |    10               |    RPDLINK803R24 - Should be selected by default:   Should   have an option to choose from any of the below routers as well:   RP24LINKSYS8500   RPDLINK868R24                                                                                  |
|    Bundle   Rental                                  |                      |    AED 499          |                                                                                                                                                                                                                                                  |

## BSCS Package Structure

|  			Plan 			Monthly Rental-eLife sports with 50Mbps (01/05/15 – 31/05/15) 		 |  			  			 		                                        |               |
|----------------------------------------------------------------------|---------------------------------------------|---------------|
|  			                         			Components 		                                |  			                            			Amount  (AED) 		 |  			Description 		 |
|  			Broadband 			50 Mbps Speed 		                                            |  			340 		                                       |  			Hardcode 		    |
|  			eLife 			main set top box Recorder 		                                    |  			30 		                                        |  			Hardcode 		    |
|  			Router 			Model Name 		                                                  |  			Xx 		                                        |  			Legend 			Desc 		 |
|  			Bein 			Sports               			 			 		                                        |  			78 		                                        |  			Legend 			Desc 		 |
|  			AD 			Sports 		                                                          |  			14 		                                        |  			Legend 			Desc 		 |
|  			Choice 			Basic 		                                                       |  			30 		                                        |  			Legend 			Desc 		 |
|  			ExtremeSport 		                                                       |  			7 		                                         |  			Legend 			Desc 		 |
|  			eLife 			On 		                                                           |  			30 		                                        |  			Legend 			Desc 		 |
|  			Unlimited 			National Calls 		                                           |  			0 		                                         |  			Legend 			Desc 		 |
|  			Wireless 			Phone 		                                                     |  			5 		                                         |  			Legend 			Desc 		 |
|  			Total 			component Value 		                                              |  			534 		                                       |  			  			 		          |
|  			Bundle 			Rental 		                                                      |  			499 		                                       |  			  			 		          |

## StreamServ Presentation

|  			Description 		                     |  			TMCdoe 		 |  			SPCode 		 |  			Primary SnCode 		                                                            |  			Clubbed SNCode 		                                                                             |
|-----------------------------------|----------|----------|-----------------------------------------------------------------------------|----------------------------------------------------------------------------------------------|
|  			Broadband 50 Mbps Speed 		         |  			RPEL3 		  |  			E3SSP 		  |  			WWC02 		                                                                     |  			RPEL3->SPE3S-> WWE04 		                                                                       |
|  			eLife main set top box Recorder 		 |  			RPEL3 		  |  			SPE3S 		  |  			ELMST 		                                                                     |  			RPEL3->STESP->ST001 			RPEL3->STESP->ST002 			  			 		                                                 |
|  			Router Model Name 		               |  			RPEL3 		  |  			STESP 		  |  			XT096/XT097/ST101/ST102/XT103 			ST114/XT101/ST110/ST130 			XT106/ 		              |  			  			 		                                                                                         |
|  			Bein Sports               		       |  			RPEL3 		  |  			SPE3S 		  |  			WWE14 		                                                                     |  			  			 		                                                                                         |
|  			AD Sports 		                       |  			RPEL3 		  |  			SPE3S 		  |  			WWE07 		                                                                     |  			  			 		                                                                                         |
|  			Choice Basic 		                    |  			RPEL3 		  |  			EL3TV 		  |  			TVC75,TVC74,TVC73,TVC72, 			TV144,TV143,TV142,TV141, 			TV140,TV139,TV138,TV137 		 |  			PL/SQL procedure to return 1st active 			TV service. If 1st one is ceased take the next one.  			 		 |
|  			Extreme Sport 		                   |  			RPEL3 		  |  			EL3TV 		  |  			WWE13 		                                                                     |  			  			 		                                                                                         |
|  			eLife On 		                        |  			RPEL3 		  |  			SPE3S 		  |  			WWE01 		                                                                     |  			  			 		                                                                                         |
|  			Wireless Phone 		                  |  			RPEL3 		  |  			SPE3S 		  |  			WWC01/ WWC07/ WWC08 		                                                       |  			  			 		                                                                                         |

!!! note "Key points of Invoice package structure"
    * Sncodes/Rateplans clubbed together for presenting package structure. CRM have separate rate plans that needs to be merged for invoice presentation purpose.
    Broadband 50 Mbps Speed  = Total Amount = WWC02 + WWE04
    * Customer can subscribe ‘n’ number of choice basics and first choice basic needs to be treated as part of the package. Stream server is calling a procedure EMCESU.CONTR_TVPACK to identify Ist active TV service

!!! note "Discounts need to remove from package Structure"
    * Remove below discounts from Total Component Value

    (E3C2R OR E3N2R OR E3N3R OR E3C2I OR E3N2I OR E3N3I) +
    EL3WP/GSD50R24M/ PAN25R24M/LTRTR24/LTRTR12/LSEA850024M/
    DLINK868B24M/DL803805E24M/LSYSE850024M/DLINK850B24M/
    LSYSE850012M/DLINK868B12M/DLINK850B12M/ROUTER12/ROUTER24

## Sample Invoice

!!! info "Sample Invoice"
    ![Sample Invoice](../img/invSports.PNG)
