## eLife 4.0 Entertainment

## CRM Package Structure

Package Code: MKTP3P20MBMOVIES

|    Components                                         |    Production RP    |    Amount           |    Comments                                                                                                                                                                                                                                              |
|-------------------------------------------------------|---------------------|--------------------:|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|    Broadband 50 Mbps Speed                            |    RP636664         |    255              |    This component is added automatically while selecting the package, no   need to display in the screen for agent to select. If the screen is   displaying the charges for broadband separately, it should display the cost   of  RP636664+ RP636662    |
|    eLife Basic (HD TV Box)   installment discount)    |    RP636662         |    35               |    This component is added automatically at the backend, no need to   display in the screen for agent to select                                                                                                                                          |
|    Choice   Basic                                     |    RP564671         |    30               |    This is given by default and cannot be removed                                                                                                                                                                                                        |
|    Video Pack                                         |    RP599609         |    39               |    This is given by default and cannot be removed                                                                                                                                                                                                        |
|    eLife On                                           |    RP622732         |    30               |    This is given by default and cannot be removed                                                                                                                                                                                                        |
|    Starzplay                                          |    RPSTARZPLAY      |    20               |    This is given by default and cannot be removed                                                                                                                                                                                                        |
|    Premium Video Pack                                 |    RPPREMVDPACKS    |    10               |    This is given by default and cannot be removed                                                                                                                                                                                                        |
|    eLife TV - OSN - Premium movies                    |    RP636696         |    150              |    This is given by default and cannot be removed                                                                                                                                                                                                        |
|    eLife main set top box                             |    RP636539         |    30               |    This should be the default recorder STB for eLife                                                                                                                                                                                                     |
|    Wireless Phone                                     |    RP636658         |    5                |    RP636658 - Should be selected by default:   Should have an option to choose from any of the below phones as well:   RPGIGAA220TRIO2   RPPANASONICPH2                                                                                                  |
|    Bundled Router                                     |    RPDLINK803R24    |    10               |    RPDLINK803R24- Should be selected by default:   Should have an option to choose from any of the below routers as well:   RP24LINKSYS8500   RPDLINK868R24                                                                                              |
|    Bundle Rental                                      |                     |    AED 569          |                                                                                                                                                                                                                                                          |

## BSCS Package Structure

|  			Plan 			Monthly Rental-eLife Movies with 50Mbps (01/05/15 – 31/05/15) 		 |                                             |                      |
|----------------------------------------------------------------------|---------------------------------------------|----------------------|
|  			                         			Components 		                                |  			                            			Amount  (AED) 		 |  			Description 		        |
|  			Broadband 			50 Mbps Speed 		                                            |  			290 		                                       |  			Hardcode 		           |
|  			eLife 			main set top box Recorder 		                                    |  			30 		                                        |  			Hardcode 		           |
|  			Router 			Model Name 		                                                  |  			Xx 		                                        |  			Legend 			description 		 |
|  			Choice 			Basic 		                                                       |  			30 		                                        |  			Legend 			description 		 |
|  			eLife 			TV - OSN - Premium movies 		                                    |  			150 		                                       |  			Legend 			description 		 |
|  			elife 			TV - Video Packs  			 		                                           |  			39 		                                        |  			Legend 			description 		 |
|  			Starz 			Play 		                                                         |  			20 		                                        |  			Legend 			description 		 |
|  			Premium 			Video Packs 		                                                |  			10 		                                        |  			Legend 			description 		 |
|  			eLife 			On  			 		                                                         |  			30 		                                        |  			Legend 			description 		 |
|  			Unlimited 			National Calls 		                                           |  			0 		                                         |  			Legend 			description 		 |
|  			Wireless 			Phone 		                                                     |  			5 		                                         |  			Legend 			description 		 |
|  			Total 			component Value 		                                              |  			634 		                                       |  			  			 		                 |
|  			Bundle 			Rental 		                                                      |  			569 		                                       |  			  			 		                 |

## StreamServ Presentation

|  			Description 		                     |  			TMCdoe 		 |  			SPCode 		 |  			Primary SnCode 		                                                            |  			Clubbed SNCode 		                                                                              |
|-----------------------------------|----------|----------|-----------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------|
|  			Broadband 50 Mbps Speed 		         |  			RPEL3 		  |  			E3MSP 		  |  			WWC02 		                                                                     |  			RPEL3->SPE3S-> WWE04 		                                                                        |
|  			eLife main set top box Recorder 		 |  			RPEL3 		  |  			SPE3S 		  |  			ELMST 		                                                                     |  			RPEL3->STESP->ST001 			RPEL3->STESP->ST002 			  			 		                                                  |
|  			Router Model Name 		               |  			RPEL3 		  |  			STESP 		  |  			XT096/XT097/ST101/ST102/XT103 			ST114/XT101/ST110/ST130 			XT106/ 		              |  			  			 		                                                                                          |
|  			Choice Basic 		                    |  			RPEL3 		  |  			EL3TV 		  |  			TVC75,TVC74,TVC73,TVC72, 			TV144,TV143,TV142,TV141, 			TV140,TV139,TV138,TV137 		 |  			PLSQL procedure to return I’st active TV 			service. If Ist one is Ceased take the next one.  			 		 |
|  			eLife TV - OSN - Premium movies 		 |  			RPEL3 		  |  			SPE3S 		  |  			WWE05 		                                                                     |  			  			 		                                                                                          |
|  			elife TV - Video Packs 		          |  			RPEL3 		  |  			SPE3S 		  |  			WWE03 		                                                                     |  			  			 		                                                                                          |
|  			Startz Play 		                     |  			RPEL3 		  |  			EL3TV 		  |  			WWE11 		                                                                     |  			  			 		                                                                                          |
|  			Premium Video Packs 		             |  			RPEL3 		  |  			EL3TV 		  |  			WWE12 		                                                                     |  			  			 		                                                                                          |
|  			eLife On 		                        |  			RPEL3 		  |  			SPE3S 		  |  			WWE01 		                                                                     |  			  			 		                                                                                          |
|  			Wireless Phone 		                  |  			RPEL3 		  |  			SPE3S 		  |  			WWC01/ WWC07/ WWC08 		                                                       |  			  			 		                                                                                          |

!!! note "Key points of Invoice package structure"
    * Sncodes/Rateplans clubbed together for presenting package structure. CRM have separate rate plans that needs to be merged for invoice presentation purpose.
    Broadband 50 Mbps Speed  = Total Amount= WWC02+ WWE04
    * Customer can subscribe ‘n’ number of choice basics and first choice basic needs to be treated as part of the package. Stream server is calling a procedure EMCESU.CONTR_TVPACK to identify Ist active TV service

!!! note "Discounts need to remove from package Structure"
    * Remove below discounts from Total Component Value

    (E3C2R OR E3N2R OR E3N3R OR E3C2I OR E3N2I OR E3N3I) + EL3WP/GSD50R24M/ PAN25R24M/LTRTR24/LTRTR12/LSEA850024M/DLINK868B24M/DL803805E24M/LSYSE850024M/DLINK850B24M/
    LSYSE850012M/DLINK868B12M/DLINK850B12M/ROUTER12/ROUTER24

## Sample Invoice

!!! info "Sample Invoice"
    ![Sample Invoice](../img/invEntertainment.PNG)
