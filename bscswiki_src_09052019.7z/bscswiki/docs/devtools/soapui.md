# SoapUI

SoapUI is a tool for testing Web Services; these can be the SOAP Web Services as well RESTful Web Services or HTTP based services. SoapUI is an Open Source and completely free tool.

SoapUI comes with support for testing WSDL / SOAP based services.

To see different input sample for Unified Bill Inquiry interfaces, see [SoapUI Sample formats](../../unified/apiusage#soap-ui)

## Sample screenshots

!!! info "SoapUI sample for Unified Bill Inquiry"
    ![SoapUI](soapui.PNG)
