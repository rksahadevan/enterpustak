API testing involves testing APIs directly (in isolation) and as part of the end-to-end transactions exercised during integration testing. Beyond RESTful APIs, these transactions include multiple types of endpoints such as web services, ESBs, databases, mainframes, web UIs, and ERPs. API testing is performed on APIs that the development team produces.

API testing is used to determine whether APIs return the correct response (in the expected format) for a broad range of feasible requests, react properly to edge cases such as failures and unexpected/extreme inputs, deliver responses in an acceptable amount of time.

API testing commonly includes testing REST APIs or SOAP web services with JSON or XML message payloads being sent over HTTP, HTTPS, JMS, and MQ.

Postman is a great tool for prototyping APIs, and it also has some powerful testing features. To see different input sample for interfaces, see [POSTMAN Sample formats](../../unified/apiusage#postman)

To download Postman, go to https://www.getpostman.com/

!!! tips "Steps for doing API Testing using POSTMAN"
    Step 1: Open POSTMAN tool and log in with your credentials.<br>
    Step 2: Get the Request URL(Uniform Resource Locator) of the API.<br>
    Step 3: Paste that URL into the URL space given in the POSTMAN.<br>
    Step 4: Select the Method which you want to perform, For example GET,PUT,POST,DELETE.<br>
            (Note: The endpoint of the URL would be different for different Methods).<br>

    Step 5: Put the Headers with Key and Value field.<br>
    Step 6: Put the body part and select raw option, incase you are using any POST/DELETE Method.<br>
    Step 7: Recheck the given URL and click on send button and observe the response in JSON format.

!!! info "Sample screenshot"
    ![Postman](postman.PNG)
