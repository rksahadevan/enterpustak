Promotions are used to apply certain benefits to customers.  It can be applied on invoice charges like One time charges, Rental charges, Usages etc.  To apply any promotion in BSCS, corresponding promotion package need to be activated for the customer.  These promotion activation/deactivation controlling by CRM according to business requirements.  

## How to activate?

Promotions can be activated/deactivated using following methods:

* Activate/deactivate promotion for Packages if subscribed with a discounted rate plan in CRM
* Activate/deactivate promotion for add-on rate plans
* Activate/deactivate promotion for for a service based on an indicator rate plan subscription in CRM

## Promotion application

Rules for applying discounts are configured in BSCS.  This contains the selection criteria for eligibility, and and application mechanism to apply discount on different type of transactions in the invoice.

Discounts can be applied as below in BSCS:

* Tiered discount
* Scaled discount
* Absolute discount
* Relative discount
