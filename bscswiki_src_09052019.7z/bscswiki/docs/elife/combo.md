## eLife 4.0 Sports and Movies (Combo)

## CRM Package Structure

Package Code: MKTP3P20MBCOMBO

|    Components                                         |    Production RP     |    Amount      |    Comments                                                                                                                                                                                      |
|-------------------------------------------------------|----------------------|---------------:|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|    Broadband 50 Mbps Speed                            |    RP636697          |    274         |    This component is added automatically while selecting the packageIf   the screen is displaying the charges for broadband separately, it should   display the cost of  RP636697+   RP636662    |
|    eLife Basic (HD TV Box)   installment discount)    |    RP636662          |    35          |    This component is added automatically at the backend and agent cannot   select                                                                                                                |
|    Choice   Basic                                     |    RP564671          |    30          |    This is given by default and cannot be removed                                                                                                                                                |
|    Video Pack                                         |    RP599609          |    39          |    This is given by default and cannot be removed                                                                                                                                                |
|    eLife On                                           |    RP622732          |    30          |    This is given by default and cannot be removed                                                                                                                                                |
|    Starzplay                                          |    RPSTARZPLAY       |    20          |    This is given by default and cannot be removed                                                                                                                                                |
|    Premium Video Pack                                 |    RPPREMVDPACKS     |    10          |    This is given by default and cannot be removed                                                                                                                                                |
|    eLife TV - OSN - Premium movies                    |    RP636696          |    150         |    This is given by default and cannot be removed                                                                                                                                                |
|    beIN Sports                                        |    RPBEINSPORTS90    |    90          |    This is given by default and cannot be removed                                                                                                                                                |
|    eLife TV - SPORTS - Abu Dhabi   SPORTS             |    RP636656          |    14          |    This is given by default and cannot be removed                                                                                                                                                |
|    Extreme Sports                                     |    RPEXTREMSPORT     |    7           |    This is given by default and cannot be removed                                                                                                                                                |
|    eLife main set top box                             |    RP636539          |    30          |    This should be the default recorder STB for eLife                                                                                                                                             |
|    Wireless Phone                                     |    RP636658          |    5           |    RP636658 - Should be selected by default:Should have an option to   choose from any of the below phones as well:RPGIGAA220TRIO2,RPPANASONICPH2                                                |
|    Bundled Router                                     |    RPDLINK803R24     |    10          |    RPDLINK803R24- Should be selected by default: Should have an option to   choose from any of the below routers as well:RP24LINKSYS8500,RPDLINK868R24                                           |
|    Bundle Rental                                      |                      |    AED 699     |                                                                                                                                                                                                  |

## BSCS Package Structure

|  			 			Plan 			Monthly Rental-eLife Sports and Movies 50Mbps (01/05/15 – 			31/05/15) 		 |                                              |                |
|-----------------------------------------------------------------------------|----------------------------------------------|----------------|
|  			 			Components 		                                                               |  			 			                            			Amount  (AED) 		 |  			 			Description 		 |
|  			 			Broadband 50 			Mbps Speed 		                                                  |  			 			321 		                                       |  			 			Hardcode 		    |
|  			 			eLife setup 			box recorder 		                                                 |  			 			30 		                                        |  			 			Hardcode 		    |
|  			 			Router Model 			Name 		                                                        |  			 			xx 		                                        |  			 			SncodeDesc 		  |
|  			 			Bein 			Sports               			 			 		                                              |  			 			78 		                                        |  			 			SncodeDesc 		  |
|  			 			AD Sports 		                                                                |  			 			14 		                                        |  			 			SncodeDesc 		  |
|  			 			Choice Basic 		                                                             |  			 			30 		                                        |  			 			SncodeDesc 		  |
|  			 			eLifeTV 			OSNPremium  			 		                                                     |  			 			150 		                                       |  			 			SncodeDesc 		  |
|  			 			elife TV - 			Video Packs 		                                                   |  			 			39 		                                        |  			 			SncodeDesc 		  |
|  			 			Startz Play 		                                                              |  			 			20 		                                        |  			 			SncodeDesc 		  |
|  			 			Premium Video 			Packs 		                                                      |  			 			10 		                                        |  			 			SncodeDesc 		  |
|  			 			Extreme Sport 		                                                            |  			 			7 		                                         |  			 			SncodeDesc 		  |
|  			 			eLife On 		                                                                 |  			 			30 		                                        |  			 			SncodeDesc 		  |
|  			 			Unlimited 			National Calls 		                                                 |  			 			0 		                                         |  			 			HardCoded 		   |
|  			 			Wireless 			Phone 		                                                           |  			 			5 		                                         |  			 			SncodeDesc 		  |
|  			 			Total 			component Value 		                                                    |  			 			734 		                                       |  			 			  			 		          |
|  			 			Bundle 			Rental 		                                                            |  			 			699 		                                       |  			 			  			 		          |

## StreamServ Presentation

|  			Description 		                     |  			TMCdoe 		 |  			SPCode 		 |  			Primary SnCode 		                                                            |  			Clubbed SNCode 		                                                                              |
|-----------------------------------|----------|----------|-----------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------|
|  			Broadband 50 Mbps Speed 		         |  			RPEL3 		  |  			E3CSP 		  |  			WWC02 		                                                                     |  			RPEL3->SPE3S-> WWE04 		                                                                        |
|  			eLife main set top box Recorder 		 |  			RPEL3 		  |  			SPE3S 		  |  			ELMST 		                                                                     |  			RPEL3->STESP->ST001 			RPEL3->STESP->ST002 			  			 		                                                  |
|  			Router Model Name 		               |  			RPEL3 		  |  			STESP 		  |  			XT096/XT097/ST101/ST102/XT103 			ST114/XT101/ST110/ST130 			XT106/ 		              |  			  			 		                                                                                          |
|  			Bein Sports               		       |  			RPEL3 		  |  			SPE3S 		  |  			WWE14 		                                                                     |  			  			 		                                                                                          |
|  			AD Sports 		                       |  			RPEL3 		  |  			SPE3S 		  |  			WWE07 		                                                                     |  			  			 		                                                                                          |
|  			Choice Basic 		                    |  			RPEL3 		  |  			EL3TV 		  |  			TVC75,TVC74,TVC73,TVC72, 			TV144,TV143,TV142,TV141, 			TV140,TV139,TV138,TV137 		 |  			PLSQL procedure to return I’st active TV 			service. If Ist one is Ceased take the next one.  			 		 |
|  			eLife TV - OSN - Premium movies 		 |  			RPEL3 		  |  			SPE3S 		  |  			WWE05 		                                                                     |  			  			 		                                                                                          |
|  			elife TV - Video Packs 		          |  			RPEL3 		  |  			SPE3S 		  |  			WWE03 		                                                                     |  			  			 		                                                                                          |
|  			Startz Play 		                     |  			RPEL3 		  |  			EL3TV 		  |  			WWE11 		                                                                     |  			  			 		                                                                                          |
|  			Premium VideoPacks 		              |  			RPEL3 		  |  			EL3TV 		  |  			WWE12 		                                                                     |  			  			 		                                                                                          |
|  			ExtremSports 		                    |  			RPEL3 		  |  			EL3TV 		  |  			WWE13 		                                                                     |  			  			 		                                                                                          |
|  			eLife On 		                        |  			RPEL3 		  |  			SPE3S 		  |  			WWE01 		                                                                     |  			  			 		                                                                                          |
|  			Wireless Phone 		                  |  			RPEL3 		  |  			SPE3S 		  |  			WWC01/ WWC07/ WWC08 		                                                       |  			  			 		                                                                                          |

!!! note "Key points of Invoice package structure"
    * SNCODEs/Rateplans clubbed together for presenting package structure.  CRM have separate rate plans that needs to be merged in invoice presentation purpose.

!!! note "Discounts need to remove from package Structure"
    * Remove below discounts from Total Component Value

    (E3C2R OR E3N2R OR E3N3R OR E3C2I OR E3N2I OR E3N3I) +
    EL3WP/GSD50R24M/PAN25R24M/LTRTR24/LTRTR12/LSEA850024M/DLINK868B24M/
    DL803805E24M/LSYSE850024M/DLINK850B24M/
    LSYSE850012M/DLINK868B12M/DLINK850B12M/ROUTER12/ROUTER24

## Sample Invoice

!!! info "Sample Invoice"
    ![Sample Invoice](../img/invCombo.PNG)
