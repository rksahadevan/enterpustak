# Unified Inquiry Procedure Interface specification

Detailed specification for each of the interfaces listed below. Definition for the common attributes also provided for the understanding.

### Procedure: HEADER_INFO

Input Parameters:

|    Argument   Name      | Description                                                                                                                                                                                                                                         |
|-------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|    p_Account_ID         | Refers to CBCM Account ID. <br>For BIAB product, it has to be in the format AccountID-AccountNumber                                                                                                                                                                                                                                                     |
|    p_InvoiceNumber      | This is optional, refer to invoice number without any prefix values                                                                                                                                                                                                                                                    |
|    p_BillDate           | Invoice month in "MMYYYY" format. If no values passed or current month month, it Will be considered as unbilled inquiry   |
|    p_DetailsFLag        |                                                                                                                                                                                                                                                     |
|    p_CallDetailsFlag    |                                                                                                                                                                                                                                                     |
|    p_requestSytem       | Indicates the client system who requested the information.  Eg: CIM, DIGITALAPP, DIWAN                                                                                                                                                                                                                                                     |
|    p_parameter          | Additional instruction to the procedure for a special action. Eg: reqAttribute                                                                                                                                                                                                                                      |
|    p_parameter_value    | White listed Parameter Values<br>a) lastPayment <br>b) deliveryMode <br>c) INVOICE_HISTORY <br>d) OPEN_INV_COUNT (Applicable only for Unbilled Inquiry)<br>e) AmountOnly (Applicable for Details Info)    |

Output Parameters:

| Argument Name | Description |
|--------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| BilledAmnt | This refers to the Payable Amount in CBCM. <br>BSCS Ref: ORDERHDR_ALL.OHINVAMT_DOC<br><br>**Unbilled Inquiry:-** the billed amount for the previous month without any carry forward from earlier months. <br><br>**Billed Inquiry:-** the billed amount for the billed month without any carry forward from earlier months |
| TotalBilledAmntDue | This refers to the Closing balance of CBCM. <br>**Unbilled Inquiry:-** the billed amount for the previous month with any carry forward from earlier months. BSCS Ref: CUSTOMER_ALL.PREV_BALANCE. <br><br>**Billed Inquiry:-** the billed amount for the billed month with any carry forward from earlier months and will be available from the history table CUSTOMER_ALL_HISTORY which is maintained in ODS |
| TotalAmountDue | This refers to the Outstanding balance of CBCM. <br>Previous Month Billed Amount Due + payment done to date + Adjustment/Discount to date. <br>This referes to CUSTOMER_ALL.CSCURBALANCE and definition is same for both Billed and Unbilled.  |
| Due_Date | Refers to Pay By Date for the invoice |
| AsOfNowAmountDue | This refers to ASOFNOW balance of CBCM. Total Amount Due + Unbilled usage +Unbilled Onetime Transactions |
| AccountName | Account name in the invoice |
| InvoiceNumber | Invoice number along with INV or ZB prefix |
| AccountId | Refers to CBCM Account ID |
| AccountStatus | This refers to status of CBCM Account ID in BSCS.  Only 2 status avaialble in BSCS - Active or Deactive |
| InvoiceDate | Refers to Invoice generation date  |
| BilFromDate | Refers to Billing cycle start date |
| BilToDate | Refers to Billing cycle end date |
| DeliveryId | Refers to CBCM Delivery Id |
| LastPaymentDate | Date of last payment by the customer |
| LastPaymentAmt | Last amount paid by the customer |
| Open_Amount | Open Amount of the specific Invoice |
| OpenInvCount | Total open invoices count for the customer; applicable only for Unbilled Inquiry |

### Procedure: SUMMARY_INFO

Input Parameters:

|    Argument   Name      | Description                                                                                                    |
|-------------------------|----------------------------------------------------------------------------------------------------------------|
|    p_Account_ID         | CBCM Account ID. <br>For BIAB product, it has to be in the format AccountID-AccountNumber                                                                                                               |
|    p_InvoiceNumber      | This is optional, refer to invoice number without any prefix values                                                                                                               |
|    p_BillDate           | Invoice month in "MMYYYY" format. Will be considered as unbilled inquiry if no values passed or current month month                                                                                                       |
|    p_DetailsFLag        |                                                                                                                |
|    p_CallDetailsFlag    |                                                                                                                |
|    p_requestSytem       |                                                                                                                |
|    p_parameter          | Specific instruction to the procedure for providing a different output than standard ones                      |
|    p_parameter_value    | Specific instruction to the procedure for providing a different output than standard ones |

Output parameters:

|    Argument   Name          | Description                                                                                    |
|-----------------------------| -----------------------------------------------------------------------------------------------|
|    Invoice_Number           | Invoice number along with INV or ZB prefix                                                     |
|    Invoice_date             | Invoice Generation date                                                                        |
|    OpeningBalance           | **Unbilled Inquiry:-** the billed amount for the previous month with any carry forward from earlier months. BSCS Ref: CUSTOMER_ALL.PREV_BALANCE. <br><br>**Billed Inquiry:-** Opening balance in the Invoice, and will be fetched from the history table CUSTOMER_ALL_HISTORY which is maintained in ODS |
|    TotalUsageAmount         | Total usage amount                                                                             |
|    TotalRentalAmount        | Total rental amount including package and addon rentals                                        |
|    PlanRentalAmount         | Total package Rental in the invoice; this will be after discount                             |
|    AddonRentalAmount        | Total add-on Rental in the invoice                             |
|    PlanDiscountAmount       | Total discount for the package.                            |
|    TotalOneTimeCharges      | Total one time charges in the invoice                                                                                                |
|    TotalDiscountAmount      | Total discount charges in the invoice                                                          |
|    TotalPaymentAmount       | Total payment charges in the invoice                                                                                                |
|    TotalAdjustmnetAmount    | Total adjustment amount in the invoice                                                  |
|    TotalTaxAmount           | Total VAT amount for all charges in the bill                                                   |

### Procedure: DETAILS INFO

Input Parameters:

|    Argument   Name      | Description    |
|-------------------------|----------------|
|    p_Account_ID         | CBCM Account ID. <br>For BIAB product, it has to be in the format AccountID-AccountNumber               |
|    p_InvoiceNumber      | This is optional, refer to invoice number without any prefix values               |
|    p_BillDate           | Invoice month in "MMYYYY" format. It will be considered as unbilled inquiry in case no values passed OR current month month passed  |
|    p_DetailsFLag        |                |
|    p_CallDetailsFlag    |                |
|    p_requestSytem       |                |
|    p_parameter          | Additional instruction to the procedure for a special action. Eg: USAGEFORMAT    |
|    p_parameter_value    | Additional instruction to the procedure for a special action. Eg: AMOUNTONLY     |

Output parameters:

Main Object:

|    Argument   Name                      |    Description                                                                             |
|-----------------------------------------|--------------------------------------------------------------------------------------------|
|    ACCOUNT_ID                           |  Requested CBCM Account ID                                                                 |
|    INVOICE_NUMBER                       |  Invoice Number                                                                            |
|    CUSTOMER_ID_LIST                     |  List of BSCS Customer IDs linked with requested CBCM Account ID                           |
|    ACCTTRANSACTIONLISTDETAILS           |  Transactions List for Recurring/One Time/Adjustment/Discount/Payment                      |
|    ACCTUSGSUMRYLISTDETAILS              |  Transactions List for Usage summary                                                       |

List Objects:

|    Argument   Name                      |    Description                                                                          |
|-----------------------------------------|-----------------------------------------------------------------------------------------|
|    *ACCTTRANSACTIONLISTDETAILS:-*       |                                                                                         |
|    SERVICEDESC                          | Service description in the invoice                                                      |
|    SERVICECODE                          | BSCS Service SHDES                                                                      |
|    FROMDATE                             | Transaction From Date. For “ONETIME” transactions this is same as Transaction Date      |
|    TODATE                               | This is applicable only for recurring transactions and refers to end date for recurring charges                                      |
|    TRANSACTION_TYPE                     | Refers to type of transaction.  Below are the values:<br>* PAYMENT<br>* RECURRING<br>* ONETIME<br>* IMMEDIATE<br>* ONEOFF<br>* DISCOUNT<br>* TAX                     |
|    TRANSACTION_DATE                     | Effective date for the transaction                                                                         |
|    PACKAGEIDDESC                        | DISCOUNT   PACK                                                                         |
|    TRANSACTIONMODE                      | Refers to below values according to transaction types:<br>* PAYMENTMODE for Payment Transactions<br>* PLAN/ADDON for Recurring transaction<br>* Promo Pack ID for Promotions                                                            |
|    TAXAPPLIEDCHARGE                     | TAX APPLIED CHARGE                                                                      |
|    AMOUNT                               | AMOUNT                                                                                  |
|    REMARKS                              | Additional information                                                                          |
|                                         |                                                                                         |
|    *ACCTUSGSUMRYLISTDETAILS:-*          |                                                                                         |
|    MAINGROUP_NAME                       | Usage Main group. Eg: National calls and Usages, International Calls and Usages                                                                                        |
|    SUBGROUP_NAME                        | Usage Sub group. Eg: Calls to Telephone, IDD Calls                                                                                        |
|    DESCRIPTION                          | Usage sub group description                                                             |
|    AMOUNT                               | Usage Amount                                                                            |
|    CHARGEDUNITS                         | Total number of usage records                                                           |
|    CHARGEDTYPE                          | Total duration or volume                                                                |
|    REMARKS                              | Additional information                                                                  |
|                                         |                                                                                         |

### Procedure: FUP_INFO

Input parameters:

|    Argument   Name      | Description    |
|-------------------------|----------------|
|    p_Account_ID         | Valid CBCM Account ID. For BIAB, it has to be in the format AccountID-AccountNumber               |
|    p_BillDate           | Optional.  This is not relevant for this inquiry as result will be always for current month       |
|    p_Fup_Shdes          |                |
|    p_DetailsFLag        |                |
|    p_CallDetailsFlag    |                |
|    p_requestSytem       |                |
|    p_parameter          |                |
|    p_parameter_value    |                |

Output parameters:

|    Argument   Name         | Description                                  |
|----------------------------|----------------------------------------------|
|    AcctPackLevelDetails    |                                              |
|    Package_Name            | Free unit Pack Name.    Example “IDD”        |
|    FreeUnits               | Subscribed   Free units in Minutes.          |
|    Consumed_Units          | Consumed   Free units in Minutes             |
|    LeftOutUnits            | Left   out free unit in Minutes.             |

### Procedure: CALL_DETAILS

Input parameters:

|    Argument   Name      | Description                                                                             |
|-------------------------|-----------------------------------------------------------------------------------------|
|    p_Account_ID         | Valid CBCM Account ID. For BIAB, it has to be in the format AccountID-AccountNumber    |
|    p_InvoiceNumber      |                                                                                         |
|    p_BillDate           | Invoice month in "MMYYYY" format. Will be considered as unbilled inquiry if no values passed or current month month                                                                                |
|    p_DetailsFLag        |                                                                                         |
|    p_startDate          | DDMMYYY, If start date   available end date is mandatory                                |
|    p_endDate            | DDMMYYYY. Priority of start   and end date always go over Bill Date                     |
|    p_CallDetailsFlag    |                                                                                         |
|    p_requestSytem       |                                                                                         |
|    p_parameter          |                                                                                         |
|    p_parameter_value    |                                                                                         |
|    p_pagesize           | Total   number of records for each page                                                 |
|    p_index              | Paginated row offset to calculate                                                       |
|    p_mainGroup          | Optional, Pass usage main group name, in case details required only for this scenario                    |
|    P_subGroup           | Optional, Pass usage sub group name, in case details required only for this scenario                                                               |

Output parameters:

|    Argument   Name                                                   |  Description                                                     |
|----------------------------------------------------------------------|------------------------------------------------------------------|
|    AcctCallDetails                                                   |  Table of T_BSCS_UI_USAGE                                        |
|    MAINGROUP_NAME                                                    |  Main group name need to decode by client                        |
|    SUBGROUP_NAME                                                     |  Subgroup   name need to decode by client                        |
|    A_PARTY_NUMBER                                                    |  Calling   Number                                                |
|    B_PARTY_NUMBER                                                    |  Called   Number                                                 |
|    CALL_DATE                                                         |                                                                  |
|    CALL_DURATION                                                     |                                                                  |
|    DURATION_UNITS                                                    |  Time   in seconds(00:00:00) or Data in KB                       |
|    DEST_COUNTRY                                                      |                                                                  |
|    ROAMINGCOUNTRY                                                    |                                                                  |
|    OPERATOR_DESC                                                     |                                                                  |
|    AMOUNT                                                            |                                                                  |
|    REMARKS                                                           |                                                                  |
|    SERVICE                                                           |                                                                  |
|    MAIN OBJECT                             T_BSCS_UI_CALL_DETAILS    |                                                                  |
|    TOTAL_RECORDS                                                     |  Total   Number of records. This varies based on online calls    |
|    LAST_PAGE_FLAG                                                    |  ‘Y’   or ‘N’                                                    |

### Procedure: BULK_BALANCE_INQUIRY

Input parameters:

|    Argument Name          | Description                 |
|---------------------------|-----------------------------|
|    P_LINKEDACCOUNTLIST    | Collection of CBCM Account IDs.  <br>For performance perspective, it is advised to pass maximum 500 accounts in a one request |
|    P_REQUESTSYTEM         | Client System requested by.  Eg: SMARTPAY                             |
|    P_PARAMETER            |                             |
|    P_PARAMETER_VALUE      | Additional instruction to the procedure for a special action. Valid inputs: <br>RESP=OSONLY :- <br>With this, procedure will not return BILLEDAMTDUE value; it will return only outstanding related attribute's value |

Output parameters:

Main object:

|    Argument Name             | Description                                                                                             |
|------------------------------|---------------------------------------------------------------------------------------------------------|
|    P_LINKEDACCOUNTBALANCE    | List of account ID with outstanding amount information                                                  |
|    P_AGGREGATEDAMOUNT        | Aggregated amount of all accounts ‘AmountDue’.                                                          |
|    P_PAYABLEAMOUNT           | Aggregated amount for all accounts with ‘AmountDue’;  –ve balances will not be considered in this aggregation   |
|    P_ERR_CODE                | Response Code for the procedure                                                                           |
|    P_ERR_MSG                 | Response message for the procedure                                                                 |

P_LINKEDACCOUNTBALANCE

|    Argument Name             | Description                                                                                             |
|------------------------------|---------------------------------------------------------------------------------------------------------|
|    ACCOUNT_ID                | This refers to the account Id in CBCM.                                                                  |
|    AMOUNTDUE                 | This is the total Outstanding of each account. Refers to CUSTOMER_ALL.CSCURBALANCE                      |
|    BILLEDAMT                 | This   billed amount of previous month. Payable amount of CBCM.  Refers to ORDERHDR_ALL.OHINVAMT_GL     |
|    TOTALBILLEDAMTDUE         | Previous Billed Total Amount Due. Closing balance of CBCM.  Refers to CUSTOMER_ALL.PREV_BALANCE         |
|    P_ERR_CODE                | Each account Level Error Code                                                                           |
|    P_ERR_MSG                 | Each account Level Error Message                                                                     |

!!! Info "Procedure response codes and messages"

    Below are the standards response codes and messages from unified inquiry procedures.  Response code 200 considered as success response, and others are failures

    | CODE | Type                    | Description                                                                                           |
    |------|-------------------------|-------------------------------------------------------------------------------------------------------|
    | 200  | OK                      | Success                                                                                               |
    | 400  | Bad Request             | The request could not be understood by the server due to invalid input                              |
    | 404  | Not Found               | The server has not found anything matching the Request                                              |
    | 500  | Internal Server Error   | The server encountered an unexpected condition which prevented it from fulfilling   the request.    |
    | 604  |                         | ACCOUNT_ID   not Payment Responsible, hence invoice will not be available                             |

### UnbilledRental API

Input parameters:

|    Argument   Name    | Description                                    |
|-----------------------|------------------------------------------------|
|    CUSTNUM            | CBCM   Account ID                              |
|    DETAILS            | TRUE/FALSE –Always   returns full list.        |

Output parameters:

|    Argument   Name      | Description                                                                                                                                                       |
|-------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|    *SERVICELIST*          |                                                                                                                                                                   |
|    PRICE                | Unit Price                                                                                                                                                        |
|    SERVICE_DESC         | Service   description                                                                                                                                             |
|    VALID_FROM_DATE      | Valid   from date                                                                                                                                                 |
|    VALID_TILL_DATE      | Valid   till date                                                                                                                                                 |
|    QUANTITY             | Quantity                                                                                                                                                          |
|    BILLING_FREQUENCY    | Billing   Frequency                                                                                                                                               |
|    *MAINOBJECT*           |                                                                                                                                                                   |
|    TOTAL_RENTAL         | Total Rental Amount of all subscribed services multiplied   by quantity. No pro-rate will be applied. Rate Matrix and OCC approach Rental   are also included.    |
