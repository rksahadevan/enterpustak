Below are the list of Oracle view interfaces for bulk inquiry.

## BSCS Account level balance

This view contain below information against CBCM Account ID:

  * Opening Balance
  * Current month charges
  * Outstanding balance
  * Last Payment Amount
  * Last payment Date

!!! Info "Object Information"

      View name: V_BSCS_ACCOUNT_BALANCE

      Owner: EMCESU

## BSCS Invoice level balance

  This view contain invoice history with below attributes:

  * Customer ID
  * Account ID
  * Outstanding balance
  * Invoice Number
  * Billing Start Date
  * Payable Amount
  * Open Amount
  * Ohrefnum

!!! Info "Object Information"

    View name: V_BSCS_INVOICE_BALANCE

    Owner: EMCESU
