This section talking about all interfaces other than Unified Bill Inquiry.  Interfaces are available as below objects in BSCS:

* Oracle stored Procedures/Packages
* Oracle View
* REST APIs
