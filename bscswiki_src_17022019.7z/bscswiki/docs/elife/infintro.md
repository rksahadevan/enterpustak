## eLife Unlimited packages

Below are list of Unlimited plans available for the customer. Customer can choose non commitment option for AED 20/month extra.

|  			Package Name 		            |  			Package <br>Regular price 		 |  			Package price <br>without commitment 		 |
|---------------------------|------------------------:|-----------------------------------:|
|  			Unlimited Starter 		       |  			389 		                   |  			409 		                              |
|  			Unlimited Sports 		        |  			559 		                   |  			579 		                              |
|  			Unlimited Entertainment 		 |  			599 		                   |  			619 		                              |
|  			Premium 500 		             |  			1139 		                  |  			1159 		                             |
|  			Premium 1G 		              |  			2850 		                  |  			2870 		                             |
