# Unified Inquiry Procedures

## Unified Bill Inquiry

This is an Oracle Package and returns billing information as per invoice.  TIBCO invokes these procedures according to client requirements.  It support inquiry for one account at a time and consists of below main procedures:

| PROCEDURE NAME                       | DESCRIPTION                                 |
|--------------------------------------|---------------------------------------------|
| HEADER_INFO  | Provides invoice level summary                        |
| SUMMARY_INFO | Provides transaction breakup in the invoice                                   |
| DETAILS_INFO | Provides individual transaction details in the invoice             |
| CALL_DETAILS | Provides individual call details |
| FUP_INFO | Provides free units information for current month |
| USAGE_SUMMARY | Provides transaction breakup as per Mini Bill SMS format|

Database Object Information:

    Package name: UNIFIED_BILL_INQUIRY
    Procedure owner: BILL_ENQUIRY
    Clients: TIBCO/CBCM BIL

Same DB package implemented in ODS database as well, and TIBCO will route all unbilled inquiries to BSCS database and billed inquiries to ODS database.

Procedure Response codes:

| Response Code                       | Description                                 |
|--------------------------------------|---------------------------------------------|
| 200<br>OK | Success |
| 400<br>Bad Request | The request could not be understood by the server due to invalid input |
| 404<br>Not Found | The server has not found anything matching the request |
| 500<br>Internal Server Error | The server encountered an unexpected condition which prevented it from fulfilling the request |
| 604 | Requested ACCOUNT_ID not Payment Responsible in BSCS, hence invoice will not be avaialable |

!!! Note
    * FUP_INFO supports free units inquiry only for the FU SHDES for which mapping available in EMCESU.T_BSCS_FUP_GROUP
    * Above said procedure does not handles unbilled rental amount; TIBCO will use Unbilled Rental API's result to fetch unbilled rental amount. Unbilled rentals will be for the full month without prorate the charges; proration logic not implemented in this API

## Unbilled Rental

Unified Bill Inquiry Oracle DB Procedures not handling rental information which are not billed to customer.  Hence unbilled rental information addressed by using [unBilledRental REST API](../../unified/apiusage#unbilled-rental).  This provides total unbilled rental for requested CBCM Account without applying pro-rate logic, this will be charges for the whole month.
This API internally calls an Oracle procedure to fetch subscription change history and its price configuration for a BSCS Contract.

Object Information:

    Procedure name: UNBILLED_RENAL.GET_CURMONTH_SUBSCRIPTION
    Procedure owner: BILL_ENQUIRY
    Clients: REST API

## Client request via TIBCO

  Clients requests billing information from TIBCO by passing different identifier flags as below.  TIBCO identifies and executes BSCS procedures in parallel, concatenates the results of each BSCS Procedure, and then provide a single response back to the client.  Identifier flags used by clients are listed below:

  | Identifier Flag            | BSCS Procedure to be invoked                          |
  |--------------------------------------|---------------------------------------------|
  | Summary	 | HEADER_INFO, SUMMARY_INFO |
  | TotalAmount	 | HEADER_INFO |
  | AsOfNowUsage	 | HEADER_INFO |
  | UnbilledRentalsBSCS  | HEADER_INFO, UnbilledRentalsBSCS |
  | FUP	 | 	HEADER_INFO, FUP_INFO |
  | RebatesInfo	 | HEADER_INFO, REBATES_INFO |

  Example on the identifierFlag values and how to pass it.
  In case of multiple IdentifierFlag then those will be sent in comma separator.

    Examples:
    IdentifierFlag = Summary,AsOfNowUsage,FUP
      Client will get: Header Info + AsOfNowUsage + Summary + FUP

    IdentifierFlag = Summary
      Client will get: Header Info + Summary

    IdentifierFlag = AsOfNowUsage
      Client will get: Header Info + As of now usage

    IdentifierFlag = RebatesInfo
      Client will get: Header Info + RebatesInfo

    IdentifierFlag = FUP
      Client will get: Header Info + FUP

    IdentifierFlag = TotalAmount or NULL
      Client will get: Header Info

  Migration status for the requested account will be identified by TIBCO and it will call BSCS/CBCM Inquiry accrodingly.  


## Test Scripts

If you want to troubleshoot/analyze the stored procedure results, use below download link to test the procedures in DB level.  Save the file into your local path by right click and choose the option "Save target as".  These scripts can be executed from SQL Prompt or any other Oracle IDE application like TOAD, PL/SQL Developer etc.  Update required input values in the file before execution.

[Header Info Test script](UNIFIED_BILL_INQUIRY_HEADER_INFO.sql)

[Summary Info Test script](UNIFIED_BILL_INQUIRY_SUMMARY_INFO.sql)

[Details Info Test script](UNIFIED_BILL_INQUIRY_DETAILS_INFO.sql)

[Call Details Test script](UNIFIED_BILL_INQUIRY_CALL_DETAILS.sql)

[FUP Info Test script](UNIFIED_BILL_INQUIRY_FUP_INFO.sql)

[UNBILLED_RENAL.GET_CURMONTH_SUBSCRIPTION  Test script](UNBILLED_RENTAL_SUBSCRIPTION.sql)
