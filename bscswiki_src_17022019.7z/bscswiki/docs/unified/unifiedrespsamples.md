# Sample Request/Responses for Unified Bill Inquiry

### Request/Response Samples

Given below list of sample requests for different procedures in Unified Bill Inquiry.  This is provided to get the full information of the API on the attributes it is returning.

#### Header_Info request/response

Note: Unbilled rental amount will be always Zero from this procedure

      SAMPLE REQUEST (SOAP)

      <soapenv:Body>
          <onl:OnlineBillInquiryRequest>
             <app:ApplicationHeader>
                <app:TransactionID>63463487686242422</app:TransactionID>
                <app:RequestedSystem>DigitalApp</app:RequestedSystem>
                <app:RequestedDate>?</app:RequestedDate>
             </app:ApplicationHeader>
             <onl:DataHeader>
                <!--You have a CHOICE of the next 4 items at this level
               <onl:AccountID>716741354</onl:AccountID>-->
               <onl:AccountNumber>043469364</onl:AccountNumber>
                 <!--Optional:-->
                <onl:BillDate>122018</onl:BillDate>
                <onl:DetailsFlag>true</onl:DetailsFlag>
                <onl:CallDetailsFlag>false</onl:CallDetailsFlag>
                <!--Optional:-->
                <onl:IdentifierFlag>AsOfNowUsage </onl:IdentifierFlag>
                <!--Zero or more repetitions:-->
                <com:AdditionalInfo>
                   <com:Name>?</com:Name>
                   <com:Value>?</com:Value>
                </com:AdditionalInfo>
             </onl:DataHeader>
          </onl:OnlineBillInquiryRequest>
       </soapenv:Body>

       ATTRIBUTES IN RESPONSE

       {
               "billedAmount": 325.03,
               "totalBilledAmountDue": 0,
               "totalAmountDue": 324.96,
               "dueDate": "2019-02-15 12:00:00",
               "asofNowAmountDue": 0,
               "accountName": " SREEJITH GOPALAKRISHNAN",
               "invoiceNumber": "INV1649112869",
               "accountId": "696570386",
               "accountStatus": " SREEJITH GOPALAKRISHNAN",
               "invoiceDate": "2019-02-01",
               "billFromDate": "2019-01-01 12:00:00",
               "billToDate": "2019-01-31 12:00:00",
               "deliveryId": 0,
               "lastPaymentDate": null,
               "lastPaymentAmount": null,
               "openAmount": 324.96
           }

#### Summary_Info Request/Response

Note: Unbilled rental amount will be always Zero from this procedure

    SAMPLE REQUEST (SOAP)

    <soapenv:Body>
          <onl:OnlineBillInquiryRequest>
             <app:ApplicationHeader>
                <app:TransactionID>63463487686242422</app:TransactionID>
                <app:RequestedSystem>DigitalApp</app:RequestedSystem>
                <app:RequestedDate>?</app:RequestedDate>
             </app:ApplicationHeader>
             <onl:DataHeader>
                <!--You have a CHOICE of the next 4 items at this level
               <onl:AccountID>716741354</onl:AccountID>-->
               <onl:AccountNumber>043469364</onl:AccountNumber>
                 <!--Optional:-->
                <onl:BillDate>122018</onl:BillDate>
                <onl:DetailsFlag>true</onl:DetailsFlag>
                <onl:CallDetailsFlag>false</onl:CallDetailsFlag>
                <!--Optional:-->
                <onl:IdentifierFlag>AsOfNowUsage,Summary </onl:IdentifierFlag>
                <!--Zero or more repetitions:-->
                <com:AdditionalInfo>
                   <com:Name>?</com:Name>
                   <com:Value>?</com:Value>
                </com:AdditionalInfo>
             </onl:DataHeader>
          </onl:OnlineBillInquiryRequest>
       </soapenv:Body>

       ATTRIBUTES IN RESPONSE

          {
               "invoiceNumber": "INV1649112869",
               "invoiceDate": "2019-02-01",
               "openingBalance": 0,
               "totalOnetimeAmount": 0,
               "totalDiscountAmount": 0,
               "totalPaymentAmount": 0,
               "totalAdjustmentAmount": -370.71,
               "totalTaxAmount": 0,
               "totalUsageAmount": 122.4,
               "totalRentalAmount": 187.15,
               "planRentalAmount": 0,
               "addOnRentalAmount": 187.15,
               "planDiscountAmount": 0
           }


#### Details_Info Request/Response

Note: Unbilled rental amount will not be available in the response

    SAMPLE REQUEST (SOAP)

    <soapenv:Body>
          <onl:OnlineBillInquiryRequest>
             <app:ApplicationHeader>
                <app:TransactionID>63463487686242422</app:TransactionID>
                <app:RequestedSystem>DigitalApp</app:RequestedSystem>
                <app:RequestedDate>?</app:RequestedDate>
             </app:ApplicationHeader>
             <onl:DataHeader>
                <!--You have a CHOICE of the next 4 items at this level
               <onl:AccountID>716741354</onl:AccountID>-->
               <onl:AccountNumber>043469364</onl:AccountNumber>
                 <!--Optional:-->
                <onl:BillDate>122018</onl:BillDate>
                <onl:DetailsFlag>true</onl:DetailsFlag>
                <onl:CallDetailsFlag>false</onl:CallDetailsFlag>
                <!--Optional:-->
                <onl:IdentifierFlag>AsOfNowUsage,Summary </onl:IdentifierFlag>
                <!--Zero or more repetitions:-->
                <com:AdditionalInfo>
                   <com:Name>?</com:Name>
                   <com:Value>?</com:Value>
                </com:AdditionalInfo>
             </onl:DataHeader>
          </onl:OnlineBillInquiryRequest>
       </soapenv:Body>

       ATTRIBUTES IN RESPONSE

       {
        "accountId": 696570386,
        "invoiceNumber": "0",
        "customerIdList": "5118678",
        "financialTransDetails": [
            {
                "serviceCode": null,
                "serviceDesc": "Reimbursement",
                "transactionFromDate": null,
                "transactionToDate": null,
                "transactionType": "IMMEDIATE",
                "transactionDate": "2019-01-25",
                "packageIdDesc": null,
                "transactionMode": null,
                "taxAppliedCharge": null,
                "amount": -0.01,
               "remarks": null,
                "taxRate": null
            },
            {
                "serviceCode": null,
                "serviceDesc": "Reimbursement",
                "transactionFromDate": null,
                "transactionToDate": null,
                "transactionType": "IMMEDIATE",
                "transactionDate": "2019-01-25",
                "packageIdDesc": null,
                "transactionMode": null,
                "taxAppliedCharge": null,
                "amount": -370.7,
                "remarks": null,
                "taxRate": null
            },
            {
                "serviceCode": "TVC82",
                "serviceDesc": "eLife TV - Pehla Lite",
                "transactionFromDate": "2019-01-01",
                "transactionToDate": "2019-01-31",
                "transactionType": "RECURRING",
                "transactionDate": "2019-02-01",
                "packageIdDesc": null,
                "transactionMode": "ADDON",
                "taxAppliedCharge": null,
                "amount": 67.15,
                "remarks": null,
                "taxRate": null
            },
            {
                "serviceCode": "LLOCP",
                "serviceDesc": "Voice - 50Fils (no call setup)",
                "transactionFromDate": "2019-01-01",
                "transactionToDate": "2019-01-31",
                "transactionType": "RECURRING",
                "transactionDate": "2019-02-01",
                "packageIdDesc": null,
                "transactionMode": "ADDON",
                "taxAppliedCharge": null,
                "amount": 20,
                "remarks": null,
                "taxRate": null
            },
            {
                "serviceCode": "VOIPB",
                "serviceDesc": "Internet Calling Plan for eLife",
                "transactionFromDate": "2019-01-01",
                "transactionToDate": "2019-01-31",
                "transactionType": "RECURRING",
                "transactionDate": "2019-02-01",
                "packageIdDesc": null,
                "transactionMode": "ADDON",
                "taxAppliedCharge": null,
                "amount": 100,
                "remarks": null,
                "taxRate": null
            }
        ],
        "usageSummaryDetails": [
            {
                "mainGroupName": "International Usage",
                "subGroupName": "International_Calls",
                "description": "International Calls",
                "amount": 121.5,
                "chargedUnits": "22",
                "chargedType": "14580",
                "remarks": null
            },
            {
                "mainGroupName": "Local Usage",
                "subGroupName": "Calls_to_Local_Mobile",
                "description": "Calls to Local Mobile",
                "amount": 0.9,
                "chargedUnits": "3",
                "chargedType": "180",
                "remarks": null
            },
            {
                "mainGroupName": "Local Usage",
                "subGroupName": "Calls_to_Telephone",
                "description": "Calls to Telephone",
                "amount": 0,
                "chargedUnits": "37",
                "chargedType": "12960",
                "remarks": null
            }
        ],
        "remarks": null

#### Call_Details Request/Response

Sample response

    CallDetails
    (
    "total_records": 3,
    "last_page_flag": "Y",
    "calldetailrecord": ,         
    "call_details_rec": [
    	{
    	"maingroup_name": "International Usage",
    	"subgroup_name": "International_Calls",
    	"a_party_number": "01971504094949",
    	"b_party_number": "201003459950",
    	"call_date": "2019-01-01T22:44:09+04:00",
    	"call_duration": 338,
    	"duration_units": null,
    	"dest_country": null,
    	"operator_desc": null,
    	"roaming_country": null,
    	"service": "Voice",
    	"amount": 6.6,
    	"remarks": null
    	},
    	{
    	"maingroup_name": "International Usage",
    	"subgroup_name": "International_Calls",
    	"a_party_number": "01971504094949",
    	"b_party_number": "201062225909",
    	"call_date": "2019-01-02T12:45:18+04:00",
    	"call_duration": 212,
    	"duration_units": null,
    	"dest_country": null,
    	"operator_desc": null,
    	"roaming_country": null,
    	"service": "Voice",
    	"amount": 4.4,
    	"remarks": null
    	},
    	{
    	"maingroup_name": "Local Usage",
    	"subgroup_name": "Calls_To_Mobile",
    	"a_party_number": "01971504094949",
    	"b_party_number": "971506349967",
    	"call_date": "2019-01-02T12:50:58+04:00",
    	"call_duration": 227,
    	"duration_units": null,
    	"dest_country": null,
    	"operator_desc": null,
    	"roaming_country": null,
    	"service": "Voice",
    	"amount": 0.8,
    	"remarks": null
    	}
        ]
    )

#### UnbilledRental Request/Response

Note: Unbilled rentals will be for the full month without prorate the charges; proration logic not implemented in this API

  SAMPLE Request

    <soapenv:Body>
      <onl:OnlineBillInquiryRequest>
         <app:ApplicationHeader>
            <app:TransactionID>Test_702349562</app:TransactionID>
            <app:RequestedSystem>CRC</app:RequestedSystem>
            <!--Optional:-->
            <app:RetryLimit></app:RetryLimit>
            <!--Optional:-->
            <app:RequestedDate></app:RequestedDate>
         </app:ApplicationHeader>
         <onl:DataHeader>
            <!--You have a CHOICE of the next 4 items at this level-->
            <!--Optional:-->
            <onl:AccountID>702379931</onl:AccountID>
            <onl:BillDate>112017</onl:BillDate>
            <onl:DetailsFlag>false</onl:DetailsFlag>
            <onl:CallDetailsFlag>false</onl:CallDetailsFlag>
            <!--Optional:-->
         <onl:IdentifierFlag>AsOfNowUsage,UnbilledRentalsBSCS</onl:IdentifierFlag>
            <!--Zero or more repetitions:-->
            <com:AdditionalInfo>
               <com:Name></com:Name>
               <com:Value></com:Value>
            </com:AdditionalInfo>
         </onl:DataHeader>
      </onl:Online

    SAMPLE Response

     <SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/">
     <SOAP-ENV:Body>
        <ns0:OnlineBillInquiryResponse xmlns:ns0="http://www.etisalat.ae/Middleware/UnifiedBillInquiry/OnlineBillInquiryResponse.xsd">
           <ns0:ResposneData>
              <ns0:TransactionID>20180103121807</ns0:TransactionID>
              <ns0:Account>
                 <ns0:AccountID>702414646</ns0:AccountID>
                 <ns0:AccountName>TES  TEST</ns0:AccountName>
                 <ns0:AccountStatus>ACTIVE</ns0:AccountStatus>
                 <ns0:BillDateFrom>2018-12-01T00:00:00+04:00</ns0:BillDateFrom>
                 <ns0:BillDateTo>2018-12-31T00:00:00+04:00</ns0:BillDateTo>
                 <ns0:DeliveryID>0</ns0:DeliveryID>
                 <ns0:InvoiceNumber>INV1500029329</ns0:InvoiceNumber>
                 <ns0:InvoiceDate>2019-01-01T00:00:00+04:00</ns0:InvoiceDate>
                 <ns0:OpenAmount>895.17</ns0:OpenAmount>
                 <ns0:BilledAmnt>895.17</ns0:BilledAmnt>
                 <ns0:TotalBilledAmntDue>0.0</ns0:TotalBilledAmntDue>
                 <ns0:TotalAmountDue>2794.91</ns0:TotalAmountDue>
                 <ns0:AsOfNowAmountDue>0.0</ns0:AsOfNowAmountDue>
                 <ns0:DueDate>2019-01-15T00:00:00+04:00</ns0:DueDate>
                 <ns0:Summary>
                    <ns0:TotalUnbilledRentalsBSCS>674.0</ns0:TotalUnbilledRentalsBSCS>
                    <ns0:TransactionDetails/>
                    <ns0:UnbilledRentals>
                       <ns0:BSCSServiceList>
                          <ns0:Price>0.0</ns0:Price>
                          <ns0:ServiceDesc>ENI11</ns0:ServiceDesc>
                          <ns0:ValidFromDate>2018-12-06T03:25:37.001+04:00</ns0:ValidFromDate>
                          <ns0:Quantity>1</ns0:Quantity>
                       </ns0:BSCSServiceList>
                       <ns0:BSCSServiceList>
                          <ns0:Price>9.0</ns0:Price>
                          <ns0:ServiceDesc>LLELV</ns0:ServiceDesc>
                          <ns0:ValidFromDate>2018-12-06T03:25:37.001+04:00</ns0:ValidFromDate>
                          <ns0:Quantity>1</ns0:Quantity>
                       </ns0:BSCSServiceList>
                       <ns0:BSCSServiceList>
                          <ns0:Price>30.0</ns0:Price>
                          <ns0:ServiceDesc>TV333</ns0:ServiceDesc>
                          <ns0:ValidFromDate>2018-12-06T03:25:37.001+04:00</ns0:ValidFromDate>
                          <ns0:Quantity>1</ns0:Quantity>
                       </ns0:BSCSServiceList>
                       <ns0:BSCSServiceList>
                          <ns0:Price>0.0</ns0:Price>
                          <ns0:ServiceDesc>TV339</ns0:ServiceDesc>
                          <ns0:ValidFromDate>2018-12-06T03:25:37.001+04:00</ns0:ValidFromDate>
                          <ns0:Quantity>1</ns0:Quantity>
                       </ns0:BSCSServiceList>
                       <ns0:BSCSServiceList>
                          <ns0:Price>39.0</ns0:Price>
                          <ns0:ServiceDesc>WWE03</ns0:ServiceDesc>
                          <ns0:ValidFromDate>2018-12-06T03:25:37.001+04:00</ns0:ValidFromDate>
                          <ns0:Quantity>1</ns0:Quantity>
                       </ns0:BSCSServiceList>
                       <ns0:BSCSServiceList>
                          <ns0:Price>150.0</ns0:Price>
                          <ns0:ServiceDesc>WWE05</ns0:ServiceDesc>
                          <ns0:ValidFromDate>2018-12-06T03:25:37.001+04:00</ns0:ValidFromDate>
                          <ns0:Quantity>1</ns0:Quantity>
                       </ns0:BSCSServiceList>
                       <ns0:BSCSServiceList>
                          <ns0:Price>20.0</ns0:Price>
                          <ns0:ServiceDesc>WWE11</ns0:ServiceDesc>
                          <ns0:ValidFromDate>2018-12-06T03:25:37.001+04:00</ns0:ValidFromDate>
                          <ns0:Quantity>1</ns0:Quantity>
                       </ns0:BSCSServiceList>
                       <ns0:BSCSServiceList>
                          <ns0:Price>10.0</ns0:Price>
                          <ns0:ServiceDesc>WWE12</ns0:ServiceDesc>
                          <ns0:ValidFromDate>2018-12-06T03:25:37.001+04:00</ns0:ValidFromDate>
                          <ns0:Quantity>1</ns0:Quantity>
                       </ns0:BSCSServiceList>
                       <ns0:BSCSServiceList>
                          <ns0:Price>311.0</ns0:Price>
                          <ns0:ServiceDesc>WWC02</ns0:ServiceDesc>
                          <ns0:ValidFromDate>2018-08-15T15:34:23.001+04:00</ns0:ValidFromDate>
                          <ns0:Quantity>1</ns0:Quantity>
                       </ns0:BSCSServiceList>
                       <ns0:BSCSServiceList>
                          <ns0:Price>0.0</ns0:Price>
                          <ns0:ServiceDesc>LOC01</ns0:ServiceDesc>
                          <ns0:ValidFromDate>2018-12-05T23:52:06.001+04:00</ns0:ValidFromDate>
                          <ns0:Quantity>1</ns0:Quantity>
                       </ns0:BSCSServiceList>
                       <ns0:BSCSServiceList>
                          <ns0:Price>0.0</ns0:Price>
                          <ns0:ServiceDesc>ELVM2</ns0:ServiceDesc>
                          <ns0:ValidFromDate>2018-12-05T23:52:06.001+04:00</ns0:ValidFromDate>
                          <ns0:Quantity>1</ns0:Quantity>
                       </ns0:BSCSServiceList>
                       <ns0:BSCSServiceList>
                          <ns0:Price>0.0</ns0:Price>
                          <ns0:ServiceDesc>ENI13</ns0:ServiceDesc>
                          <ns0:ValidFromDate>2018-12-05T23:52:06.001+04:00</ns0:ValidFromDate>
                          <ns0:Quantity>1</ns0:Quantity>
                       </ns0:BSCSServiceList>
                       <ns0:BSCSServiceList>
                          <ns0:Price>0.0</ns0:Price>
                          <ns0:ServiceDesc>ENIS7</ns0:ServiceDesc>
                          <ns0:ValidFromDate>2018-12-05T23:52:06.001+04:00</ns0:ValidFromDate>
                          <ns0:Quantity>1</ns0:Quantity>
                       </ns0:BSCSServiceList>
                       <ns0:BSCSServiceList>
                          <ns0:Price>0.0</ns0:Price>
                          <ns0:ServiceDesc>LLRFI</ns0:ServiceDesc>
                          <ns0:ValidFromDate>2018-12-05T23:52:06.001+04:00</ns0:ValidFromDate>
                          <ns0:Quantity>1</ns0:Quantity>
                       </ns0:BSCSServiceList>
                       <ns0:BSCSServiceList>
                          <ns0:Price>0.0</ns0:Price>
                          <ns0:ServiceDesc>LQCID</ns0:ServiceDesc>
                          <ns0:ValidFromDate>2018-12-05T23:52:06.001+04:00</ns0:ValidFromDate>
                          <ns0:Quantity>1</ns0:Quantity>
                       </ns0:BSCSServiceList>
                       <ns0:BSCSServiceList>
                          <ns0:Price>30.0</ns0:Price>
                          <ns0:ServiceDesc>EGM01</ns0:ServiceDesc>
                          <ns0:ValidFromDate>2018-08-26T13:05:16.001+04:00</ns0:ValidFromDate>
                          <ns0:Quantity>1</ns0:Quantity>
                       </ns0:BSCSServiceList>
                       <ns0:BSCSServiceList>
                          <ns0:Price>0.0</ns0:Price>
                          <ns0:ServiceDesc>LLF2F</ns0:ServiceDesc>
                          <ns0:ValidFromDate>2018-08-15T15:34:23.001+04:00</ns0:ValidFromDate>
                          <ns0:Quantity>1</ns0:Quantity>
                       </ns0:BSCSServiceList>
                       <ns0:BSCSServiceList>
                          <ns0:Price>30.0</ns0:Price>
                          <ns0:ServiceDesc>ST001</ns0:ServiceDesc>
                          <ns0:ValidFromDate>2018-08-15T15:34:23.001+04:00</ns0:ValidFromDate>
                          <ns0:Quantity>1</ns0:Quantity>
                       </ns0:BSCSServiceList>
                       <ns0:BSCSServiceList>
                          <ns0:Price>10.0</ns0:Price>
                          <ns0:ServiceDesc>ST101</ns0:ServiceDesc>
                          <ns0:ValidFromDate>2018-08-15T15:34:23.001+04:00</ns0:ValidFromDate>
                          <ns0:Quantity>1</ns0:Quantity>
                       </ns0:BSCSServiceList>
                       <ns0:BSCSServiceList>
                          <ns0:Price>0.0</ns0:Price>
                          <ns0:ServiceDesc>USC01</ns0:ServiceDesc>
                          <ns0:ValidFromDate>2018-08-15T15:34:23.001+04:00</ns0:ValidFromDate>
                          <ns0:Quantity>1</ns0:Quantity>
                       </ns0:BSCSServiceList>
                       <ns0:BSCSServiceList>
                          <ns0:Price>0.0</ns0:Price>
                          <ns0:ServiceDesc>USC03</ns0:ServiceDesc>
                          <ns0:ValidFromDate>2018-08-15T15:34:23.001+04:00</ns0:ValidFromDate>
                          <ns0:Quantity>1</ns0:Quantity>
                       </ns0:BSCSServiceList>
                       <ns0:BSCSServiceList>
                          <ns0:Price>0.0</ns0:Price>
                          <ns0:ServiceDesc>USC05</ns0:ServiceDesc>
                          <ns0:ValidFromDate>2018-08-15T15:34:23.001+04:00</ns0:ValidFromDate>
                          <ns0:Quantity>1</ns0:Quantity>
                       </ns0:BSCSServiceList>
                       <ns0:BSCSServiceList>
                          <ns0:Price>0.0</ns0:Price>
                          <ns0:ServiceDesc>USC07</ns0:ServiceDesc>
                          <ns0:ValidFromDate>2018-08-15T15:34:23.001+04:00</ns0:ValidFromDate>
                          <ns0:Quantity>1</ns0:Quantity>
                       </ns0:BSCSServiceList>
                       <ns0:BSCSServiceList>
                          <ns0:Price>5.0</ns0:Price>
                          <ns0:ServiceDesc>WWC01</ns0:ServiceDesc>
                          <ns0:ValidFromDate>2018-08-15T15:34:23.001+04:00</ns0:ValidFromDate>
                          <ns0:Quantity>1</ns0:Quantity>
                       </ns0:BSCSServiceList>
                       <ns0:BSCSServiceList>
                          <ns0:Price>30.0</ns0:Price>
                          <ns0:ServiceDesc>WWE01</ns0:ServiceDesc>
                          <ns0:ValidFromDate>2018-08-15T15:34:23.001+04:00</ns0:ValidFromDate>
                          <ns0:Quantity>1</ns0:Quantity>
                       </ns0:BSCSServiceList>
                    </ns0:UnbilledRentals>
                 </ns0:Summary>
              </ns0:Account>
           </ns0:ResposneData>
           <ns1:AckMessage xmlns:ns1="http://www.etisalat.ae/Middleware/SharedResources/Common/AckMessage.xsd">
              <ns1:Status>SUCCESS</ns1:Status>
           </ns1:AckMessage>
        </ns0:OnlineBillInquiryResponse>
     </SOAP-ENV:Body>
  </SOAP-ENV:Envelope>

  #### FUP_Info Request

        SAMPLE REQUEST (SOAP)

        <soapenv:Body>
            <onl:OnlineBillInquiryRequest>
               <app:ApplicationHeader>
                  <app:TransactionID>63463487686242422</app:TransactionID>
                  <app:RequestedSystem>CIM</app:RequestedSystem>
                  <app:RequestedDate>?</app:RequestedDate>
               </app:ApplicationHeader>
               <onl:DataHeader>
                  <!--You have a CHOICE of the next 4 items at this level
                 <onl:AccountID>638910369</onl:AccountID>-->
                 <onl:AccountNumber>065395034</onl:AccountNumber>
                   <!--Optional:-->
                  <onl:BillDate>102018</onl:BillDate>
                  <onl:DetailsFlag>false</onl:DetailsFlag>
                  <onl:CallDetailsFlag>false</onl:CallDetailsFlag>
                  <!--Optional:-->
                  <onl:IdentifierFlag>FUP_INFO</onl:IdentifierFlag>
                  <!--Zero or more repetitions:-->
                  <com:AdditionalInfo>
                     <com:Name>FUPONLY</com:Name>
                     <com:Value>YES</com:Value>
                  </com:AdditionalInfo>
               </onl:DataHeader>
            </onl:OnlineBillInquiryRequest>
         </soapenv:Body>

         ATTRIBUTES IN RESPONSE

         PackageLevelDetailsList [
         {
            "PackageName": "F2F",
            "FreeUnits": 7500,
            "ConsumedUnits": 0.0
          },
          {
             "PackageName": "FLXI",
             "FreeUnits": 202,
             "ConsumedUnits": 0.0
           }
        ]

#### miniBillSMS Request/Response sample

    Production URL:
    https://bscs.etisalat.corp.ae/bscsrs/rest/ubService/miniBillSMS?accountId=724618828&billingMonth=122018

    Sample Output:

    {
        "errorMessage": "OK|20-01-2019 10.38.50.5339|20-01-2019 10.38.50.5506|
        724618828|1644131304|122018|SMS|||01122018000000|31122018235959|
        01012019000000|9749757|9749757|||",
        "errorCode": 200,
        "accountId": 724618828,
        "openingBalance": 499.45,
        "rentalAmount": 198,
        "paymentAmount": 0,
        "adjustmentAmount": -436.45,
        "discountAmount": 0,
        "onetimeAmount": 0,
        "vatAmount": 24.05,
        "totalAmountDue": 565.09,
        "billingMonth": "122018",
        "dueDate": "2019-01-15 12:00:00",
        "fromDate": "2018-12-01 12:00:00",
        "toDate": "2018-12-31 12:00:00",
        "subscription": "Mobile services",
        "usageList": [
            {
                "smsUsageGroup": "Text Messages",
                "usageAmount": 0.54
            },
            {
                "smsUsageGroup": "Local Calls",
                "usageAmount": 150
            },
            {
                "smsUsageGroup": "International calls",
                "usageAmount": 192.5
            }
        ],
        "invoiceNumber": "INV1644131304"
    }
