Below are the list of Oracle view interfaces for bulk inquiry.

## BSCS Account level balance

View **EMCESU.V_BSCS_ACCOUNT_BALANCE** contain account level balance with below attributes:

  | Attribute Name      | Description                                                                                                                             |
  |---------------------|-----------------------------------------------------------------------------------------------------------------------------------------|
  | ACCOUNT_ID          | Refers to CBCM Account ID.  Pass the value as string for better performance.<br>Account ID is mandatory for any query in this view |
  | OPENING_BALANCE     | Refers to Opening balance for the account in current month |
  | OUTSTANDING_BALANCE | Refers to Outstanding balance for the account as per last invoice |  
  | LAST_PAYMENT_AMOUNT | Refers to last payment amount for the account |  
  | LAST_PAYMENT_AMOUNT | Refers to last payment date for the account |  

  For better performance, list of account IDs to be limited to maximum 1000
  
## BSCS Invoice level balance

  View **EMCESU.V_BSCS_INVOICE_BALANCE** contain invoice history information with below attributes:

  | Attribute Name      | Description                                                                                                                             |
  |---------------------|-----------------------------------------------------------------------------------------------------------------------------------------|
  | ACCOUNT_ID          | Refers to CBCM Account ID.  Pass the value as string for better performance.<br>Account ID is mandatory for any query in this view |
  | BILLING_START_DATE  | Refers to Bill cycle starting date <br>Eg: 01-Jan-2019, 01-Feb-2019                                                                   |
  | CUSTOMER_ID         | Refers to BSCS Customer ID where invoice getting generated                                                                            |
  | INVOICE_NUMBER      | Refers to Invoice Number WITHOUT having INV or ZB prefix.<br>Eg: 1645486120, 2739257872                                              |
  | OHREFNUM            | Refers to Invoice Number WITH INV or ZB prefix<br>Eg: INV1645486120, ZB2739257872                                                    |
  | OUTSTANDING_BALANCE | Outstanding balance for the account ID                                                                                                 |
  | PAYABLE_AMOUNT      | Invoice Amount for the account ID for specific billing month                                                                          |
  | OPEN_AMOUNT         | Open Invoice Amount for the account ID for specific billing month                                                                     |

  **Derivable Attributes**

  Below are the attributes that can be derived from the view.

  | Attribute Name      |Description                                                                      |
  |---------------------|---------------------------------------------------------------------------------|
  | SETTLEDAMOUNT | This can be   derived by using (PAYABLE_AMOUNT- OPEN_AMOUNT)     |
  | INVOICE_MONTH | This can be derived   by using ADD_MONTHS(BILLING_START_DATE, 1) |

  For better performance, list of account IDs to be limited to maximum 1000
