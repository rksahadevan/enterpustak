!!! Info "Notes"
    * elife Starter package also known as Basic or Family packages
    * No commitment option for AED 20/month extra; base plan service will be added accordingly
    * CRM Package Code: MKTP3P50MBINFSTARTER
    * BSCS TMCODE: RPEL3

## Package composition

|    Line   item                                        |    CBCM   RP Code    |    Amount    |    Promo     |     BSCS   Service                                        |
|-------------------------------------------------------|----------------------|-------------:|-------------:|-----------------------------------------------------------|
|    BroadBand   Speed                                  |    RPTPINFSTRBB<br>RPTPINFSTRNCBB      |    271.00    |              |    SPISC_WWC02   (AED271)<br>SPITN_WWC02 (AED291)    |
|    eLife   ON                                         |    RP622732          |    30.00     |              |    SPE3S_WWE01                                      |
|    On-Demand   Unlimited Basic                        |    RP599609          |    39.00     |              |    SPE3S_WWE03                                      |
|    On-Demand   Unlimited Premium                      |    RPPREMVDPACKS     |    10.00     |              |    EL3TV_WWE12                                      |
|    eLife   Basic                                      |    RPINFINTEBASIC    |    30.00     |              |    EL3TV_TV333                                      |
|    eLife   Voice                                      |    RPINFVOICE        |    9.00      |              |    SPLAO_LLELV                                      |
|    Wireless   Telephone (Gigaset)                     |    RP636658          |    5.00      |    -5.00     |    SPE3V_WWC01                                      |
|    STB   - Regular                                    |    RP636558          |    20.00     |    -20.00    |    STESV_ST002                                      |
|    Router   - Basic                                   |    RPDLINK803R24     |    10.00     |    -10.00    |    STESV_ST101                                      |
|    Package Price                  |                      |    424.00    |              |                                                           |
|    Discount                                           |                      |    -35.00    |              |                                                           |
|    **Bundle Price**    |                      |    **389.00**    |              |                                                           |
|    Price after 5% VAT                                 |                      |    408.45    |              |                                                           |

## Sample Invoice

!!! info "Sample Invoice - Regular subscription"
    ![Sample Invoice](../img/invInfStarter.PNG)

!!! info "Sample Invoice - With no commitment option"    
    ![Sample Invoice](../img/invInfStarterNC.PNG)
