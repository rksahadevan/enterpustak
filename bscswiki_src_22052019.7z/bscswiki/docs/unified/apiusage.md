# API Usage

## Rule of Thumb before using the API

  Below are the rules before using any API in Unified Interface:

  a) What is the level of data you want from Inquiry

  -	Summary Level
  -	Detail Level
  -	Account Level
  -	Invoice Level

  b) What is the type of client?

  -	Online
  -	Batch
  -	IVR
  -	Thick client
  -	Thin client

  c) What is the expected response time required for the client?

  -	milliseconds
  -	seconds

  d) What is the nature of Inquiry?

  -	Bulk inquiry
  -	Individual inquiry
  -	Bulk Inquiry with pagination

API's are designed by considering all above aspects. API explorer  matrix will give details about API's

Every API call consists of three elements: the *entity*, *ActionName*, and *parameters*.

For example, consider a few commonly-used entities along with the supported actions and parameters:

|     Entity        |     Description                                        |     Actions                                                  |     Parameters     |
|-------------------|--------------------------------------------------------|--------------------------------------------------------------|--------------------|
|    Account        |    CBCM AccountId with/without billing Month           |    AsOfNowUsage<br>Summary<br>FUP_INFO<br>LastPaymentDetails    |                    |
|    Invoice        |    Invoice Number                                      |    AsOfNowUsage<br>Summary<br>FUP_INFO<br>LastPaymentDetails    |                    |
|    FUP            |    CBCM AccountId                                      |    FUP_INFO                                                  |                    |
|    AccountList    |    AccountId comma delimted                            |    AsOfNowUsage                                              |                    |

(For full, up-to-date details about specific entities and parameters, use the API Explorer)

## API Explorer

* AccountAPI

	* Unbilled

		AsOfNow<br>
		Summary<br>
		Detail<br>

	* Billed

		AsOfNow<br>
		Summary<br>
		Detail<br>

* InvoiceAPI<br>

	AsOfNow<br>
	Summary<br>
	Detail<br>

* FreeUnits API

	FUPINFO

* UnBilled Rentals API<br>

	AsOfNow

!!! Note "Unbilled rentals"
    Unbilled rentals will be for the full month without prorate the charges; proration logic not implemented in this API"
