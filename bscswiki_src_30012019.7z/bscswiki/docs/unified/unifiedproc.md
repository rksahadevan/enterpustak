# Unified Inquiry Procedures

## Unified Bill Inquiry

This is an Oracle Package and returns billing information as per invoice.  TIBCO invokes these procedures according to client requirements.  It support inquiry for one account at a time and consists of below main procedures:

| PROCEDURE NAME                       | DESCRIPTION                                 |
|--------------------------------------|---------------------------------------------|
| HEADER_INFO  | Provides invoice level summary                        |
| SUMMARY_INFO | Provides transaction breakup in the invoice                                   |
| DETAILS_INFO | Provides individual transaction details in the invoice             |
| CALL_DETAILS | Provides individual call details |
| FUP_INFO | Provides free units information for current month |
| USAGE_SUMMARY | Provides transaction breakup as per Mini Bill SMS format|

!!! Note "FUP_INFO supports free units inquiry only for the FU SHDES for which mapping available in EMCESU.T_BSCS_FUP_GROUP"

!!! Info "Object Information"

    Package name: UNIFIED_BILL_INQUIRY

    Procedure owner: BILL_ENQUIRY

    Clients: TIBCO/CBCM BIL

## Test Scripts

Follow below links to download the scripts to test the procedures in DB level:

[Header Info](UNIFIED_BILL_INQUIRY_HEADER_INFO.sql)

[Summary Info](UNIFIED_BILL_INQUIRY_SUMMARY_INFO.sql)

[Details Info](UNIFIED_BILL_INQUIRY_DETAILS_INFO.sql)

[Call Details](UNIFIED_BILL_INQUIRY_CALL_DETAILS.sql)

[FUP Info](UNIFIED_BILL_INQUIRY_FUP_INFO.sql)

## Unbilled Rental

This procedure being invoked by [unBilledRental REST API](../../unified/apiusage#unbilled-rental) to calculate unbilled rental charges.  It provides subscription change history and its price configuration for requested CO_CODE.

!!! Info "Object Information"

    Procedure name: UNBILLED_RENAL.GET_CURMONTH_SUBSCRIPTION

    Procedure owner: BILL_ENQUIRY

    Clients: CMS

!!! Notes "Test Script"

    Follow below link to download the scripts to test the procedures in DB level:

    [Unbilled Rental Subscription](UNBILLED_RENTAL_SUBSCRIPTION.sql)
