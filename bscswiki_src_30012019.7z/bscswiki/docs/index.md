# BSCS Wiki User Guide

## Scope of this Guide

This guide is for BSCS Dev, QA, and support users which cover all the customized functionality and interfaces exposed to client systems. In general, we try to cover the usage of API's and avoid duplicating the existing services in the user guide which the user can perform from BSCS system and also the process of testing or troubleshooting.  

It starts with a high level introduction to get you familiar with BSCS interfaces and customization. It covers setting up development environment for API interfaces, checking whether or not you actually need to implement your own custom code (i.e you can't achieve what you want through configuration or installing an already existing extension), best practice ways to extend current interfaces or re-use existing interface (a.k.a how to write an extension), things you should know before you start hacking on core, and best practice for testing.

For elife, it gives a clear mapping information from CRM subscription till invoice presentation and the rules used for presenting the invoice. This will help you to understand the business for each elife pakages and its presentation for the customer.

The guide also includes detailed references for tools and subsystems of interface development.  These cover topics like API usage with SOAP UI and POSTMAN and how to use with Unified Bill Interface.

## Editing this Guide

* For simple editing instructions, see contributing to this guide (publish shortly).
* For a more in-depth editing tutorial, see our page in Developer Guide on writing documentation (publish shortly).

## Credits

This guide is collaboratively written by the BSCS Development team, with facilitation from the project and Interface documents.
