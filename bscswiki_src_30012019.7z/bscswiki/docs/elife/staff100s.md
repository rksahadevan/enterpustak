## eLife - My Etisalat Plan - 100 MBPS - Senior Upgrade

## CRM Package Structure

Package Code: MKTTP11004SRSTF100MB

|    Components                         |    Production RP      |    Amount     |    Comments                                            |
|---------------------------------------|-----------------------|--------------:|--------------------------------------------------------|
|    Broadband   100 Mbps Speed         |    RP3PESRSTF100MB    |    540        |    This   is given by default and cannot be removed    |
|    Choice   Basic                     |    RP564671           |    0          |    This is   given by default and cannot be removed    |
|    Router                             |    RPDLINK803R24      |    10         |                                                        |
|    eLife   main set top box           |    RP636558           |    20         |    Recorder   - RP636539                               |
