## Additional components

|    Components                                      |    Rate plan    |    Amount    |    Comments                                                            |
|----------------------------------------------------|-----------------|-------------:|------------------------------------------------------------------------|
|    Non-Recorder   Additional STB                   |    RP636560     |    30        |                                                                        |
|    Recorder   Additional STB                       |    RP636561     |    40        |                                                                        |
|    Additional   WiFi Connector                     |    RP647259     |    10        |    This to be proposed if more than one room   WIFI option selected    |
|    Additional   TV Connected Room - PLC/Cabling    |    RP647258     |    5         |    This to be proposed if more than one room   STB option selected     |
