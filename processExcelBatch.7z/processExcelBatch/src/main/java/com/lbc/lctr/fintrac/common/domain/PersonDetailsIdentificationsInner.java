package com.lbc.lctr.fintrac.common.domain;

import java.util.Objects;

import javax.annotation.Generated;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.fasterxml.jackson.annotation.JsonValue;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * PersonDetailsIdentificationsInner
 */

@JsonTypeName("PersonDetails_identifications_inner")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-03-29T08:53:00.631912700-04:00[America/New_York]")
public class PersonDetailsIdentificationsInner {

  /**
   * * `1` - Birth certificate / Certificat de naissance * `2` - Passport / Passeport * `3` - Other / Autre * `4` - Driver license / Permis de conduire * `5` - Provincial health card / Carte d'assurance-maladie provinciale * `14` - Citizenship card / Carte de citoyenneté * `15` - Certificate of Indian Status / Certificat sécurisé de status d'Indien * `32` - Permanent resident card / Carte de résident permanent * `33` - Record of landing / Fiche d'établissement * `34` - Credit file / Dossier de crédit * `35` - Goverment issued identification / Document d'identité délivré par le gouvernement * `36` - Insurance documents / Documents d'assurance * `37` - Provincial or territorial identity card / Carte d'identité provinciale ou territoriale * `38` - Record of employment / Relevé d'emploi * `39` - Travel visa / Visa de voyage * `40` - Utility statement / Relevé de compte d'un service public 
   */
  public enum IdentifierTypeCodeEnum {
    NUMBER_1(1),
    
    NUMBER_2(2),
    
    NUMBER_3(3),
    
    NUMBER_4(4),
    
    NUMBER_5(5),
    
    NUMBER_14(14),
    
    NUMBER_15(15),
    
    NUMBER_32(32),
    
    NUMBER_33(33),
    
    NUMBER_34(34),
    
    NUMBER_35(35),
    
    NUMBER_36(36),
    
    NUMBER_37(37),
    
    NUMBER_38(38),
    
    NUMBER_39(39),
    
    NUMBER_40(40);

    private Integer value;

    IdentifierTypeCodeEnum(Integer value) {
      this.value = value;
    }

    @JsonValue
    public Integer getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static IdentifierTypeCodeEnum fromValue(Integer value) {
      for (IdentifierTypeCodeEnum b : IdentifierTypeCodeEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  @JsonProperty("identifierTypeCode")
  private IdentifierTypeCodeEnum identifierTypeCode;

  @JsonProperty("identifierTypeOther")
  private String identifierTypeOther;

  @JsonProperty("number")
  private String number;

  @JsonProperty("jurisdictionOfIssuerCountryCode")
  private CountryCode jurisdictionOfIssuerCountryCode;

  @JsonProperty("jurisdictionOfIssueProvinceStateCode")
  private ProvinceStateCode jurisdictionOfIssueProvinceStateCode;

  @JsonProperty("jurisdictionOfIssueProvinceStateName")
  private String jurisdictionOfIssueProvinceStateName;

  public PersonDetailsIdentificationsInner identifierTypeCode(IdentifierTypeCodeEnum identifierTypeCode) {
    this.identifierTypeCode = identifierTypeCode;
    return this;
  }

  /**
   * * `1` - Birth certificate / Certificat de naissance * `2` - Passport / Passeport * `3` - Other / Autre * `4` - Driver license / Permis de conduire * `5` - Provincial health card / Carte d'assurance-maladie provinciale * `14` - Citizenship card / Carte de citoyenneté * `15` - Certificate of Indian Status / Certificat sécurisé de status d'Indien * `32` - Permanent resident card / Carte de résident permanent * `33` - Record of landing / Fiche d'établissement * `34` - Credit file / Dossier de crédit * `35` - Goverment issued identification / Document d'identité délivré par le gouvernement * `36` - Insurance documents / Documents d'assurance * `37` - Provincial or territorial identity card / Carte d'identité provinciale ou territoriale * `38` - Record of employment / Relevé d'emploi * `39` - Travel visa / Visa de voyage * `40` - Utility statement / Relevé de compte d'un service public 
   * @return identifierTypeCode
  */
  @NotNull 
  @Schema(name = "identifierTypeCode", description = "* `1` - Birth certificate / Certificat de naissance * `2` - Passport / Passeport * `3` - Other / Autre * `4` - Driver license / Permis de conduire * `5` - Provincial health card / Carte d'assurance-maladie provinciale * `14` - Citizenship card / Carte de citoyenneté * `15` - Certificate of Indian Status / Certificat sécurisé de status d'Indien * `32` - Permanent resident card / Carte de résident permanent * `33` - Record of landing / Fiche d'établissement * `34` - Credit file / Dossier de crédit * `35` - Goverment issued identification / Document d'identité délivré par le gouvernement * `36` - Insurance documents / Documents d'assurance * `37` - Provincial or territorial identity card / Carte d'identité provinciale ou territoriale * `38` - Record of employment / Relevé d'emploi * `39` - Travel visa / Visa de voyage * `40` - Utility statement / Relevé de compte d'un service public ", requiredMode = Schema.RequiredMode.REQUIRED)
  public IdentifierTypeCodeEnum getIdentifierTypeCode() {
    return identifierTypeCode;
  }

  public void setIdentifierTypeCode(IdentifierTypeCodeEnum identifierTypeCode) {
    this.identifierTypeCode = identifierTypeCode;
  }

  public PersonDetailsIdentificationsInner identifierTypeOther(String identifierTypeOther) {
    this.identifierTypeOther = identifierTypeOther;
    return this;
  }

  /**
   * Get identifierTypeOther
   * @return identifierTypeOther
  */
  @Size(max = 200) 
  @Schema(name = "identifierTypeOther", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getIdentifierTypeOther() {
    return identifierTypeOther;
  }

  public void setIdentifierTypeOther(String identifierTypeOther) {
    this.identifierTypeOther = identifierTypeOther;
  }

  public PersonDetailsIdentificationsInner number(String number) {
    this.number = number;
    return this;
  }

  /**
   * Get number
   * @return number
  */
  @NotNull @Size(max = 100) 
  @Schema(name = "number", requiredMode = Schema.RequiredMode.REQUIRED)
  public String getNumber() {
    return number;
  }

  public void setNumber(String number) {
    this.number = number;
  }

  public PersonDetailsIdentificationsInner jurisdictionOfIssuerCountryCode(CountryCode jurisdictionOfIssuerCountryCode) {
    this.jurisdictionOfIssuerCountryCode = jurisdictionOfIssuerCountryCode;
    return this;
  }

  /**
   * Get jurisdictionOfIssuerCountryCode
   * @return jurisdictionOfIssuerCountryCode
  */
  @Valid 
  @Schema(name = "jurisdictionOfIssuerCountryCode", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public CountryCode getJurisdictionOfIssuerCountryCode() {
    return jurisdictionOfIssuerCountryCode;
  }

  public void setJurisdictionOfIssuerCountryCode(CountryCode jurisdictionOfIssuerCountryCode) {
    this.jurisdictionOfIssuerCountryCode = jurisdictionOfIssuerCountryCode;
  }

  public PersonDetailsIdentificationsInner jurisdictionOfIssueProvinceStateCode(ProvinceStateCode jurisdictionOfIssueProvinceStateCode) {
    this.jurisdictionOfIssueProvinceStateCode = jurisdictionOfIssueProvinceStateCode;
    return this;
  }

  /**
   * Get jurisdictionOfIssueProvinceStateCode
   * @return jurisdictionOfIssueProvinceStateCode
  */
  @Valid 
  @Schema(name = "jurisdictionOfIssueProvinceStateCode", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public ProvinceStateCode getJurisdictionOfIssueProvinceStateCode() {
    return jurisdictionOfIssueProvinceStateCode;
  }

  public void setJurisdictionOfIssueProvinceStateCode(ProvinceStateCode jurisdictionOfIssueProvinceStateCode) {
    this.jurisdictionOfIssueProvinceStateCode = jurisdictionOfIssueProvinceStateCode;
  }

  public PersonDetailsIdentificationsInner jurisdictionOfIssueProvinceStateName(String jurisdictionOfIssueProvinceStateName) {
    this.jurisdictionOfIssueProvinceStateName = jurisdictionOfIssueProvinceStateName;
    return this;
  }

  /**
   * Get jurisdictionOfIssueProvinceStateName
   * @return jurisdictionOfIssueProvinceStateName
  */
  @Size(max = 100) 
  @Schema(name = "jurisdictionOfIssueProvinceStateName", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getJurisdictionOfIssueProvinceStateName() {
    return jurisdictionOfIssueProvinceStateName;
  }

  public void setJurisdictionOfIssueProvinceStateName(String jurisdictionOfIssueProvinceStateName) {
    this.jurisdictionOfIssueProvinceStateName = jurisdictionOfIssueProvinceStateName;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PersonDetailsIdentificationsInner personDetailsIdentificationsInner = (PersonDetailsIdentificationsInner) o;
    return Objects.equals(this.identifierTypeCode, personDetailsIdentificationsInner.identifierTypeCode) &&
        Objects.equals(this.identifierTypeOther, personDetailsIdentificationsInner.identifierTypeOther) &&
        Objects.equals(this.number, personDetailsIdentificationsInner.number) &&
        Objects.equals(this.jurisdictionOfIssuerCountryCode, personDetailsIdentificationsInner.jurisdictionOfIssuerCountryCode) &&
        Objects.equals(this.jurisdictionOfIssueProvinceStateCode, personDetailsIdentificationsInner.jurisdictionOfIssueProvinceStateCode) &&
        Objects.equals(this.jurisdictionOfIssueProvinceStateName, personDetailsIdentificationsInner.jurisdictionOfIssueProvinceStateName);
  }

  @Override
  public int hashCode() {
    return Objects.hash(identifierTypeCode, identifierTypeOther, number, jurisdictionOfIssuerCountryCode, jurisdictionOfIssueProvinceStateCode, jurisdictionOfIssueProvinceStateName);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PersonDetailsIdentificationsInner {\n");
    sb.append("    identifierTypeCode: ").append(toIndentedString(identifierTypeCode)).append("\n");
    sb.append("    identifierTypeOther: ").append(toIndentedString(identifierTypeOther)).append("\n");
    sb.append("    number: ").append(toIndentedString(number)).append("\n");
    sb.append("    jurisdictionOfIssuerCountryCode: ").append(toIndentedString(jurisdictionOfIssuerCountryCode)).append("\n");
    sb.append("    jurisdictionOfIssueProvinceStateCode: ").append(toIndentedString(jurisdictionOfIssueProvinceStateCode)).append("\n");
    sb.append("    jurisdictionOfIssueProvinceStateName: ").append(toIndentedString(jurisdictionOfIssueProvinceStateName)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

