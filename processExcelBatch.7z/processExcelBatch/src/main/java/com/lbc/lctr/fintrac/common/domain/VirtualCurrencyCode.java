package com.lbc.lctr.fintrac.common.domain;

import javax.annotation.Generated;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

/**
 * * 'ZCN' - 0Chain / 0Chain * 'ZRX' - 0x / 0x * 'TSHP' - 12Ships / 12Ships * 'FST' - 1irstcoin / 1irstcoin * 'AAVE' - Aave / Aave * 'ABBC' - ABBC Coin / ABBC Coin * 'ADX' - AdEx Network / AdEx Network * 'AIB' - Advanced Internet Blocks / Advanced Internet Blocks * 'ELF' - aelf / aelf * 'AERGO' - Aergo / Aergo * 'AE' - Aeternity / Aeternity * 'AGVC' - AgaveCoin / AgaveCoin * 'AION' - Aion / Aion * 'AST' - AirSwap / AirSwap * 'AKRO' - Akropolis / Akropolis * 'ALGO' - Algorand / Algorand * 'AMO' - AMO Coin / AMO Coin * 'AMP' - Amp / Amp * 'AMPL' - Ampleforth / Ampleforth * 'ANCT' - Anchor / Anchor * 'ANKR' - Ankr / Ankr * 'APM' - apM Coin / apM Coin * 'APL' - Apollo Currency / Apollo Currency * 'ANT' - Aragon / Aragon * 'ARDR' - Ardor / Ardor * 'ARK' - Ark / Ark * 'ARPA' - ARPA Chain / ARPA Chain * 'AR' - Arweave / Arweave * 'ATT' - Attila / Attila * 'AUDIO' - Audius / Audius * 'REP' - Augur / Augur * 'AOA' - Aurora / Aurora * 'AVAX' - Avalanche / Avalanche * 'AXEL' - AXEL / AXEL * 'AXS' - Axie Infinity / Axie Infinity * 'B2B' - B2BX / B2BX * 'BRC' - Baer Chain / Baer Chain * 'BAL' - Balancer / Balancer * 'BNT' - Bancor / Bancor * 'BAND' - Band Protocol / Band Protocol * 'BNK' - Bankera / Bankera * 'BASIC' - BASIC / BASIC * 'BAT' - Basic Attention Token / Basic Attention Token * 'BASID' - Basid Coin / Basid Coin * 'BDCC' - BDCC Bitica COIN / BDCC Bitica COIN * 'BEAM' - Beam / Beam * 'BDX' - Beldex / Beldex * 'BEL' - Bella Protocol / Bella Protocol * 'BWF' - Beowulf / Beowulf * 'BHT' - BHEX Token / BHEX Token * 'BHP' - BHPCoin / BHPCoin * 'BIGONE' - BigONE Token / BigONE Token * 'BIKI' - BIKI / BIKI * 'BNB' - Binance Coin / Binance Coin * 'BUSD' - Binance USD / Binance USD * 'BTRS' - Bitball Treasure / Bitball Treasure * 'BXK' - Bitbook Gambling / Bitbook Gambling * 'BTC' - Bitcoin / Bitcoin * 'BTC2' - Bitcoin 2 / Bitcoin 2 * 'BTCB' - Bitcoin BEP2 / Bitcoin BEP2 * 'BCH' - Bitcoin Cash / Bitcoin Cash * 'BCD' - Bitcoin Diamond / Bitcoin Diamond * 'BTG' - Bitcoin Gold / Bitcoin Gold * 'BSV' - Bitcoin SV / Bitcoin SV * 'BHD' - BitcoinHD / BitcoinHD * 'BPS' - BitcoinPoS / BitcoinPoS * 'BHAO' - Bithao / Bithao * 'KAN' - BitKan / BitKan * 'BTMX' - BitMax Token / BitMax Token * 'BTS' - BitShares / BitShares * 'BTT' - BitTorrent / BitTorrent * 'BZ' - Bit-Z Token / Bit-Z Token * 'BLOCK' - Blocknet / Blocknet * 'STX' - Blockstack / Blockstack * 'BLCT' - Bloomzed Loyalty Club Ticket / Bloomzed Loyalty Club Ticket * 'BLZ' - Bluzelle / Bluzelle * 'BONO' - Bonorum / Bonorum * 'BORA' - BORA / BORA * 'BOA' - BOSAGORA / BOSAGORA * 'BOTX' - botXcoin / botXcoin * 'BOT' - Bounce Token / Bounce Token * 'BRZE' - Breezecoin / Breezecoin * 'BRG' - Bridge Oracle / Bridge Oracle * 'BTU' - BTU Protocol / BTU Protocol * 'BCZERO' - Buggyra Coin Zero / Buggyra Coin Zero * 'BCN' - Bytecoin / Bytecoin * 'BTM' - Bytom / Bytom * 'BZRX' - bZx Protocol / bZx Protocol * 'ADA' - Cardano / Cardano * 'CRE' - Carry / Carry * 'CELR' - Celer Network / Celer Network * 'CELO' - Celo / Celo * 'CUSD' - Celo Dollar / Celo Dollar * 'CEL' - Celsius / Celsius * 'CENNZ' - Centrality / Centrality * 'CTK' - CertiK / CertiK * 'LINK' - Chainlink / Chainlink * 'PCX' - ChainX / ChainX * 'CHZ' - Chiliz / Chiliz * 'BNANA' - Chimpion / Chimpion * 'CHR' - Chromia / Chromia * 'CND' - Cindicator / Cindicator * 'CIPHC' - Cipher Core Token / Cipher Core Token * 'CVC' - Civic / Civic * 'COCOS' - Cocos-BCX / Cocos-BCX * 'XCM' - CoinMetro Token / CoinMetro Token * 'COMP' - Compound / Compound * 'DAG' - Constellation / Constellation * 'CVNT' - Content Value Network / Content Value Network * 'COS' - Contentos / Contentos * 'CTCN' - CONTRACOIN / CONTRACOIN * 'CON' - CONUN / CONUN * 'CTXC' - Cortex / Cortex * 'ATOM' - Cosmos / Cosmos * 'COTI' - COTI / COTI * 'CCA' - Counos Coin / Counos Coin * 'CCXX' - Counos X / Counos X * 'CTC' - Creditcoin / Creditcoin * 'CRPT' - Crypterium / Crypterium * 'CVA' - Crypto Village Accelerator / Crypto Village Accelerator * 'CRO' - Crypto.com Coin / Crypto.com Coin * 'C20' - CRYPTO20 / CRYPTO20 * 'CIX100' - Cryptoindex.com 100 / Cryptoindex.com 100 * 'CNX'   -   Cryptonex / Cryptonex * 'CRV' - Curve DAO Token / Curve DAO Token * 'CORE' - cVault.finance / cVault.finance * 'CVT' - CyberVein / CyberVein * 'DAD' - DAD / DAD * 'DAI' - Dai / Dai * 'DEC' - Darico Ecosystem Coin / Darico Ecosystem Coin * 'DMCH' - Darma Cash / Darma Cash * 'RING' - Darwinia Network / Darwinia Network * 'DASH' - Dash / Dash * 'DAC' - Davinci Coin / Davinci Coin * 'MANA' - Decentraland / Decentraland * 'DCR' - Decred / Decred * 'DFI' - DeFiChain / DeFiChain * 'DENT' - Dent / Dent * 'YFII' - DFI.Money / DFI.Money * 'DIA' - DIA / DIA * 'DGB' - DigiByte / DigiByte * 'DGTX' - Digitex Futures / Digitex Futures * 'DGD' - DigixDAO / DigixDAO * 'DCY' - Dinastycoin / Dinastycoin * 'DNT' - district0x / district0x * 'DIVI' - Divi / Divi * 'DMG' - DMM: Governance / DMM: Governance * 'DRS' - Doctors Coin / Doctors Coin * 'DOGE' - Dogecoin / Dogecoin * 'DRGN' - Dragonchain / Dragonchain * 'DREP' - DREP / DREP * 'DUSK' - Dusk Network / Dusk Network * 'DX' - DxChain Token / DxChain Token * 'DTR' - Dynamic Trading Rights / Dynamic Trading Rights * 'ECOREAL' - Ecoreal Estate / Ecoreal Estate * 'EDC' - EDC Blockchain v1 [old] / EDC Blockchain v1 [old] * 'EMC2' - Einsteinium / Einsteinium * 'ELA' - Elastos / Elastos * 'ETN' - Electroneum / Electroneum * 'EUM' - Elitium / Elitium * 'EGLD' - Elrond / Elrond * 'NRG' - Energi / Energi * 'EWT' - Energy Web Token / Energy Web Token * 'ENG' - Enigma / Enigma * 'ENJ' - Enjin Coin / Enjin Coin * 'EVN' - Envion / Envion * 'EOS' - EOS / EOS * 'ERC20' - ERC20 / ERC20 * 'ERG' - Ergo / Ergo * 'ETH' - Ethereum / Ethereum * 'ETC' - Ethereum Classic / Ethereum Classic * 'DIP' - Etherisc DIP Token / Etherisc DIP Token * 'IQ' - Everipedia / Everipedia * 'EVR' - Everus / Everus * 'XT' - ExtStock Token / ExtStock Token * 'FAB' - FABRK / FABRK * 'FTM' - Fantom / Fantom * 'FET' - Fetch.ai / Fetch.ai * 'FIL' - Filecoin / Filecoin * 'FLM' - Flamingo / Flamingo * 'FXC' - Flexacoin / Flexacoin * 'FNB' - FNB Protocol / FNB Protocol * 'FLG' - Folgory Coin / Folgory Coin * 'FTT' - FTX Token / FTX Token * 'FX' - Function X / Function X * 'FUN' - FunFair / FunFair * 'FSN' - Fusion / Fusion * 'GAS' - Gas / Gas * 'GT' - GateToken / GateToken * 'GUSD' - Gemini Dollar / Gemini Dollar * 'GLEEC' - Gleec / Gleec * 'GNO' - Gnosis / Gnosis * 'GNT' - Golem / Golem * 'GRN' - GreenPower / GreenPower * 'GRIN' - Grin / Grin * 'GRS' - Groestlcoin / Groestlcoin * 'GXC' - GXChain / GXChain * 'HNS' - Handshake  / Handshake  * 'ONE' - Harmony / Harmony * 'FARM' - Harvest Finance / Harvest Finance * 'GARD' - Hashgard / Hashgard * 'XHV' - Haven Protocol / Haven Protocol * 'HBAR' - Hedera Hashgraph / Hedera Hashgraph * 'HEDG' - HedgeTrade / HedgeTrade * 'HNT' - Helium / Helium * 'HNC' - Hellenic Coin / Hellenic Coin * 'HSN' - Helper Search Token / Helper Search Token * 'HEX' - HEX / HEX * 'HIVE' - Hive / Hive * 'HOT' - Holo / Holo * 'HMR' - Homeros / Homeros * 'ZEN' - Horizen / Horizen * 'HBTC' - Huobi BTC / Huobi BTC * 'HPT' - Huobi Pool Token / Huobi Pool Token * 'HT' - Huobi Token / Huobi Token * 'HUSD' - HUSD / HUSD * 'HXRO' - Hxro / Hxro * 'HC' - HyperCash / HyperCash * 'HYN' - Hyperion / Hyperion * 'ICX' - ICON / ICON * 'ICH' - Idea Chain Coin / Idea Chain Coin * 'IDEX' - IDEX / IDEX * 'RLC' - iExec RLC / iExec RLC * 'IGNIS' - Ignis / Ignis * 'INJ' - Injective Protocol / Injective Protocol * 'INO' - INO COIN / INO COIN * 'INB' - Insight Chain / Insight Chain * 'INSTAR' - Insights Network / Insights Network * 'IHF' - Invictus Hyperion Fund / Invictus Hyperion Fund * 'IOST' - IOST / IOST * 'MIOTA' - IOTA / IOTA * 'IOTX' - IoTeX / IoTeX * 'IRIS' - IRISnet / IRISnet * 'IZE' - IZE / IZE * 'JWL' - Jewel / Jewel * 'JUL' - Joule / Joule * 'JST' - JUST / JUST * 'KBC' - Karatgold Coin / Karatgold Coin * 'KAI' - KardiaChain / KardiaChain * 'KAVA' - Kava.io / Kava.io * 'KCASH' - Kcash / Kcash * 'KEEP' - Keep Network / Keep Network * 'KP3R' - Keep3rV1 / Keep3rV1 * 'KIN' - Kin / Kin * 'KDAG' - King DAG / King DAG * 'PNK' - Kleros / Kleros * 'KMD' - Komodo / Komodo * 'KCS' - KuCoin Shares / KuCoin Shares * 'KSM' - Kusama / Kusama * 'KNC' - Kyber Network / Kyber Network * 'LAMB' - Lambda / Lambda * 'LRG' - Largo Coin / Largo Coin * 'LA' - LATOKEN / LATOKEN * 'LBC' - LBRY Credits / LBRY Credits * 'LVX' - Level01 / Level01 * 'LEVL' - Levolution / Levolution * 'LSK' - Lisk / Lisk * 'LTC' - Litecoin / Litecoin * 'LPT' - Livepeer / Livepeer * 'LOKI' - Loki / Loki * 'LOOM' - Loom Network / Loom Network * 'LRC' - Loopring / Loopring * 'LTO' - LTO Network / LTO Network * 'MAID' - MaidSafeCoin / MaidSafeCoin * 'MFT' - Mainframe / Mainframe * 'MKR' - Maker / Maker * 'MASS' - Massnet / Massnet * 'MATH' - MATH / MATH * 'MATIC' - Matic Network / Matic Network * 'MCO' - MCO / MCO * 'MED' - MediBloc / MediBloc * 'MLN' - Melon / Melon * 'MTA' - Meta / Meta * 'MTC' - Metacoin / Metacoin * 'MTL' - Metal / Metal * 'DNA' - Metaverse Dualchain Network Architecture / Metaverse Dualchain Network Architecture * 'MLK' - MiL.k / MiL.k * 'MWC' - MimbleWimbleCoin / MimbleWimbleCoin * 'MIN' - MINDOL / MINDOL * 'XIN' - Mixin / Mixin * 'MBN' - Mobilian Coin / Mobilian Coin * 'MDA' - Moeda Loyalty Points / Moeda Loyalty Points * 'MOF' - Molecular Future / Molecular Future * 'MONA' - MonaCoin / MonaCoin * 'XMR' - Monero / Monero * 'MRPH' - Morpheus.Network / Morpheus.Network * 'MBL' - MovieBloc / MovieBloc * 'MUSD' - mStable USD / mStable USD * 'MVL' - MVL / MVL * 'MX' - MX Token / MX Token * 'MXC' - MXC / MXC * 'NANO' - Nano / Nano * 'NEX' - Nash Exchange / Nash Exchange * 'NUT' - Native Utility Token / Native Utility Token * 'NEAR' - NEAR Protocol / NEAR Protocol * 'NAS' - Nebulas / Nebulas * 'NEC' - Nectar / Nectar * 'XEM' - NEM / NEM * 'NEO' - Neo / Neo * 'NVT' - NerveNetwork / NerveNetwork * 'CKB' - Nervos Network / Nervos Network * 'NEST' - NEST Protocol / NEST Protocol * 'USDN' - Neutrino USD / Neutrino USD * 'NWC' - Newscrypto / Newscrypto * 'NYE' - NewYork Exchange / NewYork Exchange * 'XLT' - Nexalt / Nexalt * 'NEXO' - Nexo / Nexo * 'NXS' - Nexus / Nexus * 'NEXXO' - Nexxo / Nexxo * 'NIM' - Nimiq / Nimiq * 'NKN' - NKN / NKN * 'NOIA' - NOIA Network / NOIA Network * 'NU' - NuCypher / NuCypher * 'NULS' - NULS / NULS * 'NMR' - Numeraire / Numeraire * 'NXM' - NXM / NXM * 'GBYTE' - Obyte / Obyte * 'OCEAN' - Ocean Protocol / Ocean Protocol * 'OCTO' - OctoFi / OctoFi * 'OKB' - OKB / OKB * 'OMG' - OMG Network / OMG Network * 'ONOT' - ONOToken / ONOToken * 'ONT' - Ontology / Ontology * 'ORC' - Orbit Chain / Orbit Chain * 'ORBS' - Orbs / Orbs * 'OXT' - Orchid / Orchid * 'OGN' - Origin Protocol / Origin Protocol * 'TRAC' - OriginTrail / OriginTrail * 'ORN' - Orion Protocol / Orion Protocol * 'CAKE' - PancakeSwap / PancakeSwap * 'PRQ' - PARSIQ / PARSIQ * 'PAXG' - PAX Gold / PAX Gold * 'PAX' - Paxos Standard / Paxos Standard * 'PCN' - PeepCoin / PeepCoin * 'PERL' - Perlin / Perlin * 'PERP' - Perpetual Protocol / Perpetual Protocol * 'PHA' - Phala.Network / Phala.Network * 'ARRR' - Pirate Chain / Pirate Chain * 'PIVX' - PIVX / PIVX * 'PLC' - PLATINCOIN / PLATINCOIN * 'PLF' - PlayFuel / PlayFuel * 'DOT' - Polkadot / Polkadot * 'POLY' - Polymath / Polymath * 'PPT' - Populous / Populous * 'QQQ' - Poseidon Network / Poseidon Network * 'POWR' - Power Ledger / Power Ledger * 'PZM' - PRIZM / PRIZM * 'PAI' - Project Pai / Project Pai * 'PROM' - Prometeus / Prometeus * 'XPR' - Proton / Proton * 'NPXS' - Pundi X / Pundi X * 'QASH' - QASH / QASH * 'QC' - Qcash / Qcash * 'QTUM' - Qtum / Qtum * 'QNT' - Quant / Quant * 'QSP' - Quantstamp / Quantstamp * 'QRL' - Quantum Resistant Ledger / Quantum Resistant Ledger * 'QRK' - Quark / Quark * 'QKC' - QuarkChain / QuarkChain * 'RDN' - Raiden Network Token / Raiden Network Token * 'RKN' - Rakon / Rakon * 'RVN' - Ravencoin / Ravencoin * 'RCHAINREV' - RChain / RChain * 'RDD' - ReddCoin / ReddCoin * 'REN' - Ren / Ren * 'RENBTC' - renBTC / renBTC * 'RNDR' - Render Token / Render Token * 'REPO' - REPO / REPO * 'REQ' - Request / Request * 'RSR' - Reserve Rights / Reserve Rights * 'REV' - Revain / Revain * 'RCN' - Ripio Credit Network / Ripio Credit Network * 'RPL' - Rocket Pool / Rocket Pool * 'RIF' - RSK Infrastructure Framework / RSK Infrastructure Framework * 'S4F' - S4FE / S4FE * 'SLS' - SaluS / SaluS * 'SAPP' - Sapphire / Sapphire * 'SCRT' - Secret / Secret * 'SEELE' - Seele-N / Seele-N * 'SNTVT' - Sentivate / Sentivate * 'SRM' - Serum / Serum * 'SHR' - ShareToken / ShareToken * 'SC' - Siacoin / Siacoin * 'AGI' - SingularityNET / SingularityNET * 'SOL' - Solana / Solana * 'SOLO' - Sologenic / Sologenic * 'SOLVE' - SOLVE / SOLVE * 'XOR' - Sora / Sora * 'SPND' - Spendcoin / Spendcoin * 'SNL' - Sport and Leisure / Sport and Leisure * 'XSN' - Stakenet / Stakenet * 'STPT' - Standard Tokenization Protocol / Standard Tokenization Protocol * 'EURS' - STASIS EURO / STASIS EURO * 'SNT' - Status / Status * 'STEEM' - Steem / Steem * 'XLM' - Stellar / Stellar * 'SCC' - STEM CELL COIN / STEM CELL COIN * 'STORJ' - Storj / Storj * 'STMX' - StormX / StormX * 'STP' - STPAY / STPAY * 'STRAT' - Stratis / Stratis * 'DATA' - Streamr / Streamr * 'STRONG' - Strong / Strong * 'SUKU' - SUKU / SUKU * 'SUN' - SUN / SUN * 'SERO' - Super Zero Protocol / Super Zero Protocol * 'SUSD' - sUSD / sUSD * 'SUSHI' - SushiSwap / SushiSwap * 'SWINGBY' - Swingby / Swingby * 'SXP' - Swipe / Swipe * 'CHSB' - SwissBorg / SwissBorg * 'SWTH' - Switcheo / Switcheo * 'SNB' - SynchroBitcoin / SynchroBitcoin * 'SNX' - Synthetix / Synthetix * 'SYS' - Syscoin / Syscoin * 'IPX' - Tachyon Protocol / Tachyon Protocol * 'XTP' - Tap / Tap * 'TRB' - Tellor / Tellor * 'LUNA' - Terra / Terra * 'KRT' - TerraKRW / TerraKRW * 'USDT' - Tether / Tether * 'XTZ' - Tezos / Tezos * 'TMTG' - The Midas Touch Gold / The Midas Touch Gold * 'SAND' - The Sandbox / The Sandbox * 'TTT' - The Transfer Token / The Transfer Token * 'THETA' - THETA / THETA * 'TFUEL' - Theta Fuel / Theta Fuel * 'RUNE' - THORChain / THORChain * 'THR' - ThoreCoin / ThoreCoin * 'THX' - ThoreNext / ThoreNext * 'TT' - Thunder Token / Thunder Token * 'TITAN' - TitanSwap / TitanSwap * 'MTXLT' - Tixl / Tixl * 'TNC' - TNC Coin / TNC Coin * 'TOMO' - TomoChain / TomoChain * 'TRAT' - Tratin / Tratin * 'AVA' - Travala.com / Travala.com * 'TRX' - TRON / TRON * 'TROY' - TROY / TROY * 'TRUE' - TrueChain / TrueChain * 'TUSD' - TrueUSD / TrueUSD * 'TWT' - Trust Wallet Token / Trust Wallet Token * 'SWAP' - TrustSwap / TrustSwap * 'ULT' - Ultiledger / Ultiledger * 'UOS' - Ultra / Ultra * 'UMA' - UMA / UMA * 'UNICOIN' - UNI COIN / UNI COIN * 'UBT' - Unibright / Unibright * 'UNI' - Uniswap / Uniswap * 'UNO' - Unobtanium / Unobtanium * 'LEO' - UNUS SED LEO / UNUS SED LEO * 'UQC' - Uquid Coin / Uquid Coin * 'USDC' - USD Coin / USD Coin * 'USDJ' - USDJ / USDJ * 'USDK' - USDK / USDK * 'UTK' - Utrust / Utrust * 'VSYS' - v.systems / v.systems * 'VET' - VeChain / VeChain * 'VLX' - Velas / Velas * 'XVS' - Venus / Venus * 'XVG' - Verge / Verge * 'VRSC' - VerusCoin / VerusCoin * 'VEST' - VestChain / VestChain * 'VTHO' - VeThor Token / VeThor Token * 'VIDT' - VIDT Datalink / VIDT Datalink * 'VITAE' - Vitae / Vitae * 'VGX' - Voyager Token / Voyager Token * 'WAN' - Wanchain / Wanchain * 'WAVES' - Waves / Waves * 'WAXP' - WAX / WAX * 'WICC' - WaykiChain / WaykiChain * 'WRX' - WazirX / WazirX * 'WET' - WeShow Token / WeShow Token * 'XWC' - WhiteCoin / WhiteCoin * 'WIN' - WINk / WINk * 'WXT' - Wirex Token / Wirex Token * 'WIX' - Wixlar / Wixlar * 'WOM' - WOM Protocol / WOM Protocol * 'WBTC' - Wrapped Bitcoin / Wrapped Bitcoin * 'WBNB' - Wrapped BNB / Wrapped BNB * 'STAKE' - xDai / xDai * 'XNC' - XeniosCoin / XeniosCoin * 'XSR' - Xensor / Xensor * 'XDC' - XinFin Network / XinFin Network * 'XRP' - XRP / XRP * 'YFI' - yearn.finance / yearn.finance * 'YEP' - YEP COIN / YEP COIN * 'YFL' - YF Link / YF Link * 'YF-DAI' - YFDAI.FINANCE / YFDAI.FINANCE * 'SAFE' - yieldfarming.insure / yieldfarming.insure * 'YUSRA' - YUSRA / YUSRA * 'ZAP' - Zap / Zap * 'ZB' - ZB Token / ZB Token * 'ZT' - ZBG Token / ZBG Token * 'ZEC' - Zcash / Zcash * 'XZC' - Zcoin / Zcoin * 'ZLW' - Zelwin / Zelwin * 'ZNN' - Zenon / Zenon * 'ZIL' - Zilliqa / Zilliqa * 'ZYN' - Zynecoin / Zynecoin * 'OTH' - Other / Fr-Other 
 */

@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-03-29T08:53:00.631912700-04:00[America/New_York]")
public enum VirtualCurrencyCode {
  
  ZCN("ZCN"),
  
  ZRX("ZRX"),
  
  TSHP("TSHP"),
  
  FST("FST"),
  
  AAVE("AAVE"),
  
  ABBC("ABBC"),
  
  ADX("ADX"),
  
  AIB("AIB"),
  
  ELF("ELF"),
  
  AERGO("AERGO"),
  
  AE("AE"),
  
  AGVC("AGVC"),
  
  AION("AION"),
  
  AST("AST"),
  
  AKRO("AKRO"),
  
  ALGO("ALGO"),
  
  AMO("AMO"),
  
  AMP("AMP"),
  
  AMPL("AMPL"),
  
  ANCT("ANCT"),
  
  ANKR("ANKR"),
  
  APM("APM"),
  
  APL("APL"),
  
  ANT("ANT"),
  
  ARDR("ARDR"),
  
  ARK("ARK"),
  
  ARPA("ARPA"),
  
  AR("AR"),
  
  ATT("ATT"),
  
  AUDIO("AUDIO"),
  
  REP("REP"),
  
  AOA("AOA"),
  
  AVAX("AVAX"),
  
  AXEL("AXEL"),
  
  AXS("AXS"),
  
  B2B("B2B"),
  
  BRC("BRC"),
  
  BAL("BAL"),
  
  BNT("BNT"),
  
  BAND("BAND"),
  
  BNK("BNK"),
  
  BASIC("BASIC"),
  
  BAT("BAT"),
  
  BASID("BASID"),
  
  BDCC("BDCC"),
  
  BEAM("BEAM"),
  
  BDX("BDX"),
  
  BEL("BEL"),
  
  BWF("BWF"),
  
  BHT("BHT"),
  
  BHP("BHP"),
  
  BIGONE("BIGONE"),
  
  BIKI("BIKI"),
  
  BNB("BNB"),
  
  BUSD("BUSD"),
  
  BTRS("BTRS"),
  
  BXK("BXK"),
  
  BTC("BTC"),
  
  BTC2("BTC2"),
  
  BTCB("BTCB"),
  
  BCH("BCH"),
  
  BCD("BCD"),
  
  BTG("BTG"),
  
  BSV("BSV"),
  
  BHD("BHD"),
  
  BPS("BPS"),
  
  BHAO("BHAO"),
  
  KAN("KAN"),
  
  BTMX("BTMX"),
  
  BTS("BTS"),
  
  BTT("BTT"),
  
  BZ("BZ"),
  
  BLOCK("BLOCK"),
  
  STX("STX"),
  
  BLCT("BLCT"),
  
  BLZ("BLZ"),
  
  BONO("BONO"),
  
  BORA("BORA"),
  
  BOA("BOA"),
  
  BOTX("BOTX"),
  
  BOT("BOT"),
  
  BRZE("BRZE"),
  
  BRG("BRG"),
  
  BTU("BTU"),
  
  BCZERO("BCZERO"),
  
  BCN("BCN"),
  
  BTM("BTM"),
  
  BZRX("BZRX"),
  
  ADA("ADA"),
  
  CRE("CRE"),
  
  CELR("CELR"),
  
  CELO("CELO"),
  
  CUSD("CUSD"),
  
  CEL("CEL"),
  
  CENNZ("CENNZ"),
  
  CTK("CTK"),
  
  LINK("LINK"),
  
  PCX("PCX"),
  
  CHZ("CHZ"),
  
  BNANA("BNANA"),
  
  CHR("CHR"),
  
  CND("CND"),
  
  CIPHC("CIPHC"),
  
  CVC("CVC"),
  
  COCOS("COCOS"),
  
  XCM("XCM"),
  
  COMP("COMP"),
  
  DAG("DAG"),
  
  CVNT("CVNT"),
  
  COS("COS"),
  
  CTCN("CTCN"),
  
  CON("CON"),
  
  CTXC("CTXC"),
  
  ATOM("ATOM"),
  
  COTI("COTI"),
  
  CCA("CCA"),
  
  CCXX("CCXX"),
  
  CTC("CTC"),
  
  CRPT("CRPT"),
  
  CVA("CVA"),
  
  CRO("CRO"),
  
  C20("C20"),
  
  CIX100("CIX100"),
  
  CNX("CNX"),
  
  CRV("CRV"),
  
  CORE("CORE"),
  
  CVT("CVT"),
  
  DAD("DAD"),
  
  DAI("DAI"),
  
  DEC("DEC"),
  
  DMCH("DMCH"),
  
  RING("RING"),
  
  DASH("DASH"),
  
  DAC("DAC"),
  
  MANA("MANA"),
  
  DCR("DCR"),
  
  DFI("DFI"),
  
  DENT("DENT"),
  
  YFII("YFII"),
  
  DIA("DIA"),
  
  DGB("DGB"),
  
  DGTX("DGTX"),
  
  DGD("DGD"),
  
  DCY("DCY"),
  
  DNT("DNT"),
  
  DIVI("DIVI"),
  
  DMG("DMG"),
  
  DRS("DRS"),
  
  DOGE("DOGE"),
  
  DRGN("DRGN"),
  
  DREP("DREP"),
  
  DUSK("DUSK"),
  
  DX("DX"),
  
  DTR("DTR"),
  
  ECOREAL("ECOREAL"),
  
  EDC("EDC"),
  
  EMC2("EMC2"),
  
  ELA("ELA"),
  
  ETN("ETN"),
  
  EUM("EUM"),
  
  EGLD("EGLD"),
  
  NRG("NRG"),
  
  EWT("EWT"),
  
  ENG("ENG"),
  
  ENJ("ENJ"),
  
  EVN("EVN"),
  
  EOS("EOS"),
  
  ERC20("ERC20"),
  
  ERG("ERG"),
  
  ETH("ETH"),
  
  ETC("ETC"),
  
  DIP("DIP"),
  
  IQ("IQ"),
  
  EVR("EVR"),
  
  XT("XT"),
  
  FAB("FAB"),
  
  FTM("FTM"),
  
  FET("FET"),
  
  FIL("FIL"),
  
  FLM("FLM"),
  
  FXC("FXC"),
  
  FNB("FNB"),
  
  FLG("FLG"),
  
  FTT("FTT"),
  
  FX("FX"),
  
  FUN("FUN"),
  
  FSN("FSN"),
  
  GAS("GAS"),
  
  GT("GT"),
  
  GUSD("GUSD"),
  
  GLEEC("GLEEC"),
  
  GNO("GNO"),
  
  GNT("GNT"),
  
  GRN("GRN"),
  
  GRIN("GRIN"),
  
  GRS("GRS"),
  
  GXC("GXC"),
  
  HNS("HNS"),
  
  ONE("ONE"),
  
  FARM("FARM"),
  
  GARD("GARD"),
  
  XHV("XHV"),
  
  HBAR("HBAR"),
  
  HEDG("HEDG"),
  
  HNT("HNT"),
  
  HNC("HNC"),
  
  HSN("HSN"),
  
  HEX("HEX"),
  
  HIVE("HIVE"),
  
  HOT("HOT"),
  
  HMR("HMR"),
  
  ZEN("ZEN"),
  
  HBTC("HBTC"),
  
  HPT("HPT"),
  
  HT("HT"),
  
  HUSD("HUSD"),
  
  HXRO("HXRO"),
  
  HC("HC"),
  
  HYN("HYN"),
  
  ICX("ICX"),
  
  ICH("ICH"),
  
  IDEX("IDEX"),
  
  RLC("RLC"),
  
  IGNIS("IGNIS"),
  
  INJ("INJ"),
  
  INO("INO"),
  
  INB("INB"),
  
  INSTAR("INSTAR"),
  
  IHF("IHF"),
  
  IOST("IOST"),
  
  MIOTA("MIOTA"),
  
  IOTX("IOTX"),
  
  IRIS("IRIS"),
  
  IZE("IZE"),
  
  JWL("JWL"),
  
  JUL("JUL"),
  
  JST("JST"),
  
  KBC("KBC"),
  
  KAI("KAI"),
  
  KAVA("KAVA"),
  
  KCASH("KCASH"),
  
  KEEP("KEEP"),
  
  KP3R("KP3R"),
  
  KIN("KIN"),
  
  KDAG("KDAG"),
  
  PNK("PNK"),
  
  KMD("KMD"),
  
  KCS("KCS"),
  
  KSM("KSM"),
  
  KNC("KNC"),
  
  LAMB("LAMB"),
  
  LRG("LRG"),
  
  LA("LA"),
  
  LBC("LBC"),
  
  LVX("LVX"),
  
  LEVL("LEVL"),
  
  LSK("LSK"),
  
  LTC("LTC"),
  
  LPT("LPT"),
  
  LOKI("LOKI"),
  
  LOOM("LOOM"),
  
  LRC("LRC"),
  
  LTO("LTO"),
  
  MAID("MAID"),
  
  MFT("MFT"),
  
  MKR("MKR"),
  
  MASS("MASS"),
  
  MATH("MATH"),
  
  MATIC("MATIC"),
  
  MCO("MCO"),
  
  MED("MED"),
  
  MLN("MLN"),
  
  MTA("MTA"),
  
  MTC("MTC"),
  
  MTL("MTL"),
  
  DNA("DNA"),
  
  MLK("MLK"),
  
  MWC("MWC"),
  
  MIN("MIN"),
  
  XIN("XIN"),
  
  MBN("MBN"),
  
  MDA("MDA"),
  
  MOF("MOF"),
  
  MONA("MONA"),
  
  XMR("XMR"),
  
  MRPH("MRPH"),
  
  MBL("MBL"),
  
  MUSD("MUSD"),
  
  MVL("MVL"),
  
  MX("MX"),
  
  MXC("MXC"),
  
  NANO("NANO"),
  
  NEX("NEX"),
  
  NUT("NUT"),
  
  NEAR("NEAR"),
  
  NAS("NAS"),
  
  NEC("NEC"),
  
  XEM("XEM"),
  
  NEO("NEO"),
  
  NVT("NVT"),
  
  CKB("CKB"),
  
  NEST("NEST"),
  
  USDN("USDN"),
  
  NWC("NWC"),
  
  NYE("NYE"),
  
  XLT("XLT"),
  
  NEXO("NEXO"),
  
  NXS("NXS"),
  
  NEXXO("NEXXO"),
  
  NIM("NIM"),
  
  NKN("NKN"),
  
  NOIA("NOIA"),
  
  NU("NU"),
  
  NULS("NULS"),
  
  NMR("NMR"),
  
  NXM("NXM"),
  
  GBYTE("GBYTE"),
  
  OCEAN("OCEAN"),
  
  OCTO("OCTO"),
  
  OKB("OKB"),
  
  OMG("OMG"),
  
  ONOT("ONOT"),
  
  ONT("ONT"),
  
  ORC("ORC"),
  
  ORBS("ORBS"),
  
  OXT("OXT"),
  
  OGN("OGN"),
  
  TRAC("TRAC"),
  
  ORN("ORN"),
  
  CAKE("CAKE"),
  
  PRQ("PRQ"),
  
  PAXG("PAXG"),
  
  PAX("PAX"),
  
  PCN("PCN"),
  
  PERL("PERL"),
  
  PERP("PERP"),
  
  PHA("PHA"),
  
  ARRR("ARRR"),
  
  PIVX("PIVX"),
  
  PLC("PLC"),
  
  PLF("PLF"),
  
  DOT("DOT"),
  
  POLY("POLY"),
  
  PPT("PPT"),
  
  QQQ("QQQ"),
  
  POWR("POWR"),
  
  PZM("PZM"),
  
  PAI("PAI"),
  
  PROM("PROM"),
  
  XPR("XPR"),
  
  NPXS("NPXS"),
  
  QASH("QASH"),
  
  QC("QC"),
  
  QTUM("QTUM"),
  
  QNT("QNT"),
  
  QSP("QSP"),
  
  QRL("QRL"),
  
  QRK("QRK"),
  
  QKC("QKC"),
  
  RDN("RDN"),
  
  RKN("RKN"),
  
  RVN("RVN"),
  
  RCHAINREV("RCHAINREV"),
  
  RDD("RDD"),
  
  REN("REN"),
  
  RENBTC("RENBTC"),
  
  RNDR("RNDR"),
  
  REPO("REPO"),
  
  REQ("REQ"),
  
  RSR("RSR"),
  
  REV("REV"),
  
  RCN("RCN"),
  
  RPL("RPL"),
  
  RIF("RIF"),
  
  S4F("S4F"),
  
  SLS("SLS"),
  
  SAPP("SAPP"),
  
  SCRT("SCRT"),
  
  SEELE("SEELE"),
  
  SNTVT("SNTVT"),
  
  SRM("SRM"),
  
  SHR("SHR"),
  
  SC("SC"),
  
  AGI("AGI"),
  
  SOL("SOL"),
  
  SOLO("SOLO"),
  
  SOLVE("SOLVE"),
  
  XOR("XOR"),
  
  SPND("SPND"),
  
  SNL("SNL"),
  
  XSN("XSN"),
  
  STPT("STPT"),
  
  EURS("EURS"),
  
  SNT("SNT"),
  
  STEEM("STEEM"),
  
  XLM("XLM"),
  
  SCC("SCC"),
  
  STORJ("STORJ"),
  
  STMX("STMX"),
  
  STP("STP"),
  
  STRAT("STRAT"),
  
  DATA("DATA"),
  
  STRONG("STRONG"),
  
  SUKU("SUKU"),
  
  SUN("SUN"),
  
  SERO("SERO"),
  
  SUSD("SUSD"),
  
  SUSHI("SUSHI"),
  
  SWINGBY("SWINGBY"),
  
  SXP("SXP"),
  
  CHSB("CHSB"),
  
  SWTH("SWTH"),
  
  SNB("SNB"),
  
  SNX("SNX"),
  
  SYS("SYS"),
  
  IPX("IPX"),
  
  XTP("XTP"),
  
  TRB("TRB"),
  
  LUNA("LUNA"),
  
  KRT("KRT"),
  
  USDT("USDT"),
  
  XTZ("XTZ"),
  
  TMTG("TMTG"),
  
  SAND("SAND"),
  
  TTT("TTT"),
  
  THETA("THETA"),
  
  TFUEL("TFUEL"),
  
  RUNE("RUNE"),
  
  THR("THR"),
  
  THX("THX"),
  
  TT("TT"),
  
  TITAN("TITAN"),
  
  MTXLT("MTXLT"),
  
  TNC("TNC"),
  
  TOMO("TOMO"),
  
  TRAT("TRAT"),
  
  AVA("AVA"),
  
  TRX("TRX"),
  
  TROY("TROY"),
  
  TRUE("TRUE"),
  
  TUSD("TUSD"),
  
  TWT("TWT"),
  
  SWAP("SWAP"),
  
  ULT("ULT"),
  
  UOS("UOS"),
  
  UMA("UMA"),
  
  UNICOIN("UNICOIN"),
  
  UBT("UBT"),
  
  UNI("UNI"),
  
  UNO("UNO"),
  
  LEO("LEO"),
  
  UQC("UQC"),
  
  USDC("USDC"),
  
  USDJ("USDJ"),
  
  USDK("USDK"),
  
  UTK("UTK"),
  
  VSYS("VSYS"),
  
  VET("VET"),
  
  VLX("VLX"),
  
  XVS("XVS"),
  
  XVG("XVG"),
  
  VRSC("VRSC"),
  
  VEST("VEST"),
  
  VTHO("VTHO"),
  
  VIDT("VIDT"),
  
  VITAE("VITAE"),
  
  VGX("VGX"),
  
  WAN("WAN"),
  
  WAVES("WAVES"),
  
  WAXP("WAXP"),
  
  WICC("WICC"),
  
  WRX("WRX"),
  
  WET("WET"),
  
  XWC("XWC"),
  
  WIN("WIN"),
  
  WXT("WXT"),
  
  WIX("WIX"),
  
  WOM("WOM"),
  
  WBTC("WBTC"),
  
  WBNB("WBNB"),
  
  STAKE("STAKE"),
  
  XNC("XNC"),
  
  XSR("XSR"),
  
  XDC("XDC"),
  
  XRP("XRP"),
  
  YFI("YFI"),
  
  YEP("YEP"),
  
  YFL("YFL"),
  
  YF_DAI("YF-DAI"),
  
  SAFE("SAFE"),
  
  YUSRA("YUSRA"),
  
  ZAP("ZAP"),
  
  ZB("ZB"),
  
  ZT("ZT"),
  
  ZEC("ZEC"),
  
  XZC("XZC"),
  
  ZLW("ZLW"),
  
  ZNN("ZNN"),
  
  ZIL("ZIL"),
  
  ZYN("ZYN"),
  
  OTH("OTH");

  private String value;

  VirtualCurrencyCode(String value) {
    this.value = value;
  }

  @JsonValue
  public String getValue() {
    return value;
  }

  @Override
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static VirtualCurrencyCode fromValue(String value) {
    for (VirtualCurrencyCode b : VirtualCurrencyCode.values()) {
      if (b.value.equals(value)) {
        return b;
      }
    }
    throw new IllegalArgumentException("Unexpected value '" + value + "'");
  }
}

