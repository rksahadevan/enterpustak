package com.lbc.lctr.fintrac.mapper;

import java.sql.Clob;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.springframework.batch.item.database.ItemPreparedStatementSetter;
import org.springframework.jdbc.core.support.SqlLobValue;

import com.lbc.lctr.fintrac.common.domain.LCTRReport;

public class DataLoadSetter implements ItemPreparedStatementSetter<LCTRReport> {

	@Override
	public void setValues(LCTRReport item, PreparedStatement ps) throws SQLException {
		ps.setInt(1,1);
		ps.setInt(2,1);
		ps.setClob(3, (Clob) new SqlLobValue(item.toString()));
		ps.setString(4,"Test");
		ps.setInt(9,1);
	}

}
