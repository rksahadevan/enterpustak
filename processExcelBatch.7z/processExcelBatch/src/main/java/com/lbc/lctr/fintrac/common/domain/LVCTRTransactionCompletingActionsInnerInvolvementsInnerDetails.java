package com.lbc.lctr.fintrac.common.domain;

import java.util.Objects;

import javax.annotation.Generated;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * LVCTRTransactionCompletingActionsInnerInvolvementsInnerDetails
 */

@JsonTypeName("LVCTRTransaction_completingActions_inner_involvements_inner_details")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-03-29T08:53:00.631912700-04:00[America/New_York]")
public class LVCTRTransactionCompletingActionsInnerInvolvementsInnerDetails {

  @JsonProperty("accountNumber")
  private String accountNumber;

  @JsonProperty("identifyingNumber")
  private String identifyingNumber;

  @JsonProperty("policyNumber")
  private String policyNumber;

  public LVCTRTransactionCompletingActionsInnerInvolvementsInnerDetails accountNumber(String accountNumber) {
    this.accountNumber = accountNumber;
    return this;
  }

  /**
   * Get accountNumber
   * @return accountNumber
  */
  @Size(max = 100) 
  @Schema(name = "accountNumber", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getAccountNumber() {
    return accountNumber;
  }

  public void setAccountNumber(String accountNumber) {
    this.accountNumber = accountNumber;
  }

  public LVCTRTransactionCompletingActionsInnerInvolvementsInnerDetails identifyingNumber(String identifyingNumber) {
    this.identifyingNumber = identifyingNumber;
    return this;
  }

  /**
   * Get identifyingNumber
   * @return identifyingNumber
  */
  @Size(max = 100) 
  @Schema(name = "identifyingNumber", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getIdentifyingNumber() {
    return identifyingNumber;
  }

  public void setIdentifyingNumber(String identifyingNumber) {
    this.identifyingNumber = identifyingNumber;
  }

  public LVCTRTransactionCompletingActionsInnerInvolvementsInnerDetails policyNumber(String policyNumber) {
    this.policyNumber = policyNumber;
    return this;
  }

  /**
   * Get policyNumber
   * @return policyNumber
  */
  @Size(max = 100) 
  @Schema(name = "policyNumber", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getPolicyNumber() {
    return policyNumber;
  }

  public void setPolicyNumber(String policyNumber) {
    this.policyNumber = policyNumber;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    LVCTRTransactionCompletingActionsInnerInvolvementsInnerDetails lvCTRTransactionCompletingActionsInnerInvolvementsInnerDetails = (LVCTRTransactionCompletingActionsInnerInvolvementsInnerDetails) o;
    return Objects.equals(this.accountNumber, lvCTRTransactionCompletingActionsInnerInvolvementsInnerDetails.accountNumber) &&
        Objects.equals(this.identifyingNumber, lvCTRTransactionCompletingActionsInnerInvolvementsInnerDetails.identifyingNumber) &&
        Objects.equals(this.policyNumber, lvCTRTransactionCompletingActionsInnerInvolvementsInnerDetails.policyNumber);
  }

  @Override
  public int hashCode() {
    return Objects.hash(accountNumber, identifyingNumber, policyNumber);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class LVCTRTransactionCompletingActionsInnerInvolvementsInnerDetails {\n");
    sb.append("    accountNumber: ").append(toIndentedString(accountNumber)).append("\n");
    sb.append("    identifyingNumber: ").append(toIndentedString(identifyingNumber)).append("\n");
    sb.append("    policyNumber: ").append(toIndentedString(policyNumber)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

