package com.lbc.lctr.fintrac.common.domain;

import java.util.Objects;

import javax.annotation.Generated;
import javax.validation.Valid;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * LCTRTransactionStartingActionsInnerDetails
 */

@JsonTypeName("LCTRTransaction_startingActions_inner_details")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-03-29T08:53:00.631912700-04:00[America/New_York]")
public class LCTRStartingActionsDetails {

  @JsonProperty("amount")
  private String amount;

  @JsonProperty("currencyCode")
  private CurrencyCode currencyCode;

  @JsonProperty("howCashObtained")
  private String howCashObtained;

  @JsonProperty("sourceOfCashIndicator")
  private Boolean sourceOfCashIndicator;

  @JsonProperty("depositToBusinessAccountIndicator")
  private Boolean depositToBusinessAccountIndicator;

  public LCTRStartingActionsDetails amount(String amount) {
    this.amount = amount;
    return this;
  }

  /**
   * Get amount
   * @return amount
  */
  @Pattern(regexp = "^\\\\d{1,17}(\\\\.\\\\d{2,10})?$") 
  @Schema(name = "amount", example = "13797.59", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getAmount() {
    return amount;
  }

  public void setAmount(String amount) {
    this.amount = amount;
  }

  public LCTRStartingActionsDetails currencyCode(CurrencyCode currencyCode) {
    this.currencyCode = currencyCode;
    return this;
  }

  /**
   * Get currencyCode
   * @return currencyCode
  */
  @Valid 
  @Schema(name = "currencyCode", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public CurrencyCode getCurrencyCode() {
    return currencyCode;
  }

  public void setCurrencyCode(CurrencyCode currencyCode) {
    this.currencyCode = currencyCode;
  }

  public LCTRStartingActionsDetails howCashObtained(String howCashObtained) {
    this.howCashObtained = howCashObtained;
    return this;
  }

  /**
   * Get howCashObtained
   * @return howCashObtained
  */
  @Size(max = 200) 
  @Schema(name = "howCashObtained", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getHowCashObtained() {
    return howCashObtained;
  }

  public void setHowCashObtained(String howCashObtained) {
    this.howCashObtained = howCashObtained;
  }

  public LCTRStartingActionsDetails sourceOfCashIndicator(Boolean sourceOfCashIndicator) {
    this.sourceOfCashIndicator = sourceOfCashIndicator;
    return this;
  }

  /**
   * Get sourceOfCashIndicator
   * @return sourceOfCashIndicator
  */
  
  @Schema(name = "sourceOfCashIndicator", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public Boolean getSourceOfCashIndicator() {
    return sourceOfCashIndicator;
  }

  public void setSourceOfCashIndicator(Boolean sourceOfCashIndicator) {
    this.sourceOfCashIndicator = sourceOfCashIndicator;
  }

  public LCTRStartingActionsDetails depositToBusinessAccountIndicator(Boolean depositToBusinessAccountIndicator) {
    this.depositToBusinessAccountIndicator = depositToBusinessAccountIndicator;
    return this;
  }

  /**
   * Get depositToBusinessAccountIndicator
   * @return depositToBusinessAccountIndicator
  */
  
  @Schema(name = "depositToBusinessAccountIndicator", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public Boolean getDepositToBusinessAccountIndicator() {
    return depositToBusinessAccountIndicator;
  }

  public void setDepositToBusinessAccountIndicator(Boolean depositToBusinessAccountIndicator) {
    this.depositToBusinessAccountIndicator = depositToBusinessAccountIndicator;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    LCTRStartingActionsDetails lcTRTransactionStartingActionsInnerDetails = (LCTRStartingActionsDetails) o;
    return Objects.equals(this.amount, lcTRTransactionStartingActionsInnerDetails.amount) &&
        Objects.equals(this.currencyCode, lcTRTransactionStartingActionsInnerDetails.currencyCode) &&
        Objects.equals(this.howCashObtained, lcTRTransactionStartingActionsInnerDetails.howCashObtained) &&
        Objects.equals(this.sourceOfCashIndicator, lcTRTransactionStartingActionsInnerDetails.sourceOfCashIndicator) &&
        Objects.equals(this.depositToBusinessAccountIndicator, lcTRTransactionStartingActionsInnerDetails.depositToBusinessAccountIndicator);
  }

  @Override
  public int hashCode() {
    return Objects.hash(amount, currencyCode, howCashObtained, sourceOfCashIndicator, depositToBusinessAccountIndicator);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class LCTRTransactionStartingActionsInnerDetails {\n");
    sb.append("    amount: ").append(toIndentedString(amount)).append("\n");
    sb.append("    currencyCode: ").append(toIndentedString(currencyCode)).append("\n");
    sb.append("    howCashObtained: ").append(toIndentedString(howCashObtained)).append("\n");
    sb.append("    sourceOfCashIndicator: ").append(toIndentedString(sourceOfCashIndicator)).append("\n");
    sb.append("    depositToBusinessAccountIndicator: ").append(toIndentedString(depositToBusinessAccountIndicator)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

