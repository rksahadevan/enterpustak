package com.lbc.lctr.fintrac.common.domain;

import java.util.Objects;

import javax.annotation.Generated;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonTypeName;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * LCTRTransactionCompletingActionsInnerDetailsAccountHoldersInner
 */

@JsonTypeName("LCTRTransaction_completingActions_inner_details_account_holders_inner")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-03-29T08:53:00.631912700-04:00[America/New_York]")
public class LCTRAccountHolderDetail extends Subject{

  /**
   *account holder can be thrid party entity or personl 
   */
 
  public LCTRAccountHolderDetail typeCode(SubjectType typeCode) {
    this.subjectType = typeCode;
    return this;
  }



  public LCTRAccountHolderDetail refId(String refId) {
    this.refId = refId;
    return this;
  }

  /**
   * Get refId
   * @return refId
  */
  @NotNull @Size(max = 50) 
  @Schema(name = "refId", requiredMode = Schema.RequiredMode.REQUIRED)
  public String getRefId() {
    return refId;
  }

  public void setRefId(String refId) {
    this.refId = refId;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    LCTRAccountHolderDetail lcTRTransactionCompletingActionsInnerDetailsAccountHoldersInner = (LCTRAccountHolderDetail) o;
    return Objects.equals(this.subjectType, lcTRTransactionCompletingActionsInnerDetailsAccountHoldersInner.subjectType) &&
        Objects.equals(this.refId, lcTRTransactionCompletingActionsInnerDetailsAccountHoldersInner.refId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(subjectType, refId);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class LCTRTransactionCompletingActionsInnerDetailsAccountHoldersInner {\n");
    sb.append("    typeCode: ").append(toIndentedString(subjectType)).append("\n");
    sb.append("    refId: ").append(toIndentedString(refId)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

