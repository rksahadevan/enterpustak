package com.lbc.lctr.fintrac.common.domain;

import java.util.Objects;

import javax.annotation.Generated;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.fasterxml.jackson.annotation.JsonValue;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * EntityDetailsIdentificationsInner
 */

@JsonTypeName("EntityDetails_identifications_inner")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-03-29T08:53:00.631912700-04:00[America/New_York]")
public class EntityDetailsIdentification {

  /**
   * * `1` - Articles of association / Acte d'association * `2` - Certificate of corporate status / Certificat attestant l'existence de la personne morale * `3` - Certificate of incorporation / Certificat de constitution * `4` - Letter/Notice of assessment / Lettre ou avis de cotisation * `5` - Partnership agreement / Entente de partenariat * `6` - Annual report / Rapport annuel * `7` - Other / Autre 
   */
  public enum IdentifierTypeCodeEnum {
    NUMBER_1(1),
    
    NUMBER_2(2),
    
    NUMBER_3(3),
    
    NUMBER_4(4),
    
    NUMBER_5(5),
    
    NUMBER_6(6),
    
    NUMBER_7(7);

    private Integer value;

    IdentifierTypeCodeEnum(Integer value) {
      this.value = value;
    }

    @JsonValue
    public Integer getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static IdentifierTypeCodeEnum fromValue(Integer value) {
      for (IdentifierTypeCodeEnum b : IdentifierTypeCodeEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  @JsonProperty("identifierTypeCode")
  private IdentifierTypeCodeEnum identifierTypeCode;

  @JsonProperty("identifierTypeOther")
  private String identifierTypeOther;

  @JsonProperty("number")
  private String number;

  @JsonProperty("jurisdictionOfIssuerCountryCode")
  private CountryCode jurisdictionOfIssuerCountryCode;

  @JsonProperty("jurisdictionOfIssueProvinceStateCode")
  private ProvinceStateCode jurisdictionOfIssueProvinceStateCode;

  @JsonProperty("jurisdictionOfIssueProvinceStateName")
  private String jurisdictionOfIssueProvinceStateName;

  public EntityDetailsIdentification identifierTypeCode(IdentifierTypeCodeEnum identifierTypeCode) {
    this.identifierTypeCode = identifierTypeCode;
    return this;
  }

  /**
   * * `1` - Articles of association / Acte d'association * `2` - Certificate of corporate status / Certificat attestant l'existence de la personne morale * `3` - Certificate of incorporation / Certificat de constitution * `4` - Letter/Notice of assessment / Lettre ou avis de cotisation * `5` - Partnership agreement / Entente de partenariat * `6` - Annual report / Rapport annuel * `7` - Other / Autre 
   * @return identifierTypeCode
  */
  @NotNull 
  @Schema(name = "identifierTypeCode", description = "* `1` - Articles of association / Acte d'association * `2` - Certificate of corporate status / Certificat attestant l'existence de la personne morale * `3` - Certificate of incorporation / Certificat de constitution * `4` - Letter/Notice of assessment / Lettre ou avis de cotisation * `5` - Partnership agreement / Entente de partenariat * `6` - Annual report / Rapport annuel * `7` - Other / Autre ", requiredMode = Schema.RequiredMode.REQUIRED)
  public IdentifierTypeCodeEnum getIdentifierTypeCode() {
    return identifierTypeCode;
  }

  public void setIdentifierTypeCode(IdentifierTypeCodeEnum identifierTypeCode) {
    this.identifierTypeCode = identifierTypeCode;
  }

  public EntityDetailsIdentification identifierTypeOther(String identifierTypeOther) {
    this.identifierTypeOther = identifierTypeOther;
    return this;
  }

  /**
   * Get identifierTypeOther
   * @return identifierTypeOther
  */
  @Size(max = 200) 
  @Schema(name = "identifierTypeOther", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getIdentifierTypeOther() {
    return identifierTypeOther;
  }

  public void setIdentifierTypeOther(String identifierTypeOther) {
    this.identifierTypeOther = identifierTypeOther;
  }

  public EntityDetailsIdentification number(String number) {
    this.number = number;
    return this;
  }

  /**
   * Get number
   * @return number
  */
  @NotNull @Size(max = 100) 
  @Schema(name = "number", requiredMode = Schema.RequiredMode.REQUIRED)
  public String getNumber() {
    return number;
  }

  public void setNumber(String number) {
    this.number = number;
  }

  public EntityDetailsIdentification jurisdictionOfIssuerCountryCode(CountryCode jurisdictionOfIssuerCountryCode) {
    this.jurisdictionOfIssuerCountryCode = jurisdictionOfIssuerCountryCode;
    return this;
  }

  /**
   * Get jurisdictionOfIssuerCountryCode
   * @return jurisdictionOfIssuerCountryCode
  */
  @Valid 
  @Schema(name = "jurisdictionOfIssuerCountryCode", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public CountryCode getJurisdictionOfIssuerCountryCode() {
    return jurisdictionOfIssuerCountryCode;
  }

  public void setJurisdictionOfIssuerCountryCode(CountryCode jurisdictionOfIssuerCountryCode) {
    this.jurisdictionOfIssuerCountryCode = jurisdictionOfIssuerCountryCode;
  }

  public EntityDetailsIdentification jurisdictionOfIssueProvinceStateCode(ProvinceStateCode jurisdictionOfIssueProvinceStateCode) {
    this.jurisdictionOfIssueProvinceStateCode = jurisdictionOfIssueProvinceStateCode;
    return this;
  }

  /**
   * Get jurisdictionOfIssueProvinceStateCode
   * @return jurisdictionOfIssueProvinceStateCode
  */
  @Valid 
  @Schema(name = "jurisdictionOfIssueProvinceStateCode", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public ProvinceStateCode getJurisdictionOfIssueProvinceStateCode() {
    return jurisdictionOfIssueProvinceStateCode;
  }

  public void setJurisdictionOfIssueProvinceStateCode(ProvinceStateCode jurisdictionOfIssueProvinceStateCode) {
    this.jurisdictionOfIssueProvinceStateCode = jurisdictionOfIssueProvinceStateCode;
  }

  public EntityDetailsIdentification jurisdictionOfIssueProvinceStateName(String jurisdictionOfIssueProvinceStateName) {
    this.jurisdictionOfIssueProvinceStateName = jurisdictionOfIssueProvinceStateName;
    return this;
  }

  /**
   * Get jurisdictionOfIssueProvinceStateName
   * @return jurisdictionOfIssueProvinceStateName
  */
  @Size(max = 100) 
  @Schema(name = "jurisdictionOfIssueProvinceStateName", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getJurisdictionOfIssueProvinceStateName() {
    return jurisdictionOfIssueProvinceStateName;
  }

  public void setJurisdictionOfIssueProvinceStateName(String jurisdictionOfIssueProvinceStateName) {
    this.jurisdictionOfIssueProvinceStateName = jurisdictionOfIssueProvinceStateName;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    EntityDetailsIdentification entityDetailsIdentificationsInner = (EntityDetailsIdentification) o;
    return Objects.equals(this.identifierTypeCode, entityDetailsIdentificationsInner.identifierTypeCode) &&
        Objects.equals(this.identifierTypeOther, entityDetailsIdentificationsInner.identifierTypeOther) &&
        Objects.equals(this.number, entityDetailsIdentificationsInner.number) &&
        Objects.equals(this.jurisdictionOfIssuerCountryCode, entityDetailsIdentificationsInner.jurisdictionOfIssuerCountryCode) &&
        Objects.equals(this.jurisdictionOfIssueProvinceStateCode, entityDetailsIdentificationsInner.jurisdictionOfIssueProvinceStateCode) &&
        Objects.equals(this.jurisdictionOfIssueProvinceStateName, entityDetailsIdentificationsInner.jurisdictionOfIssueProvinceStateName);
  }

  @Override
  public int hashCode() {
    return Objects.hash(identifierTypeCode, identifierTypeOther, number, jurisdictionOfIssuerCountryCode, jurisdictionOfIssueProvinceStateCode, jurisdictionOfIssueProvinceStateName);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class EntityDetailsIdentificationsInner {\n");
    sb.append("    identifierTypeCode: ").append(toIndentedString(identifierTypeCode)).append("\n");
    sb.append("    identifierTypeOther: ").append(toIndentedString(identifierTypeOther)).append("\n");
    sb.append("    number: ").append(toIndentedString(number)).append("\n");
    sb.append("    jurisdictionOfIssuerCountryCode: ").append(toIndentedString(jurisdictionOfIssuerCountryCode)).append("\n");
    sb.append("    jurisdictionOfIssueProvinceStateCode: ").append(toIndentedString(jurisdictionOfIssueProvinceStateCode)).append("\n");
    sb.append("    jurisdictionOfIssueProvinceStateName: ").append(toIndentedString(jurisdictionOfIssueProvinceStateName)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

