package com.lbc.lctr.fintrac.config;

/**
* Below Class has list of DataSources configuration that is being used by the application  
*
* @author  Santosh Kumar Balekari
* @version 1.0
* @since   01-Jan-2023 
*/

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import com.zaxxer.hikari.HikariDataSource;

@Configuration
public class DataSourceRepository {

	@Bean
	@Primary
	@ConfigurationProperties(prefix = "springbatch.dbsource")
	public DataSourceProperties springBatchDataSourceProperties() {
		return new DataSourceProperties();
	}

	@Bean(name = { "dataSourceSpringBatch" })
	@Primary
	@ConfigurationProperties("springbatch.dbsource.configuration")
	public HikariDataSource springBatchDataSource() {
		return springBatchDataSourceProperties().initializeDataSourceBuilder().type(HikariDataSource.class).build();
	}

	@Bean
	@ConfigurationProperties(prefix = "app.dbsource")
	public DataSourceProperties appDataSourceProperties() {
		return new DataSourceProperties();
	}

	@Bean(name = { "dataSourceApp" })
	@ConfigurationProperties("app.dbsource.configuration")
	public HikariDataSource appDataSource() {
		return appDataSourceProperties().initializeDataSourceBuilder().type(HikariDataSource.class).build();
	}

	@Bean(name = "jdbcTemplate")
	public JdbcTemplate jdbcTemplate(@Qualifier("dataSourceApp") DataSource ds) {
		return new JdbcTemplate(ds);
	}

	@Bean(name = "namedJdbcTemplate")
	public NamedParameterJdbcTemplate namedJdbcTemplate(@Qualifier("dataSourceApp") DataSource ds) {
		return new NamedParameterJdbcTemplate(ds);
	}
}