package com.lbc.lctr.fintrac.common.domain;

import javax.annotation.Generated;

import com.fasterxml.jackson.annotation.JsonTypeInfo;

/**
 * LCTR subject all conductor,benficiers, involment, , entity , third party, onbeahlf involved into transcation..
 * @author PateP2
 *
 */
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-03-29T08:53:00.631912700-04:00[America/New_York]")
@JsonTypeInfo(use=JsonTypeInfo.Id.CLASS, include=JsonTypeInfo.As.PROPERTY, property="@class")
public interface SubjectDefination {
}
