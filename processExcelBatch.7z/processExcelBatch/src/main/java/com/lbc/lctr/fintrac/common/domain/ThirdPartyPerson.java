package com.lbc.lctr.fintrac.common.domain;

import java.util.Objects;

import javax.annotation.Generated;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * PersonName
 */

@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-03-29T08:53:00.631912700-04:00[America/New_York]")
@JsonTypeInfo(use=JsonTypeInfo.Id.CLASS, include=JsonTypeInfo.As.PROPERTY, property="@class")
public class ThirdPartyPerson implements SubjectDefination {




  @JsonProperty("refId")
  private String refId;

  @JsonProperty("givenName")
  private String givenName;

  @JsonProperty("surname")
  private String surname;

  @JsonProperty("otherNameInitial")
  private String otherNameInitial;

  
  @JsonProperty("subjectType")
  private SubjectType subjectType = SubjectType.THIRD_PARTY_PERSON;

  
  public SubjectType getSubjectType() {
	return subjectType;
}

  public void setSubjectType(SubjectType subjectType) {
	this.subjectType = subjectType;
  }




  public ThirdPartyPerson refId(String refId) {
    this.refId = refId;
    return this;
  }

  /**
   * Get refId
   * @return refId
  */
  @NotNull @Size(max = 50) 
  @Schema(name = "refId", requiredMode = Schema.RequiredMode.REQUIRED)
  public String getRefId() {
    return refId;
  }

  public void setRefId(String refId) {
    this.refId = refId;
  }

  public ThirdPartyPerson givenName(String givenName) {
    this.givenName = givenName;
    return this;
  }

  /**
   * Get givenName
   * @return givenName
  */
  @Size(max = 100) 
  @Schema(name = "givenName", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getGivenName() {
    return givenName;
  }

  public void setGivenName(String givenName) {
    this.givenName = givenName;
  }

  public ThirdPartyPerson surname(String surname) {
    this.surname = surname;
    return this;
  }

  /**
   * Get surname
   * @return surname
  */
  @Size(max = 100) 
  @Schema(name = "surname", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getSurname() {
    return surname;
  }

  public void setSurname(String surname) {
    this.surname = surname;
  }

  public ThirdPartyPerson otherNameInitial(String otherNameInitial) {
    this.otherNameInitial = otherNameInitial;
    return this;
  }

  /**
   * Get otherNameInitial
   * @return otherNameInitial
  */
  @Size(max = 100) 
  @Schema(name = "otherNameInitial", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getOtherNameInitial() {
    return otherNameInitial;
  }

  public void setOtherNameInitial(String otherNameInitial) {
    this.otherNameInitial = otherNameInitial;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ThirdPartyPerson personName = (ThirdPartyPerson) o;
    return Objects.equals(this.subjectType, personName.subjectType) &&
        Objects.equals(this.refId, personName.refId) &&
        Objects.equals(this.givenName, personName.givenName) &&
        Objects.equals(this.surname, personName.surname) &&
        Objects.equals(this.otherNameInitial, personName.otherNameInitial);
  }

  @Override
  public int hashCode() {
    return Objects.hash(subjectType, refId, givenName, surname, otherNameInitial);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PersonName {\n");
    sb.append("    typeCode: ").append(toIndentedString(subjectType)).append("\n");
    sb.append("    refId: ").append(toIndentedString(refId)).append("\n");
    sb.append("    givenName: ").append(toIndentedString(givenName)).append("\n");
    sb.append("    surname: ").append(toIndentedString(surname)).append("\n");
    sb.append("    otherNameInitial: ").append(toIndentedString(otherNameInitial)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

