package com.lbc.lctr.fintrac.common.domain;

import java.util.Objects;

import javax.annotation.Generated;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonValue;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * StructuredAddress
 */

@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-03-29T08:53:00.631912700-04:00[America/New_York]")
@JsonTypeInfo(use=JsonTypeInfo.Id.CLASS, include=JsonTypeInfo.As.PROPERTY, property="@class")

public class StructuredAddress implements PersonDetailsAddress {

  /**
   * type code for structured address / type de code pour adresse structurée
   */
  public enum TypeCodeEnum {
    NUMBER_1(1);

    private Integer value;

    TypeCodeEnum(Integer value) {
      this.value = value;
    }

    @JsonValue
    public Integer getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static TypeCodeEnum fromValue(Integer value) {
      for (TypeCodeEnum b : TypeCodeEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  @JsonProperty("typeCode")
  private TypeCodeEnum typeCode;

  @JsonProperty("unitNumber")
  private String unitNumber;

  @JsonProperty("buildingNumber")
  private String buildingNumber;

  @JsonProperty("streetAddress")
  private String streetAddress;

  @JsonProperty("city")
  private String city;

  @JsonProperty("district")
  private String district;

  @JsonProperty("provinceStateCode")
  private ProvinceStateCode provinceStateCode;

  @JsonProperty("provinceStateName")
  private String provinceStateName;

  @JsonProperty("subProvinceSubLocality")
  private String subProvinceSubLocality;

  @JsonProperty("postalZipCode")
  private String postalZipCode;

  @JsonProperty("countryCode")
  private CountryCode countryCode;

  public StructuredAddress typeCode(TypeCodeEnum typeCode) {
    this.typeCode = typeCode;
    return this;
  }

  /**
   * type code for structured address / type de code pour adresse structurée
   * @return typeCode
  */
  @NotNull 
  @Schema(name = "typeCode", description = "type code for structured address / type de code pour adresse structurée", requiredMode = Schema.RequiredMode.REQUIRED)
  public TypeCodeEnum getTypeCode() {
    return typeCode;
  }

  public void setTypeCode(TypeCodeEnum typeCode) {
    this.typeCode = typeCode;
  }

  public StructuredAddress unitNumber(String unitNumber) {
    this.unitNumber = unitNumber;
    return this;
  }

  /**
   * Get unitNumber
   * @return unitNumber
  */
  @Size(max = 10) 
  @Schema(name = "unitNumber", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getUnitNumber() {
    return unitNumber;
  }

  public void setUnitNumber(String unitNumber) {
    this.unitNumber = unitNumber;
  }

  public StructuredAddress buildingNumber(String buildingNumber) {
    this.buildingNumber = buildingNumber;
    return this;
  }

  /**
   * Get buildingNumber
   * @return buildingNumber
  */
  @Size(max = 100) 
  @Schema(name = "buildingNumber", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getBuildingNumber() {
    return buildingNumber;
  }

  public void setBuildingNumber(String buildingNumber) {
    this.buildingNumber = buildingNumber;
  }

  public StructuredAddress streetAddress(String streetAddress) {
    this.streetAddress = streetAddress;
    return this;
  }

  /**
   * Get streetAddress
   * @return streetAddress
  */
  @NotNull @Size(max = 100) 
  @Schema(name = "streetAddress", requiredMode = Schema.RequiredMode.REQUIRED)
  public String getStreetAddress() {
    return streetAddress;
  }

  public void setStreetAddress(String streetAddress) {
    this.streetAddress = streetAddress;
  }

  public StructuredAddress city(String city) {
    this.city = city;
    return this;
  }

  /**
   * Get city
   * @return city
  */
  @NotNull @Size(max = 100) 
  @Schema(name = "city", requiredMode = Schema.RequiredMode.REQUIRED)
  public String getCity() {
    return city;
  }

  public void setCity(String city) {
    this.city = city;
  }

  public StructuredAddress district(String district) {
    this.district = district;
    return this;
  }

  /**
   * Get district
   * @return district
  */
  @Size(max = 100) 
  @Schema(name = "district", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getDistrict() {
    return district;
  }

  public void setDistrict(String district) {
    this.district = district;
  }

  public StructuredAddress provinceStateCode(ProvinceStateCode provinceStateCode) {
    this.provinceStateCode = provinceStateCode;
    return this;
  }

  /**
   * Get provinceStateCode
   * @return provinceStateCode
  */
  @Valid 
  @Schema(name = "provinceStateCode", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public ProvinceStateCode getProvinceStateCode() {
    return provinceStateCode;
  }

  public void setProvinceStateCode(ProvinceStateCode provinceStateCode) {
    this.provinceStateCode = provinceStateCode;
  }

  public StructuredAddress provinceStateName(String provinceStateName) {
    this.provinceStateName = provinceStateName;
    return this;
  }

  /**
   * Get provinceStateName
   * @return provinceStateName
  */
  @Size(max = 100) 
  @Schema(name = "provinceStateName", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getProvinceStateName() {
    return provinceStateName;
  }

  public void setProvinceStateName(String provinceStateName) {
    this.provinceStateName = provinceStateName;
  }

  public StructuredAddress subProvinceSubLocality(String subProvinceSubLocality) {
    this.subProvinceSubLocality = subProvinceSubLocality;
    return this;
  }

  /**
   * Get subProvinceSubLocality
   * @return subProvinceSubLocality
  */
  @Size(max = 100) 
  @Schema(name = "subProvinceSubLocality", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getSubProvinceSubLocality() {
    return subProvinceSubLocality;
  }

  public void setSubProvinceSubLocality(String subProvinceSubLocality) {
    this.subProvinceSubLocality = subProvinceSubLocality;
  }

  public StructuredAddress postalZipCode(String postalZipCode) {
    this.postalZipCode = postalZipCode;
    return this;
  }

  /**
   * Get postalZipCode
   * @return postalZipCode
  */
  @Size(max = 20) 
  @Schema(name = "postalZipCode", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getPostalZipCode() {
    return postalZipCode;
  }

  public void setPostalZipCode(String postalZipCode) {
    this.postalZipCode = postalZipCode;
  }

  public StructuredAddress countryCode(CountryCode countryCode) {
    this.countryCode = countryCode;
    return this;
  }

  /**
   * Get countryCode
   * @return countryCode
  */
  @NotNull @Valid 
  @Schema(name = "countryCode", requiredMode = Schema.RequiredMode.REQUIRED)
  public CountryCode getCountryCode() {
    return countryCode;
  }

  public void setCountryCode(CountryCode countryCode) {
    this.countryCode = countryCode;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    StructuredAddress structuredAddress = (StructuredAddress) o;
    return Objects.equals(this.typeCode, structuredAddress.typeCode) &&
        Objects.equals(this.unitNumber, structuredAddress.unitNumber) &&
        Objects.equals(this.buildingNumber, structuredAddress.buildingNumber) &&
        Objects.equals(this.streetAddress, structuredAddress.streetAddress) &&
        Objects.equals(this.city, structuredAddress.city) &&
        Objects.equals(this.district, structuredAddress.district) &&
        Objects.equals(this.provinceStateCode, structuredAddress.provinceStateCode) &&
        Objects.equals(this.provinceStateName, structuredAddress.provinceStateName) &&
        Objects.equals(this.subProvinceSubLocality, structuredAddress.subProvinceSubLocality) &&
        Objects.equals(this.postalZipCode, structuredAddress.postalZipCode) &&
        Objects.equals(this.countryCode, structuredAddress.countryCode);
  }

  @Override
  public int hashCode() {
    return Objects.hash(typeCode, unitNumber, buildingNumber, streetAddress, city, district, provinceStateCode, provinceStateName, subProvinceSubLocality, postalZipCode, countryCode);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class StructuredAddress {\n");
    sb.append("    typeCode: ").append(toIndentedString(typeCode)).append("\n");
    sb.append("    unitNumber: ").append(toIndentedString(unitNumber)).append("\n");
    sb.append("    buildingNumber: ").append(toIndentedString(buildingNumber)).append("\n");
    sb.append("    streetAddress: ").append(toIndentedString(streetAddress)).append("\n");
    sb.append("    city: ").append(toIndentedString(city)).append("\n");
    sb.append("    district: ").append(toIndentedString(district)).append("\n");
    sb.append("    provinceStateCode: ").append(toIndentedString(provinceStateCode)).append("\n");
    sb.append("    provinceStateName: ").append(toIndentedString(provinceStateName)).append("\n");
    sb.append("    subProvinceSubLocality: ").append(toIndentedString(subProvinceSubLocality)).append("\n");
    sb.append("    postalZipCode: ").append(toIndentedString(postalZipCode)).append("\n");
    sb.append("    countryCode: ").append(toIndentedString(countryCode)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

