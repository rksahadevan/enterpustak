package com.lbc.lctr.fintrac.common.domain;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.annotation.Generated;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * LCTRTransactionCompletingActionsInner
 */

@JsonTypeName("LCTRTransaction_completingActions_inner")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-03-29T08:53:00.631912700-04:00[America/New_York]")
public class LCTRCompletingAction {

  @JsonProperty("details")
  private LCTRCompletingActionDetail details;

  @JsonProperty("involvements")
  @Valid
  private List<LCTRInvolvements> involvements = null;

  @JsonProperty("beneficiaries")
  @Valid
  private List<LCTRBeneficiarie> beneficiaries = new ArrayList<>();

  public LCTRCompletingAction details(LCTRCompletingActionDetail details) {
    this.details = details;
    return this;
  }

  /**
   * Get details
   * @return details
  */
  @NotNull @Valid 
  @Schema(name = "details", requiredMode = Schema.RequiredMode.REQUIRED)
  public LCTRCompletingActionDetail getDetails() {
    return details;
  }

  public void setDetails(LCTRCompletingActionDetail details) {
    this.details = details;
  }

  public LCTRCompletingAction involvements(List<LCTRInvolvements> involvements) {
    this.involvements = involvements;
    return this;
  }

  public LCTRCompletingAction addInvolvementsItem(LCTRInvolvements involvementsItem) {
    if (this.involvements == null) {
      this.involvements = new ArrayList<>();
    }
    this.involvements.add(involvementsItem);
    return this;
  }

  /**
   * Get involvements
   * @return involvements
  */
  @Valid 
  @Schema(name = "involvements", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public List<LCTRInvolvements> getInvolvements() {
    return involvements;
  }

  public void setInvolvements(List<LCTRInvolvements> involvements) {
    this.involvements = involvements;
  }

  public LCTRCompletingAction beneficiaries(List<LCTRBeneficiarie> beneficiaries) {
    this.beneficiaries = beneficiaries;
    return this;
  }

  public LCTRCompletingAction addBeneficiariesItem(LCTRBeneficiarie beneficiariesItem) {
    this.beneficiaries.add(beneficiariesItem);
    return this;
  }

  /**
   * Get beneficiaries
   * @return beneficiaries
  */
  @NotNull @Valid 
  @Schema(name = "beneficiaries", requiredMode = Schema.RequiredMode.REQUIRED)
  public List<LCTRBeneficiarie> getBeneficiaries() {
    return beneficiaries;
  }

  public void setBeneficiaries(List<LCTRBeneficiarie> beneficiaries) {
    this.beneficiaries = beneficiaries;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    LCTRCompletingAction lcTRTransactionCompletingActionsInner = (LCTRCompletingAction) o;
    return Objects.equals(this.details, lcTRTransactionCompletingActionsInner.details) &&
        Objects.equals(this.involvements, lcTRTransactionCompletingActionsInner.involvements) &&
        Objects.equals(this.beneficiaries, lcTRTransactionCompletingActionsInner.beneficiaries);
  }

  @Override
  public int hashCode() {
    return Objects.hash(details, involvements, beneficiaries);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class LCTRTransactionCompletingActionsInner {\n");
    sb.append("    details: ").append(toIndentedString(details)).append("\n");
    sb.append("    involvements: ").append(toIndentedString(involvements)).append("\n");
    sb.append("    beneficiaries: ").append(toIndentedString(beneficiaries)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

