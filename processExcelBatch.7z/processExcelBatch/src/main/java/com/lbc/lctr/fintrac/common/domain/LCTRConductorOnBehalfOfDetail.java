package com.lbc.lctr.fintrac.common.domain;

import java.util.Objects;

import javax.annotation.Generated;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.fasterxml.jackson.annotation.JsonValue;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * LCTRTransactionStartingActionsInnerConductorsInnerOnBehalfOfsInnerDetails
 */

@JsonTypeName("LCTRTransaction_startingActions_inner_conductors_inner_onBehalfOfs_inner_details")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-03-29T08:53:00.631912700-04:00[America/New_York]")
public class LCTRConductorOnBehalfOfDetail {

  @JsonProperty("clientNumber")
  private String clientNumber;

  @JsonProperty("emailAddress")
  private String emailAddress;

  /**
   * Gets or Sets relationshipOfConductorCode
   */
  public enum RelationshipOfConductorCodeEnum {
    NUMBER_1(1),
    
    NUMBER_2(2),
    
    NUMBER_3(3),
    
    NUMBER_4(4),
    
    NUMBER_5(5),
    
    NUMBER_6(6),
    
    NUMBER_7(7),
    
    NUMBER_8(8),
    
    NUMBER_9(9),
    
    NUMBER_10(10),
    
    NUMBER_11(11),
    
    NUMBER_12(12),
    
    NUMBER_13(13),
    
    NUMBER_14(14);

    private Integer value;

    RelationshipOfConductorCodeEnum(Integer value) {
      this.value = value;
    }

    @JsonValue
    public Integer getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static RelationshipOfConductorCodeEnum fromValue(Integer value) {
      for (RelationshipOfConductorCodeEnum b : RelationshipOfConductorCodeEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  @JsonProperty("relationshipOfConductorCode")
  private RelationshipOfConductorCodeEnum relationshipOfConductorCode;

  @JsonProperty("relationshipOfConductorOther")
  private String relationshipOfConductorOther;

  public LCTRConductorOnBehalfOfDetail clientNumber(String clientNumber) {
    this.clientNumber = clientNumber;
    return this;
  }

  /**
   * Get clientNumber
   * @return clientNumber
  */
  @Size(max = 100) 
  @Schema(name = "clientNumber", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getClientNumber() {
    return clientNumber;
  }

  public void setClientNumber(String clientNumber) {
    this.clientNumber = clientNumber;
  }

  public LCTRConductorOnBehalfOfDetail emailAddress(String emailAddress) {
    this.emailAddress = emailAddress;
    return this;
  }

  /**
   * Get emailAddress
   * @return emailAddress
  */
  @Size(max = 200) 
  @Schema(name = "emailAddress", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getEmailAddress() {
    return emailAddress;
  }

  public void setEmailAddress(String emailAddress) {
    this.emailAddress = emailAddress;
  }

  public LCTRConductorOnBehalfOfDetail relationshipOfConductorCode(RelationshipOfConductorCodeEnum relationshipOfConductorCode) {
    this.relationshipOfConductorCode = relationshipOfConductorCode;
    return this;
  }

  /**
   * Get relationshipOfConductorCode
   * @return relationshipOfConductorCode
  */
  @NotNull 
  @Schema(name = "relationshipOfConductorCode", requiredMode = Schema.RequiredMode.REQUIRED)
  public RelationshipOfConductorCodeEnum getRelationshipOfConductorCode() {
    return relationshipOfConductorCode;
  }

  public void setRelationshipOfConductorCode(RelationshipOfConductorCodeEnum relationshipOfConductorCode) {
    this.relationshipOfConductorCode = relationshipOfConductorCode;
  }

  public LCTRConductorOnBehalfOfDetail relationshipOfConductorOther(String relationshipOfConductorOther) {
    this.relationshipOfConductorOther = relationshipOfConductorOther;
    return this;
  }

  /**
   * Get relationshipOfConductorOther
   * @return relationshipOfConductorOther
  */
  @Size(max = 200) 
  @Schema(name = "relationshipOfConductorOther", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getRelationshipOfConductorOther() {
    return relationshipOfConductorOther;
  }

  public void setRelationshipOfConductorOther(String relationshipOfConductorOther) {
    this.relationshipOfConductorOther = relationshipOfConductorOther;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    LCTRConductorOnBehalfOfDetail lcTRTransactionStartingActionsInnerConductorsInnerOnBehalfOfsInnerDetails = (LCTRConductorOnBehalfOfDetail) o;
    return Objects.equals(this.clientNumber, lcTRTransactionStartingActionsInnerConductorsInnerOnBehalfOfsInnerDetails.clientNumber) &&
        Objects.equals(this.emailAddress, lcTRTransactionStartingActionsInnerConductorsInnerOnBehalfOfsInnerDetails.emailAddress) &&
        Objects.equals(this.relationshipOfConductorCode, lcTRTransactionStartingActionsInnerConductorsInnerOnBehalfOfsInnerDetails.relationshipOfConductorCode) &&
        Objects.equals(this.relationshipOfConductorOther, lcTRTransactionStartingActionsInnerConductorsInnerOnBehalfOfsInnerDetails.relationshipOfConductorOther);
  }

  @Override
  public int hashCode() {
    return Objects.hash(clientNumber, emailAddress, relationshipOfConductorCode, relationshipOfConductorOther);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class LCTRTransactionStartingActionsInnerConductorsInnerOnBehalfOfsInnerDetails {\n");
    sb.append("    clientNumber: ").append(toIndentedString(clientNumber)).append("\n");
    sb.append("    emailAddress: ").append(toIndentedString(emailAddress)).append("\n");
    sb.append("    relationshipOfConductorCode: ").append(toIndentedString(relationshipOfConductorCode)).append("\n");
    sb.append("    relationshipOfConductorOther: ").append(toIndentedString(relationshipOfConductorOther)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

