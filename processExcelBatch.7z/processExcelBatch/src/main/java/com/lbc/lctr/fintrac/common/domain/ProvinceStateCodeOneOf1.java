package com.lbc.lctr.fintrac.common.domain;

import javax.annotation.Generated;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

/**
 * * 'AL' - Alabama / Alabama * 'AK' - Alaska / Alaska * 'AZ' - Arizona / Arizona * 'AR' - Arkansas / Arkansas * 'CA' - California / Californie * 'CO' - Colorado / Colorado * 'CT' - Connecticut / Connecticut * 'DE' - Delaware / Delaware * 'DC' - District of Columbia / District fédéral de Columbia * 'FL' - Florida / Floride * 'GA' - Georgia / Géorgie * 'HI' - Hawaii / Hawai * 'ID' - Idaho / Idaho * 'IL' - Illinois / Illinois * 'IN' - Indiana / Indiana * 'IA' - Iowa / Iowa * 'KS' - Kansas / Kansas * 'KY' - Kentucky / Kentucky * 'LA' - Louisiana / Louisiane * 'ME' - Maine / Maine * 'MD' - Maryland / Maryland * 'MA' - Massachusetts / Massachusetts * 'MI' - Michigan / Michigan * 'MN' - Minnesota / Minnesota * 'MS' - Mississippi / Mississippi * 'MO' - Missouri / Missouri * 'MT' - Montana / Montana * 'NE' - Nebraska / Nebraska * 'NV' - Nevada / Nevada * 'NH' - New Hampshire / New Hampshire * 'NJ' - New Jersey / New Jersey * 'NM' - New Mexico / Nouveau-Mexique * 'NY' - New York / New York * 'NC' - North Carolina / Caroline du Nord * 'ND' - North Dakota / Dakota du Nord * 'OH' - Ohio / Ohio * 'OK' - Oklahoma / Oklahoma * 'OR' - Oregon / Orégon * 'PA' - Pennsylvania / Pennsylvanie * 'RI' - Rhode Island / Rhode Island * 'SC' - South Carolina / Carolina du Sud * 'SD' - South Dakota / Dakota du Sud * 'TN' - Tennessee / Tennessee * 'TX' - Texas / Texas * 'UT' - Utah / Utah * 'VT' - Vermont / Vermont * 'VA' - Virginia / Virginie * 'WA' - Washington / Washington * 'WV' - West Virginia / Virginie-Occidentale * 'WI' - Wisconsin / Wisconsin * 'WY' - Wyoming / Wyoming 
 */

@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-03-29T08:53:00.631912700-04:00[America/New_York]")
public enum ProvinceStateCodeOneOf1 {
  
  AL("AL"),
  
  AK("AK"),
  
  AZ("AZ"),
  
  AR("AR"),
  
  CA("CA"),
  
  CO("CO"),
  
  CT("CT"),
  
  DE("DE"),
  
  DC("DC"),
  
  FL("FL"),
  
  GA("GA"),
  
  HI("HI"),
  
  ID("ID"),
  
  IL("IL"),
  
  IN("IN"),
  
  IA("IA"),
  
  KS("KS"),
  
  KY("KY"),
  
  LA("LA"),
  
  ME("ME"),
  
  MD("MD"),
  
  MA("MA"),
  
  MI("MI"),
  
  MN("MN"),
  
  MS("MS"),
  
  MO("MO"),
  
  MT("MT"),
  
  NE("NE"),
  
  NV("NV"),
  
  NH("NH"),
  
  NJ("NJ"),
  
  NM("NM"),
  
  NY("NY"),
  
  NC("NC"),
  
  ND("ND"),
  
  OH("OH"),
  
  OK("OK"),
  
  OR("OR"),
  
  PA("PA"),
  
  RI("RI"),
  
  SC("SC"),
  
  SD("SD"),
  
  TN("TN"),
  
  TX("TX"),
  
  UT("UT"),
  
  VT("VT"),
  
  VA("VA"),
  
  WA("WA"),
  
  WV("WV"),
  
  WI("WI"),
  
  WY("WY");

  private String value;

  ProvinceStateCodeOneOf1(String value) {
    this.value = value;
  }

  @JsonValue
  public String getValue() {
    return value;
  }

  @Override
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static ProvinceStateCodeOneOf1 fromValue(String value) {
    for (ProvinceStateCodeOneOf1 b : ProvinceStateCodeOneOf1.values()) {
      if (b.value.equals(value)) {
        return b;
      }
    }
    throw new IllegalArgumentException("Unexpected value '" + value + "'");
  }
}

