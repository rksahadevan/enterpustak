package com.lbc.lctr.fintrac.common.domain;

//import com.lbc.lctr.fintrac.api.common.ReportStatus;

public class ReportContainer {

	private ReportBatch reportBatch;
	private LCTRReport lctrReport;
	private String sentTime;
	private String createTime;
	private Integer totalTransactions;
	//private ReportStatus reportStatus;
	public ReportBatch getReportBatch() {
		return reportBatch;
	}
	public void setReportBatch(ReportBatch reportBatch) {
		this.reportBatch = reportBatch;
	}
	public LCTRReport getLctrReport() {
		return lctrReport;
	}
	public void setLctrReport(LCTRReport lctrReport) {
		this.lctrReport = lctrReport;
	}
	public String getSentTime() {
		return sentTime;
	}
	public void setSentTime(String sentTime) {
		this.sentTime = sentTime;
	}
	public String getCreateTime() {
		return createTime;
	}
	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}
	public Integer getTotalTransactions() {
		return totalTransactions;
	}
	public void setTotalTransactions(Integer totalTransactions) {
		this.totalTransactions = totalTransactions;
	}
//	public ReportStatus getReportStatus() {
//		return reportStatus;
//	}
//	public void setReportStatus(ReportStatus reportStatus) {
//		this.reportStatus = reportStatus;
//	}
	
	
	
}
