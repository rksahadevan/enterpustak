package com.lbc.lctr.fintrac;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class ProcessExcelBatchApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProcessExcelBatchApplication.class, args);
	}

}
