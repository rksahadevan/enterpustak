package com.lbc.lctr.fintrac.common.domain;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.annotation.Generated;
import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * ReportListResponsePayload
 */

@JsonTypeName("ReportListResponse_payload")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-03-29T08:53:00.631912700-04:00[America/New_York]")
public class ReportListResponsePayload {

  @JsonProperty("totalElements")
  private Integer totalElements;

  @JsonProperty("numberOfPages")
  private Integer numberOfPages;

  @JsonProperty("pageSize")
  private Integer pageSize;

  @JsonProperty("pageNumber")
  private Integer pageNumber;

  @JsonProperty("numberOfElements")
  private Integer numberOfElements;

  @JsonProperty("sortBy")
  private String sortBy;

  @JsonProperty("contents")
  @Valid
  private List<ReportListResponsePayloadContentsInner> contents = null;

  public ReportListResponsePayload totalElements(Integer totalElements) {
    this.totalElements = totalElements;
    return this;
  }

  /**
   * The total number of elements in the collection
   * @return totalElements
  */
  
  @Schema(name = "totalElements", example = "100", description = "The total number of elements in the collection", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public Integer getTotalElements() {
    return totalElements;
  }

  public void setTotalElements(Integer totalElements) {
    this.totalElements = totalElements;
  }

  public ReportListResponsePayload numberOfPages(Integer numberOfPages) {
    this.numberOfPages = numberOfPages;
    return this;
  }

  /**
   * The number of pages in the collection
   * @return numberOfPages
  */
  
  @Schema(name = "numberOfPages", example = "5", description = "The number of pages in the collection", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public Integer getNumberOfPages() {
    return numberOfPages;
  }

  public void setNumberOfPages(Integer numberOfPages) {
    this.numberOfPages = numberOfPages;
  }

  public ReportListResponsePayload pageSize(Integer pageSize) {
    this.pageSize = pageSize;
    return this;
  }

  /**
   * The requested page size
   * @return pageSize
  */
  
  @Schema(name = "pageSize", example = "20", description = "The requested page size", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public Integer getPageSize() {
    return pageSize;
  }

  public void setPageSize(Integer pageSize) {
    this.pageSize = pageSize;
  }

  public ReportListResponsePayload pageNumber(Integer pageNumber) {
    this.pageNumber = pageNumber;
    return this;
  }

  /**
   * The requested page
   * @return pageNumber
  */
  
  @Schema(name = "pageNumber", example = "3", description = "The requested page", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public Integer getPageNumber() {
    return pageNumber;
  }

  public void setPageNumber(Integer pageNumber) {
    this.pageNumber = pageNumber;
  }

  public ReportListResponsePayload numberOfElements(Integer numberOfElements) {
    this.numberOfElements = numberOfElements;
    return this;
  }

  /**
   * The number of elements on this page
   * @return numberOfElements
  */
  
  @Schema(name = "numberOfElements", example = "20", description = "The number of elements on this page", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public Integer getNumberOfElements() {
    return numberOfElements;
  }

  public void setNumberOfElements(Integer numberOfElements) {
    this.numberOfElements = numberOfElements;
  }

  public ReportListResponsePayload sortBy(String sortBy) {
    this.sortBy = sortBy;
    return this;
  }

  /**
   * The field to sort by
   * @return sortBy
  */
  
  @Schema(name = "sortBy", example = "createDateTime+", description = "The field to sort by", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getSortBy() {
    return sortBy;
  }

  public void setSortBy(String sortBy) {
    this.sortBy = sortBy;
  }

  public ReportListResponsePayload contents(List<ReportListResponsePayloadContentsInner> contents) {
    this.contents = contents;
    return this;
  }

  public ReportListResponsePayload addContentsItem(ReportListResponsePayloadContentsInner contentsItem) {
    if (this.contents == null) {
      this.contents = new ArrayList<>();
    }
    this.contents.add(contentsItem);
    return this;
  }

  /**
   * Get contents
   * @return contents
  */
  @Valid 
  @Schema(name = "contents", example = "[{\"externalReportUuid\":\"be15da09c1864c7ab3c8af87741c0e7a\",\"reportingEntityReportReference\":\"TestReferenceNumber\",\"createDateTime\":\"2023-01-08T16:20:25.251Z\",\"updateDateTime\":\"2023-02-09T10:18:53.276Z\"}]", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public List<ReportListResponsePayloadContentsInner> getContents() {
    return contents;
  }

  public void setContents(List<ReportListResponsePayloadContentsInner> contents) {
    this.contents = contents;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ReportListResponsePayload reportListResponsePayload = (ReportListResponsePayload) o;
    return Objects.equals(this.totalElements, reportListResponsePayload.totalElements) &&
        Objects.equals(this.numberOfPages, reportListResponsePayload.numberOfPages) &&
        Objects.equals(this.pageSize, reportListResponsePayload.pageSize) &&
        Objects.equals(this.pageNumber, reportListResponsePayload.pageNumber) &&
        Objects.equals(this.numberOfElements, reportListResponsePayload.numberOfElements) &&
        Objects.equals(this.sortBy, reportListResponsePayload.sortBy) &&
        Objects.equals(this.contents, reportListResponsePayload.contents);
  }

  @Override
  public int hashCode() {
    return Objects.hash(totalElements, numberOfPages, pageSize, pageNumber, numberOfElements, sortBy, contents);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ReportListResponsePayload {\n");
    sb.append("    totalElements: ").append(toIndentedString(totalElements)).append("\n");
    sb.append("    numberOfPages: ").append(toIndentedString(numberOfPages)).append("\n");
    sb.append("    pageSize: ").append(toIndentedString(pageSize)).append("\n");
    sb.append("    pageNumber: ").append(toIndentedString(pageNumber)).append("\n");
    sb.append("    numberOfElements: ").append(toIndentedString(numberOfElements)).append("\n");
    sb.append("    sortBy: ").append(toIndentedString(sortBy)).append("\n");
    sb.append("    contents: ").append(toIndentedString(contents)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

