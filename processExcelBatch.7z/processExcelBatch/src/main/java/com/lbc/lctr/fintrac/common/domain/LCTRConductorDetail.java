package com.lbc.lctr.fintrac.common.domain;

import java.util.Objects;

import javax.annotation.Generated;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * LCTRTransactionStartingActionsInnerConductorsInnerDetails
 */

@JsonTypeName("LCTRTransaction_startingActions_inner_conductors_inner_details")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-03-29T08:53:00.631912700-04:00[America/New_York]")
public class LCTRConductorDetail {

  @JsonProperty("clientNumber")
  private String clientNumber;

  @JsonProperty("emailAddress")
  private String emailAddress;

  @JsonProperty("onBehalfOfIndicator")
  private Boolean onBehalfOfIndicator;

  public LCTRConductorDetail clientNumber(String clientNumber) {
    this.clientNumber = clientNumber;
    return this;
  }

  /**
   * Get clientNumber
   * @return clientNumber
  */
  @Size(max = 100) 
  @Schema(name = "clientNumber", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getClientNumber() {
    return clientNumber;
  }

  public void setClientNumber(String clientNumber) {
    this.clientNumber = clientNumber;
  }

  public LCTRConductorDetail emailAddress(String emailAddress) {
    this.emailAddress = emailAddress;
    return this;
  }

  /**
   * Get emailAddress
   * @return emailAddress
  */
  @Size(max = 200) 
  @Schema(name = "emailAddress", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getEmailAddress() {
    return emailAddress;
  }

  public void setEmailAddress(String emailAddress) {
    this.emailAddress = emailAddress;
  }

  public LCTRConductorDetail onBehalfOfIndicator(Boolean onBehalfOfIndicator) {
    this.onBehalfOfIndicator = onBehalfOfIndicator;
    return this;
  }

  /**
   * Get onBehalfOfIndicator
   * @return onBehalfOfIndicator
  */
  @NotNull 
  @Schema(name = "onBehalfOfIndicator", requiredMode = Schema.RequiredMode.REQUIRED)
  public Boolean getOnBehalfOfIndicator() {
    return onBehalfOfIndicator;
  }

  public void setOnBehalfOfIndicator(Boolean onBehalfOfIndicator) {
    this.onBehalfOfIndicator = onBehalfOfIndicator;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    LCTRConductorDetail lcTRTransactionStartingActionsInnerConductorsInnerDetails = (LCTRConductorDetail) o;
    return Objects.equals(this.clientNumber, lcTRTransactionStartingActionsInnerConductorsInnerDetails.clientNumber) &&
        Objects.equals(this.emailAddress, lcTRTransactionStartingActionsInnerConductorsInnerDetails.emailAddress) &&
        Objects.equals(this.onBehalfOfIndicator, lcTRTransactionStartingActionsInnerConductorsInnerDetails.onBehalfOfIndicator);
  }

  @Override
  public int hashCode() {
    return Objects.hash(clientNumber, emailAddress, onBehalfOfIndicator);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class LCTRTransactionStartingActionsInnerConductorsInnerDetails {\n");
    sb.append("    clientNumber: ").append(toIndentedString(clientNumber)).append("\n");
    sb.append("    emailAddress: ").append(toIndentedString(emailAddress)).append("\n");
    sb.append("    onBehalfOfIndicator: ").append(toIndentedString(onBehalfOfIndicator)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

