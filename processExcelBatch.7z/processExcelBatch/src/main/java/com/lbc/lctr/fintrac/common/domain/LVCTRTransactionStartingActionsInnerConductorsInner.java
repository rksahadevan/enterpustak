package com.lbc.lctr.fintrac.common.domain;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.annotation.Generated;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.fasterxml.jackson.annotation.JsonValue;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * LVCTRTransactionStartingActionsInnerConductorsInner
 */

@JsonTypeName("LVCTRTransaction_startingActions_inner_conductors_inner")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-03-29T08:53:00.631912700-04:00[America/New_York]")
public class LVCTRTransactionStartingActionsInnerConductorsInner {

  /**
   * * `3` - Person details / Renseignements au sujet de la personne * `4` - Entity details / Renseignements au sujet de l'entité 
   */
  public enum TypeCodeEnum {
    NUMBER_3(3),
    
    NUMBER_4(4);

    private Integer value;

    TypeCodeEnum(Integer value) {
      this.value = value;
    }

    @JsonValue
    public Integer getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static TypeCodeEnum fromValue(Integer value) {
      for (TypeCodeEnum b : TypeCodeEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  @JsonProperty("typeCode")
  private TypeCodeEnum typeCode;

  @JsonProperty("refId")
  private String refId;

  @JsonProperty("details")
  private LVCTRTransactionStartingActionsInnerConductorsInnerDetails details;

  @JsonProperty("onBehalfOfs")
  @Valid
  private List<LVCTRTransactionStartingActionsInnerConductorsInnerOnBehalfOfsInner> onBehalfOfs = null;

  public LVCTRTransactionStartingActionsInnerConductorsInner typeCode(TypeCodeEnum typeCode) {
    this.typeCode = typeCode;
    return this;
  }

  /**
   * * `3` - Person details / Renseignements au sujet de la personne * `4` - Entity details / Renseignements au sujet de l'entité 
   * @return typeCode
  */
  @NotNull 
  @Schema(name = "typeCode", description = "* `3` - Person details / Renseignements au sujet de la personne * `4` - Entity details / Renseignements au sujet de l'entité ", requiredMode = Schema.RequiredMode.REQUIRED)
  public TypeCodeEnum getTypeCode() {
    return typeCode;
  }

  public void setTypeCode(TypeCodeEnum typeCode) {
    this.typeCode = typeCode;
  }

  public LVCTRTransactionStartingActionsInnerConductorsInner refId(String refId) {
    this.refId = refId;
    return this;
  }

  /**
   * Get refId
   * @return refId
  */
  @NotNull @Size(max = 50) 
  @Schema(name = "refId", requiredMode = Schema.RequiredMode.REQUIRED)
  public String getRefId() {
    return refId;
  }

  public void setRefId(String refId) {
    this.refId = refId;
  }

  public LVCTRTransactionStartingActionsInnerConductorsInner details(LVCTRTransactionStartingActionsInnerConductorsInnerDetails details) {
    this.details = details;
    return this;
  }

  /**
   * Get details
   * @return details
  */
  @NotNull @Valid 
  @Schema(name = "details", requiredMode = Schema.RequiredMode.REQUIRED)
  public LVCTRTransactionStartingActionsInnerConductorsInnerDetails getDetails() {
    return details;
  }

  public void setDetails(LVCTRTransactionStartingActionsInnerConductorsInnerDetails details) {
    this.details = details;
  }

  public LVCTRTransactionStartingActionsInnerConductorsInner onBehalfOfs(List<LVCTRTransactionStartingActionsInnerConductorsInnerOnBehalfOfsInner> onBehalfOfs) {
    this.onBehalfOfs = onBehalfOfs;
    return this;
  }

  public LVCTRTransactionStartingActionsInnerConductorsInner addOnBehalfOfsItem(LVCTRTransactionStartingActionsInnerConductorsInnerOnBehalfOfsInner onBehalfOfsItem) {
    if (this.onBehalfOfs == null) {
      this.onBehalfOfs = new ArrayList<>();
    }
    this.onBehalfOfs.add(onBehalfOfsItem);
    return this;
  }

  /**
   * Get onBehalfOfs
   * @return onBehalfOfs
  */
  @Valid 
  @Schema(name = "onBehalfOfs", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public List<LVCTRTransactionStartingActionsInnerConductorsInnerOnBehalfOfsInner> getOnBehalfOfs() {
    return onBehalfOfs;
  }

  public void setOnBehalfOfs(List<LVCTRTransactionStartingActionsInnerConductorsInnerOnBehalfOfsInner> onBehalfOfs) {
    this.onBehalfOfs = onBehalfOfs;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    LVCTRTransactionStartingActionsInnerConductorsInner lvCTRTransactionStartingActionsInnerConductorsInner = (LVCTRTransactionStartingActionsInnerConductorsInner) o;
    return Objects.equals(this.typeCode, lvCTRTransactionStartingActionsInnerConductorsInner.typeCode) &&
        Objects.equals(this.refId, lvCTRTransactionStartingActionsInnerConductorsInner.refId) &&
        Objects.equals(this.details, lvCTRTransactionStartingActionsInnerConductorsInner.details) &&
        Objects.equals(this.onBehalfOfs, lvCTRTransactionStartingActionsInnerConductorsInner.onBehalfOfs);
  }

  @Override
  public int hashCode() {
    return Objects.hash(typeCode, refId, details, onBehalfOfs);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class LVCTRTransactionStartingActionsInnerConductorsInner {\n");
    sb.append("    typeCode: ").append(toIndentedString(typeCode)).append("\n");
    sb.append("    refId: ").append(toIndentedString(refId)).append("\n");
    sb.append("    details: ").append(toIndentedString(details)).append("\n");
    sb.append("    onBehalfOfs: ").append(toIndentedString(onBehalfOfs)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

