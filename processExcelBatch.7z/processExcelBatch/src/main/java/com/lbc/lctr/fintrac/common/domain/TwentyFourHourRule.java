package com.lbc.lctr.fintrac.common.domain;

import java.util.Objects;

import javax.annotation.Generated;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.fasterxml.jackson.annotation.JsonValue;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * ReportReportDetailsTwentyFourHourRule
 */

@JsonTypeName("Report_reportDetails_twentyFourHourRule")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-03-29T08:53:00.631912700-04:00[America/New_York]")
public class TwentyFourHourRule {

  /**
   * * `1` - Beneficiary / Bénéficiaire * `2` - Conductor / Personne qui a effectué l'opération * `3` - On behalf of (i.e. 3rd party) / Au nom de (i.e. tierce partie) * `4` - Not applicable / Sans objet 
   */
  public enum AggregationTypeCodeEnum {
    NUMBER_1(1),
    
    NUMBER_2(2),
    
    NUMBER_3(3),
    
    NUMBER_4(4);

    private Integer value;

    AggregationTypeCodeEnum(Integer value) {
      this.value = value;
    }

    @JsonValue
    public Integer getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static AggregationTypeCodeEnum fromValue(Integer value) {
      for (AggregationTypeCodeEnum b : AggregationTypeCodeEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  @JsonProperty("aggregationTypeCode")
  private AggregationTypeCodeEnum aggregationTypeCode;

  @JsonProperty("periodStart")
  private String periodStart;

  @JsonProperty("periodEnd")
  private String periodEnd;

  public TwentyFourHourRule aggregationTypeCode(AggregationTypeCodeEnum aggregationTypeCode) {
    this.aggregationTypeCode = aggregationTypeCode;
    return this;
  }

  /**
   * * `1` - Beneficiary / Bénéficiaire * `2` - Conductor / Personne qui a effectué l'opération * `3` - On behalf of (i.e. 3rd party) / Au nom de (i.e. tierce partie) * `4` - Not applicable / Sans objet 
   * @return aggregationTypeCode
  */
  @NotNull 
  @Schema(name = "aggregationTypeCode", description = "* `1` - Beneficiary / Bénéficiaire * `2` - Conductor / Personne qui a effectué l'opération * `3` - On behalf of (i.e. 3rd party) / Au nom de (i.e. tierce partie) * `4` - Not applicable / Sans objet ", requiredMode = Schema.RequiredMode.REQUIRED)
  public AggregationTypeCodeEnum getAggregationTypeCode() {
    return aggregationTypeCode;
  }

  public void setAggregationTypeCode(AggregationTypeCodeEnum aggregationTypeCode) {
    this.aggregationTypeCode = aggregationTypeCode;
  }

  public TwentyFourHourRule periodStart(String periodStart) {
    this.periodStart = periodStart;
    return this;
  }

  /**
   * Get periodStart
   * @return periodStart
  */
  @Pattern(regexp = "^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}[\\\\-\\\\+][0-9]{2}:[0-9]{2}$") 
  @Schema(name = "periodStart", example = "2020-11-19T00:00:00-05:00", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getPeriodStart() {
    return periodStart;
  }

  public void setPeriodStart(String periodStart) {
    this.periodStart = periodStart;
  }

  public TwentyFourHourRule periodEnd(String periodEnd) {
    this.periodEnd = periodEnd;
    return this;
  }

  /**
   * Get periodEnd
   * @return periodEnd
  */
  @Pattern(regexp = "^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}[\\\\-\\\\+][0-9]{2}:[0-9]{2}$") 
  @Schema(name = "periodEnd", example = "2020-11-19T23:59:59-05:00", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getPeriodEnd() {
    return periodEnd;
  }

  public void setPeriodEnd(String periodEnd) {
    this.periodEnd = periodEnd;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    TwentyFourHourRule reportReportDetailsTwentyFourHourRule = (TwentyFourHourRule) o;
    return Objects.equals(this.aggregationTypeCode, reportReportDetailsTwentyFourHourRule.aggregationTypeCode) &&
        Objects.equals(this.periodStart, reportReportDetailsTwentyFourHourRule.periodStart) &&
        Objects.equals(this.periodEnd, reportReportDetailsTwentyFourHourRule.periodEnd);
  }

  @Override
  public int hashCode() {
    return Objects.hash(aggregationTypeCode, periodStart, periodEnd);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ReportReportDetailsTwentyFourHourRule {\n");
    sb.append("    aggregationTypeCode: ").append(toIndentedString(aggregationTypeCode)).append("\n");
    sb.append("    periodStart: ").append(toIndentedString(periodStart)).append("\n");
    sb.append("    periodEnd: ").append(toIndentedString(periodEnd)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

