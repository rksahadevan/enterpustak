package com.lbc.lctr.fintrac.common.domain;

import javax.annotation.Generated;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

/**
 * * 'AB' - Alberta / Alberta * 'BC' - British Columbia / Colombie-Britannique * 'MB' - Manitoba / Manitoba * 'NB' - New Brunswick / Nouveau-Brunswick * 'NL' - Newfoundland and Labrador / Terre-Neuve et Labrador * 'NT' - Northwest Territories / Territoires du Nord-Ouest * 'NS' - Nova Scotia / Nouvelle-Écosse * 'NU' - Nunavut / Nunavut * 'ON' - Ontario / Ontario * 'PE' - Prince Edward Island / Île-du-Prince-Édouard * 'QC' - Quebec / Québec * 'SK' - Saskatchewan / Saskatchewan * 'YT' - Yukon / Yukon 
 */

@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-03-29T08:53:00.631912700-04:00[America/New_York]")
public enum ProvinceStateCodeOneOf {
  
  AB("AB"),
  
  BC("BC"),
  
  MB("MB"),
  
  NB("NB"),
  
  NL("NL"),
  
  NT("NT"),
  
  NS("NS"),
  
  NU("NU"),
  
  ON("ON"),
  
  PE("PE"),
  
  QC("QC"),
  
  SK("SK"),
  
  YT("YT");

  private String value;

  ProvinceStateCodeOneOf(String value) {
    this.value = value;
  }

  @JsonValue
  public String getValue() {
    return value;
  }

  @Override
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static ProvinceStateCodeOneOf fromValue(String value) {
    for (ProvinceStateCodeOneOf b : ProvinceStateCodeOneOf.values()) {
      if (b.value.equals(value)) {
        return b;
      }
    }
    throw new IllegalArgumentException("Unexpected value '" + value + "'");
  }
}

