package com.lbc.lctr.fintrac.common.domain;

import java.util.Objects;

import javax.annotation.Generated;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.fasterxml.jackson.annotation.JsonValue;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * LCTRTransactionCompletingActionsInnerDetails
 */

@JsonTypeName("LCTRTransaction_completingActions_inner_details")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-03-29T08:53:00.631912700-04:00[America/New_York]")
public class LCTRCompletingActionDetail {

  /**
   * Gets or Sets dispositionCode
   */
  public enum DispositionCodeEnum {
    NUMBER_1(1),
    
    NUMBER_3(3),
    
    NUMBER_4(4),
    
    NUMBER_5(5),
    
    NUMBER_6(6),
    
    NUMBER_7(7),
    
    NUMBER_8(8),
    
    NUMBER_9(9),
    
    NUMBER_11(11),
    
    NUMBER_14(14),
    
    NUMBER_15(15),
    
    NUMBER_17(17),
    
    NUMBER_18(18),
    
    NUMBER_19(19),
    
    NUMBER_21(21),
    
    NUMBER_22(22),
    
    NUMBER_23(23),
    
    NUMBER_24(24),
    
    NUMBER_25(25),
    
    NUMBER_26(26),
    
    NUMBER_27(27),
    
    NUMBER_28(28),
    
    NUMBER_29(29),
    
    NUMBER_30(30),
    
    NUMBER_31(31),
    
    NUMBER_32(32);

    private Integer value;

    DispositionCodeEnum(Integer value) {
      this.value = value;
    }

    @JsonValue
    public Integer getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static DispositionCodeEnum fromValue(Integer value) {
      for (DispositionCodeEnum b : DispositionCodeEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  @JsonProperty("dispositionCode")
  private DispositionCodeEnum dispositionCode;

  @JsonProperty("dispositionOther")
  private String dispositionOther;

  @JsonProperty("amount")
  private String amount;

  @JsonProperty("currencyCode")
  private CurrencyCode currencyCode;

  @JsonProperty("virtualCurrencyTypeCode")
  private VirtualCurrencyCode virtualCurrencyTypeCode;

  @JsonProperty("virtualCurrencyTypeOther")
  private String virtualCurrencyTypeOther;

  @JsonProperty("exchangeRate")
  private String exchangeRate;

  @JsonProperty("valueInCanadianDollars")
  private String valueInCanadianDollars;

  @JsonProperty("referenceNumber")
  private String referenceNumber;

  @JsonProperty("referenceNumberOtherRelatedNumber")
  private String referenceNumberOtherRelatedNumber;

  @JsonProperty("account")
  private LCTRAccountDetail account;
  
  @JsonProperty("involvementIndicator")
  private boolean involvementIndicator;

  public LCTRCompletingActionDetail dispositionCode(DispositionCodeEnum dispositionCode) {
    this.dispositionCode = dispositionCode;
    return this;
  }

  /**
   * Get dispositionCode
   * @return dispositionCode
  */
  @NotNull 
  @Schema(name = "dispositionCode", requiredMode = Schema.RequiredMode.REQUIRED)
  public DispositionCodeEnum getDispositionCode() {
    return dispositionCode;
  }

  public void setDispositionCode(DispositionCodeEnum dispositionCode) {
    this.dispositionCode = dispositionCode;
  }

  public LCTRCompletingActionDetail dispositionOther(String dispositionOther) {
    this.dispositionOther = dispositionOther;
    return this;
  }

  /**
   * Get dispositionOther
   * @return dispositionOther
  */
  @Size(max = 200) 
  @Schema(name = "dispositionOther", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getDispositionOther() {
    return dispositionOther;
  }

  public void setDispositionOther(String dispositionOther) {
    this.dispositionOther = dispositionOther;
  }

  public LCTRCompletingActionDetail amount(String amount) {
    this.amount = amount;
    return this;
  }

  /**
   * Get amount
   * @return amount
  */
  @Pattern(regexp = "^\\\\d{1,17}(\\\\.\\\\d{2,10})?$") 
  @Schema(name = "amount", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getAmount() {
    return amount;
  }

  public void setAmount(String amount) {
    this.amount = amount;
  }

  public LCTRCompletingActionDetail currencyCode(CurrencyCode currencyCode) {
    this.currencyCode = currencyCode;
    return this;
  }

  /**
   * Get currencyCode
   * @return currencyCode
  */
  @Valid 
  @Schema(name = "currencyCode", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public CurrencyCode getCurrencyCode() {
    return currencyCode;
  }

  public void setCurrencyCode(CurrencyCode currencyCode) {
    this.currencyCode = currencyCode;
  }

  public LCTRCompletingActionDetail virtualCurrencyTypeCode(VirtualCurrencyCode virtualCurrencyTypeCode) {
    this.virtualCurrencyTypeCode = virtualCurrencyTypeCode;
    return this;
  }

  /**
   * Get virtualCurrencyTypeCode
   * @return virtualCurrencyTypeCode
  */
  @Valid 
  @Schema(name = "virtualCurrencyTypeCode", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public VirtualCurrencyCode getVirtualCurrencyTypeCode() {
    return virtualCurrencyTypeCode;
  }

  public void setVirtualCurrencyTypeCode(VirtualCurrencyCode virtualCurrencyTypeCode) {
    this.virtualCurrencyTypeCode = virtualCurrencyTypeCode;
  }

  public LCTRCompletingActionDetail virtualCurrencyTypeOther(String virtualCurrencyTypeOther) {
    this.virtualCurrencyTypeOther = virtualCurrencyTypeOther;
    return this;
  }

  /**
   * Get virtualCurrencyTypeOther
   * @return virtualCurrencyTypeOther
  */
  @Size(max = 200) 
  @Schema(name = "virtualCurrencyTypeOther", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getVirtualCurrencyTypeOther() {
    return virtualCurrencyTypeOther;
  }

  public void setVirtualCurrencyTypeOther(String virtualCurrencyTypeOther) {
    this.virtualCurrencyTypeOther = virtualCurrencyTypeOther;
  }

  public LCTRCompletingActionDetail exchangeRate(String exchangeRate) {
    this.exchangeRate = exchangeRate;
    return this;
  }

  /**
   * Get exchangeRate
   * @return exchangeRate
  */
  @Pattern(regexp = "^\\\\d{1,17}(\\\\.\\\\d{2,10})?$") 
  @Schema(name = "exchangeRate", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getExchangeRate() {
    return exchangeRate;
  }

  public void setExchangeRate(String exchangeRate) {
    this.exchangeRate = exchangeRate;
  }

  public LCTRCompletingActionDetail valueInCanadianDollars(String valueInCanadianDollars) {
    this.valueInCanadianDollars = valueInCanadianDollars;
    return this;
  }

  /**
   * Get valueInCanadianDollars
   * @return valueInCanadianDollars
  */
  @Pattern(regexp = "^\\\\d{1,17}(\\\\.\\\\d{2,10})?$") 
  @Schema(name = "valueInCanadianDollars", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getValueInCanadianDollars() {
    return valueInCanadianDollars;
  }

  public void setValueInCanadianDollars(String valueInCanadianDollars) {
    this.valueInCanadianDollars = valueInCanadianDollars;
  }

  public LCTRCompletingActionDetail referenceNumber(String referenceNumber) {
    this.referenceNumber = referenceNumber;
    return this;
  }

  /**
   * Get referenceNumber
   * @return referenceNumber
  */
  @Size(max = 200) 
  @Schema(name = "referenceNumber", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getReferenceNumber() {
    return referenceNumber;
  }

  public void setReferenceNumber(String referenceNumber) {
    this.referenceNumber = referenceNumber;
  }

  public LCTRCompletingActionDetail referenceNumberOtherRelatedNumber(String referenceNumberOtherRelatedNumber) {
    this.referenceNumberOtherRelatedNumber = referenceNumberOtherRelatedNumber;
    return this;
  }

  /**
   * Get referenceNumberOtherRelatedNumber
   * @return referenceNumberOtherRelatedNumber
  */
  @Size(max = 200) 
  @Schema(name = "referenceNumberOtherRelatedNumber", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getReferenceNumberOtherRelatedNumber() {
    return referenceNumberOtherRelatedNumber;
  }

  public void setReferenceNumberOtherRelatedNumber(String referenceNumberOtherRelatedNumber) {
    this.referenceNumberOtherRelatedNumber = referenceNumberOtherRelatedNumber;
  }

  public LCTRCompletingActionDetail account(LCTRAccountDetail account) {
    this.account = account;
    return this;
  }

  /**
   * Get account
   * @return account
  */
  @Valid 
  @Schema(name = "account", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public LCTRAccountDetail getAccount() {
    return account;
  }

  public void setAccount(LCTRAccountDetail account) {
    this.account = account;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    LCTRCompletingActionDetail lcTRTransactionCompletingActionsInnerDetails = (LCTRCompletingActionDetail) o;
    return Objects.equals(this.dispositionCode, lcTRTransactionCompletingActionsInnerDetails.dispositionCode) &&
        Objects.equals(this.dispositionOther, lcTRTransactionCompletingActionsInnerDetails.dispositionOther) &&
        Objects.equals(this.amount, lcTRTransactionCompletingActionsInnerDetails.amount) &&
        Objects.equals(this.currencyCode, lcTRTransactionCompletingActionsInnerDetails.currencyCode) &&
        Objects.equals(this.virtualCurrencyTypeCode, lcTRTransactionCompletingActionsInnerDetails.virtualCurrencyTypeCode) &&
        Objects.equals(this.virtualCurrencyTypeOther, lcTRTransactionCompletingActionsInnerDetails.virtualCurrencyTypeOther) &&
        Objects.equals(this.exchangeRate, lcTRTransactionCompletingActionsInnerDetails.exchangeRate) &&
        Objects.equals(this.valueInCanadianDollars, lcTRTransactionCompletingActionsInnerDetails.valueInCanadianDollars) &&
        Objects.equals(this.referenceNumber, lcTRTransactionCompletingActionsInnerDetails.referenceNumber) &&
        Objects.equals(this.referenceNumberOtherRelatedNumber, lcTRTransactionCompletingActionsInnerDetails.referenceNumberOtherRelatedNumber) &&
        Objects.equals(this.account, lcTRTransactionCompletingActionsInnerDetails.account);
  }

  @Override
  public int hashCode() {
    return Objects.hash(dispositionCode, dispositionOther, amount, currencyCode, virtualCurrencyTypeCode, virtualCurrencyTypeOther, exchangeRate, valueInCanadianDollars, referenceNumber, referenceNumberOtherRelatedNumber, account);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class LCTRTransactionCompletingActionsInnerDetails {\n");
    sb.append("    dispositionCode: ").append(toIndentedString(dispositionCode)).append("\n");
    sb.append("    dispositionOther: ").append(toIndentedString(dispositionOther)).append("\n");
    sb.append("    amount: ").append(toIndentedString(amount)).append("\n");
    sb.append("    currencyCode: ").append(toIndentedString(currencyCode)).append("\n");
    sb.append("    virtualCurrencyTypeCode: ").append(toIndentedString(virtualCurrencyTypeCode)).append("\n");
    sb.append("    virtualCurrencyTypeOther: ").append(toIndentedString(virtualCurrencyTypeOther)).append("\n");
    sb.append("    exchangeRate: ").append(toIndentedString(exchangeRate)).append("\n");
    sb.append("    valueInCanadianDollars: ").append(toIndentedString(valueInCanadianDollars)).append("\n");
    sb.append("    referenceNumber: ").append(toIndentedString(referenceNumber)).append("\n");
    sb.append("    referenceNumberOtherRelatedNumber: ").append(toIndentedString(referenceNumberOtherRelatedNumber)).append("\n");
    sb.append("    account: ").append(toIndentedString(account)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

public boolean isInvolvementIndicator() {
	return involvementIndicator;
}

public void setInvolvementIndicator(boolean involvementIndicator) {
	this.involvementIndicator = involvementIndicator;
}
}

