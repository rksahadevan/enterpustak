package com.lbc.lctr.fintrac.common.domain;

import java.util.Objects;

import javax.annotation.Generated;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.fasterxml.jackson.annotation.JsonValue;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * LCTRTransactionLargeCashTransactionDetails
 */

@JsonTypeName("LCTRTransaction_largeCashTransactionDetails")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-03-29T08:53:00.631912700-04:00[America/New_York]")
public class LCTRTransactionDetails {

  @JsonProperty("thresholdIndicator")
  private Boolean thresholdIndicator;

  @JsonProperty("dateTimeOfTransaction")
  private String dateTimeOfTransaction;

  /**
   * Gets or Sets methodCode
   */
  public enum MethodCodeEnum {
    NUMBER_1(1),
    
    NUMBER_2(2),
    
    NUMBER_3(3),
    
    NUMBER_4(4),
    
    NUMBER_5(5),
    
    NUMBER_7(7),
    
    NUMBER_8(8),
    
    NUMBER_9(9),
    
    NUMBER_10(10),
    
    NUMBER_11(11);

    private Integer value;

    MethodCodeEnum(Integer value) {
      this.value = value;
    }

    @JsonValue
    public Integer getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static MethodCodeEnum fromValue(Integer value) {
      for (MethodCodeEnum b : MethodCodeEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  @JsonProperty("methodCode")
  private MethodCodeEnum methodCode;

  @JsonProperty("methodOther")
  private String methodOther;

  @JsonProperty("dateTimeOfPosting")
  private String dateTimeOfPosting;

  @JsonProperty("reportingEntityTransactionReference")
  private String reportingEntityTransactionReference;

  @JsonProperty("purpose")
  private String purpose;

  public LCTRTransactionDetails thresholdIndicator(Boolean thresholdIndicator) {
    this.thresholdIndicator = thresholdIndicator;
    return this;
  }

  /**
   * Get thresholdIndicator
   * @return thresholdIndicator
  */
  
  @Schema(name = "thresholdIndicator", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public Boolean getThresholdIndicator() {
    return thresholdIndicator;
  }

  public void setThresholdIndicator(Boolean thresholdIndicator) {
    this.thresholdIndicator = thresholdIndicator;
  }

  public LCTRTransactionDetails dateTimeOfTransaction(String dateTimeOfTransaction) {
    this.dateTimeOfTransaction = dateTimeOfTransaction;
    return this;
  }

  /**
   * Get dateTimeOfTransaction
   * @return dateTimeOfTransaction
  */
  @Pattern(regexp = "^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}[\\\\-\\\\+][0-9]{2}:[0-9]{2}$") 
  @Schema(name = "dateTimeOfTransaction", example = "2020-11-19T23:59:59-05:00", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getDateTimeOfTransaction() {
    return dateTimeOfTransaction;
  }

  public void setDateTimeOfTransaction(String dateTimeOfTransaction) {
    this.dateTimeOfTransaction = dateTimeOfTransaction;
  }

  public LCTRTransactionDetails methodCode(MethodCodeEnum methodCode) {
    this.methodCode = methodCode;
    return this;
  }

  /**
   * Get methodCode
   * @return methodCode
  */
  
  @Schema(name = "methodCode", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public MethodCodeEnum getMethodCode() {
    return methodCode;
  }

  public void setMethodCode(MethodCodeEnum methodCode) {
    this.methodCode = methodCode;
  }

  public LCTRTransactionDetails methodOther(String methodOther) {
    this.methodOther = methodOther;
    return this;
  }

  /**
   * Get methodOther
   * @return methodOther
  */
  @Size(max = 200) 
  @Schema(name = "methodOther", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getMethodOther() {
    return methodOther;
  }

  public void setMethodOther(String methodOther) {
    this.methodOther = methodOther;
  }

  public LCTRTransactionDetails dateTimeOfPosting(String dateTimeOfPosting) {
    this.dateTimeOfPosting = dateTimeOfPosting;
    return this;
  }

  /**
   * Get dateTimeOfPosting
   * @return dateTimeOfPosting
  */
  @Pattern(regexp = "^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}[\\\\-\\\\+][0-9]{2}:[0-9]{2}$") 
  @Schema(name = "dateTimeOfPosting", example = "2020-11-19T23:59:59-05:00", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getDateTimeOfPosting() {
    return dateTimeOfPosting;
  }

  public void setDateTimeOfPosting(String dateTimeOfPosting) {
    this.dateTimeOfPosting = dateTimeOfPosting;
  }

  public LCTRTransactionDetails reportingEntityTransactionReference(String reportingEntityTransactionReference) {
    this.reportingEntityTransactionReference = reportingEntityTransactionReference;
    return this;
  }

  /**
   * Get reportingEntityTransactionReference
   * @return reportingEntityTransactionReference
  */
  @Size(max = 200) 
  @Schema(name = "reportingEntityTransactionReference", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getReportingEntityTransactionReference() {
    return reportingEntityTransactionReference;
  }

  public void setReportingEntityTransactionReference(String reportingEntityTransactionReference) {
    this.reportingEntityTransactionReference = reportingEntityTransactionReference;
  }

  public LCTRTransactionDetails purpose(String purpose) {
    this.purpose = purpose;
    return this;
  }

  /**
   * Get purpose
   * @return purpose
  */
  @Size(max = 200) 
  @Schema(name = "purpose", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getPurpose() {
    return purpose;
  }

  public void setPurpose(String purpose) {
    this.purpose = purpose;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    LCTRTransactionDetails lcTRTransactionLargeCashTransactionDetails = (LCTRTransactionDetails) o;
    return Objects.equals(this.thresholdIndicator, lcTRTransactionLargeCashTransactionDetails.thresholdIndicator) &&
        Objects.equals(this.dateTimeOfTransaction, lcTRTransactionLargeCashTransactionDetails.dateTimeOfTransaction) &&
        Objects.equals(this.methodCode, lcTRTransactionLargeCashTransactionDetails.methodCode) &&
        Objects.equals(this.methodOther, lcTRTransactionLargeCashTransactionDetails.methodOther) &&
        Objects.equals(this.dateTimeOfPosting, lcTRTransactionLargeCashTransactionDetails.dateTimeOfPosting) &&
        Objects.equals(this.reportingEntityTransactionReference, lcTRTransactionLargeCashTransactionDetails.reportingEntityTransactionReference) &&
        Objects.equals(this.purpose, lcTRTransactionLargeCashTransactionDetails.purpose);
  }

  @Override
  public int hashCode() {
    return Objects.hash(thresholdIndicator, dateTimeOfTransaction, methodCode, methodOther, dateTimeOfPosting, reportingEntityTransactionReference, purpose);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class LCTRTransactionLargeCashTransactionDetails {\n");
    sb.append("    thresholdIndicator: ").append(toIndentedString(thresholdIndicator)).append("\n");
    sb.append("    dateTimeOfTransaction: ").append(toIndentedString(dateTimeOfTransaction)).append("\n");
    sb.append("    methodCode: ").append(toIndentedString(methodCode)).append("\n");
    sb.append("    methodOther: ").append(toIndentedString(methodOther)).append("\n");
    sb.append("    dateTimeOfPosting: ").append(toIndentedString(dateTimeOfPosting)).append("\n");
    sb.append("    reportingEntityTransactionReference: ").append(toIndentedString(reportingEntityTransactionReference)).append("\n");
    sb.append("    purpose: ").append(toIndentedString(purpose)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

