package com.lbc.lctr.fintrac.listener;

import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;

public class PreProcLogStepListener implements StepExecutionListener {
	
	private static final Logger log = LoggerFactory.getLogger(PreProcLogStepListener.class);
	
	@Override
	public void beforeStep(StepExecution stepExecution) {
		
		
		String filePath = (String) stepExecution.getExecutionContext().get("fileName");
		String fileName = FilenameUtils.getName(filePath);
		
		
		
		MDC.put("logFileName", fileName);
		log.info("start  of processing PreProcStepListener the file "+fileName);
		
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		List<Throwable> failureExceptions = stepExecution.getFailureExceptions();

		ExitStatus es = stepExecution.getExitStatus();
		
		String filePath = (String) stepExecution.getExecutionContext().get("fileName");
		String fileName = FilenameUtils.getName(filePath);
		
		log.info("Completion of processing the file "+fileName);
		
	//	MDC.remove("logFileName");

		

		return stepExecution.getExitStatus();
	}

}