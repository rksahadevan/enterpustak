package com.lbc.lctr.fintrac.common.domain;

import java.math.BigDecimal;
import java.util.Objects;

import javax.annotation.Generated;
import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * ReportListResponse
 */

@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-03-29T08:53:00.631912700-04:00[America/New_York]")
public class ReportListResponse {

  @JsonProperty("code")
  private BigDecimal code;

  @JsonProperty("message")
  private ReportListResponseMessage message;

  @JsonProperty("payload")
  private ReportListResponsePayload payload;

  public ReportListResponse code(BigDecimal code) {
    this.code = code;
    return this;
  }

  /**
   * Status code
   * @return code
  */
  @Valid 
  @Schema(name = "code", description = "Status code", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public BigDecimal getCode() {
    return code;
  }

  public void setCode(BigDecimal code) {
    this.code = code;
  }

  public ReportListResponse message(ReportListResponseMessage message) {
    this.message = message;
    return this;
  }

  /**
   * Get message
   * @return message
  */
  @Valid 
  @Schema(name = "message", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public ReportListResponseMessage getMessage() {
    return message;
  }

  public void setMessage(ReportListResponseMessage message) {
    this.message = message;
  }

  public ReportListResponse payload(ReportListResponsePayload payload) {
    this.payload = payload;
    return this;
  }

  /**
   * Get payload
   * @return payload
  */
  @Valid 
  @Schema(name = "payload", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public ReportListResponsePayload getPayload() {
    return payload;
  }

  public void setPayload(ReportListResponsePayload payload) {
    this.payload = payload;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ReportListResponse reportListResponse = (ReportListResponse) o;
    return Objects.equals(this.code, reportListResponse.code) &&
        Objects.equals(this.message, reportListResponse.message) &&
        Objects.equals(this.payload, reportListResponse.payload);
  }

  @Override
  public int hashCode() {
    return Objects.hash(code, message, payload);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ReportListResponse {\n");
    sb.append("    code: ").append(toIndentedString(code)).append("\n");
    sb.append("    message: ").append(toIndentedString(message)).append("\n");
    sb.append("    payload: ").append(toIndentedString(payload)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

