package com.lbc.lctr.fintrac.common.domain;

import java.util.Objects;

import javax.annotation.Generated;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonValue;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * UnstructuredAddress
 */

@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-03-29T08:53:00.631912700-04:00[America/New_York]")
@JsonTypeInfo(use=JsonTypeInfo.Id.CLASS, include=JsonTypeInfo.As.PROPERTY, property="@class")

public class UnstructuredAddress implements PersonDetailsAddress {

  /**
   * type code for unstructured address / Type de code pour une adresse de format non structuré
   */
  public enum TypeCodeEnum {
    NUMBER_2(2);

    private Integer value;

    TypeCodeEnum(Integer value) {
      this.value = value;
    }

    @JsonValue
    public Integer getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static TypeCodeEnum fromValue(Integer value) {
      for (TypeCodeEnum b : TypeCodeEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  @JsonProperty("typeCode")
  private TypeCodeEnum typeCode;

  @JsonProperty("countryCode")
  private CountryCode countryCode;

  @JsonProperty("unstructured")
  private String unstructured;

  public UnstructuredAddress typeCode(TypeCodeEnum typeCode) {
    this.typeCode = typeCode;
    return this;
  }

  /**
   * type code for unstructured address / Type de code pour une adresse de format non structuré
   * @return typeCode
  */
  @NotNull 
  @Schema(name = "typeCode", description = "type code for unstructured address / Type de code pour une adresse de format non structuré", requiredMode = Schema.RequiredMode.REQUIRED)
  public TypeCodeEnum getTypeCode() {
    return typeCode;
  }

  public void setTypeCode(TypeCodeEnum typeCode) {
    this.typeCode = typeCode;
  }

  public UnstructuredAddress countryCode(CountryCode countryCode) {
    this.countryCode = countryCode;
    return this;
  }

  /**
   * Get countryCode
   * @return countryCode
  */
  @NotNull @Valid 
  @Schema(name = "countryCode", requiredMode = Schema.RequiredMode.REQUIRED)
  public CountryCode getCountryCode() {
    return countryCode;
  }

  public void setCountryCode(CountryCode countryCode) {
    this.countryCode = countryCode;
  }

  public UnstructuredAddress unstructured(String unstructured) {
    this.unstructured = unstructured;
    return this;
  }

  /**
   * Get unstructured
   * @return unstructured
  */
  @NotNull @Size(max = 500) 
  @Schema(name = "unstructured", requiredMode = Schema.RequiredMode.REQUIRED)
  public String getUnstructured() {
    return unstructured;
  }

  public void setUnstructured(String unstructured) {
    this.unstructured = unstructured;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    UnstructuredAddress unstructuredAddress = (UnstructuredAddress) o;
    return Objects.equals(this.typeCode, unstructuredAddress.typeCode) &&
        Objects.equals(this.countryCode, unstructuredAddress.countryCode) &&
        Objects.equals(this.unstructured, unstructuredAddress.unstructured);
  }

  @Override
  public int hashCode() {
    return Objects.hash(typeCode, countryCode, unstructured);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class UnstructuredAddress {\n");
    sb.append("    typeCode: ").append(toIndentedString(typeCode)).append("\n");
    sb.append("    countryCode: ").append(toIndentedString(countryCode)).append("\n");
    sb.append("    unstructured: ").append(toIndentedString(unstructured)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

