package com.lbc.lctr.fintrac;

public class FintracUtil {
	public static final String QUERY_INSERT_JSON_PAYLOAD = "INSERT INTO Report_Table "
			+ " (ID,BATCH_ID,REPORT_DATA,REF_NO,SENT_TIME,CREATE_TIME,START_TIME,END_TIME,TOTAL_TXNS,STATUS,CREATED_BY,MODIFIED_BY,MODIFIED_TIME) "
			+ " VALUES (?,?,?,?,sysdate,sysdate,sysdate,sysdate,?,?,system,system,sysdate)";
}
