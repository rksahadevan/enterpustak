package com.lbc.lctr.fintrac.common.domain;

import java.util.List;

/**
 * domain object for the batch.
 * @author PateP2
 *
 */
public class ReportBatch {
    
	private String batchNumber;
	private String batchId;
	private Integer numberofTransactions;
	private List<ReportContainer> reports;
	public String getBatchNumber() {
		return batchNumber;
	}
	public void setBatchNumber(String batchNumber) {
		this.batchNumber = batchNumber;
	}
	public Integer getNumberofTransactions() {
		return numberofTransactions;
	}
	public void setNumberofTransactions(Integer numberofTransactions) {
		this.numberofTransactions = numberofTransactions;
	}
	
	public String getBatchId() {
		return batchId;
	}
	public void setBatchId(String batchId) {
		this.batchId = batchId;
	}
	public List<ReportContainer> getReports() {
		return reports;
	}
	public void setReports(List<ReportContainer> reports) {
		this.reports = reports;
	}
	
	
	
}
