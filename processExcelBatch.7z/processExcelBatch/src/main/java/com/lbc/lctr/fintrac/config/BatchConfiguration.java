package com.lbc.lctr.fintrac.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.partition.support.Partitioner;
import org.springframework.batch.extensions.excel.poi.PoiItemReader;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.database.ItemPreparedStatementSetter;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.lbc.lctr.fintrac.FintracUtil;
import com.lbc.lctr.fintrac.common.domain.LCTRReport;
import com.lbc.lctr.fintrac.listener.PreProcJobListener;
import com.lbc.lctr.fintrac.listener.PreProcLogStepListener;
import com.lbc.lctr.fintrac.listener.PreProcSkipListener;
import com.lbc.lctr.fintrac.listener.PreProcStepListener;
import com.lbc.lctr.fintrac.mapper.DataLoadSetter;
import com.lbc.lctr.fintrac.mapper.ExcelRowMapper;
import com.lbc.lctr.fintrac.partitioner.CustomMultiResourcePartitioner;
import com.lbc.lctr.fintrac.processor.ExcelProcessor;
import com.lbc.lctr.fintrac.tasklet.MoveErrorFilesTasklet;
import com.lbc.lctr.fintrac.tasklet.MoveFilesTasklet;



@Configuration
@EnableBatchProcessing
public class BatchConfiguration {

	Logger logger = LoggerFactory.getLogger(BatchConfiguration.class);

	@Value("${files.input.path}")
	private String resourcesPath;
	@Value("${files.error.path}")
	private String errorPath;
	@Value("${files.success.path}")
	private String sucessPath;
	@Value("${files.types}")
	private String fileType;

	@Value("${thread.maxPool.Size}")
	private Integer threadPoolSize;
	@Value("${thread.corePool.Size}")
	private Integer threadCorePoolSize;
	@Value("${thread.queuePool.Size}")
	private Integer threadQueuePoolSize;
	@Value("${batch.commit.chunk}")
	private Integer chunkSize;
	@Value("${batch.error.skipCount}")
	private Integer skipErrorCount;
;
	@Autowired
	private JobBuilderFactory jobBuilderFactory;
	@Autowired
	private StepBuilderFactory stepBuilderFactory;
	@Autowired
	@Qualifier("jdbcTemplate")
	private JdbcTemplate jdbcTemplate;
	@Autowired
	@Qualifier("namedJdbcTemplate")
	private NamedParameterJdbcTemplate namedJdbcTemplate;
	@Autowired
	private ApplicationArguments args;
	
	@Bean("partitioner")
	@JobScope
	public Partitioner partitionerDB() throws Exception {
		CustomMultiResourcePartitioner partitioner = new CustomMultiResourcePartitioner();
		PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
		Resource[] resources = resolver.getResources("file:" + resourcesPath + fileType);
		if (resources.length > 0) {
			partitioner.setResources(resources);
			partitioner.partition(threadCorePoolSize);
		}
		return partitioner;
	}

	@Bean
	@StepScope
	public PreProcSkipListener itemSkipListener() {
		return new PreProcSkipListener();
	}
	
	@Bean
	@StepScope
	public ExcelProcessor excelProcessor() throws Exception{
		return new ExcelProcessor();
	}

	@Bean
	@StepScope
	public JdbcBatchItemWriter<LCTRReport> reportWriter() throws Exception{
		JdbcBatchItemWriter<LCTRReport> databaseItemWriter = new JdbcBatchItemWriter<>();
		databaseItemWriter.setJdbcTemplate(namedJdbcTemplate);
		databaseItemWriter.setSql(FintracUtil.QUERY_INSERT_JSON_PAYLOAD);
		ItemPreparedStatementSetter<LCTRReport> excelPreparedStatementSetter = new DataLoadSetter();
		databaseItemWriter.setItemPreparedStatementSetter(excelPreparedStatementSetter);
		return databaseItemWriter;
	}

	@Bean
	@StepScope
	@Qualifier("excelReader")
	PoiItemReader<LCTRReport> excelReader(@Value("#{stepExecutionContext['fileName']}") String fileName) throws Exception {
        PoiItemReader<LCTRReport> reader = new PoiItemReader<>();
        reader.setLinesToSkip(1);
        reader.setResource(new FileSystemResource(fileName));
        reader.setRowMapper(new ExcelRowMapper());
        return reader;
	 }
	 
	@Bean
	public Job excelJob() throws Exception {
		return jobBuilderFactory.get("excelJob").incrementer(new RunIdIncrementer()).listener(new PreProcJobListener())
				.start(masterStep()).on("COMPLETED").to(moveFiles()).from(masterStep()).on("UNKNOWN")
				.to(moveErrorFiles()).end().build();
	}

	@Bean
	public Step slaveStep() throws Exception {
		return stepBuilderFactory.get("slaveStep").<LCTRReport, LCTRReport>chunk(chunkSize).reader(excelReader(null))
				.processor(excelProcessor()).writer(reportWriter())
				//.faultTolerant().skipLimit(skipErrorCount)
				//.skip(Exception.class).listener(itemSkipListener())
				.listener(new PreProcLogStepListener()).build();
	}

	@Bean
	public ThreadPoolTaskExecutor taskExecutor() {
		ThreadPoolTaskExecutor taskExecutor = new ThreadPoolTaskExecutor();
		taskExecutor.setMaxPoolSize(threadPoolSize);
		taskExecutor.setCorePoolSize(threadCorePoolSize);
		taskExecutor.setWaitForTasksToCompleteOnShutdown(true);
		taskExecutor.afterPropertiesSet();
		return taskExecutor;
	}

	@Bean
	@Qualifier("masterStep")
	public Step masterStep() throws Exception {
		return stepBuilderFactory.get("masterStep").partitioner("slaveStep", partitionerDB()).step(slaveStep())
				.gridSize(threadQueuePoolSize).taskExecutor(taskExecutor()).listener(new PreProcStepListener()).build();
	}

	@Bean
	public Step moveFiles()throws Exception {
		MoveFilesTasklet moveFilesTasklet = new MoveFilesTasklet();
		moveFilesTasklet.setInputPath(resourcesPath);
		moveFilesTasklet.setSuccessPath(sucessPath);
		return stepBuilderFactory.get("moveFiles").tasklet(moveFilesTasklet).build();
	}

	@Bean
	public Step moveErrorFiles()throws Exception {
		MoveErrorFilesTasklet moveFilesTasklet = new MoveErrorFilesTasklet();
		moveFilesTasklet.setInputPath(resourcesPath);
		moveFilesTasklet.setErrorPath(errorPath);
		return stepBuilderFactory.get("moveErrorFiles").tasklet(moveFilesTasklet).build();
	}

	
}
