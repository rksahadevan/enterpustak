package com.lbc.lctr.fintrac.common.domain;

import java.util.Objects;

import javax.annotation.Generated;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.fasterxml.jackson.annotation.JsonValue;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * ReportReportDetails
 */

@JsonTypeName("Report_reportDetails")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-03-29T08:53:00.631912700-04:00[America/New_York]")
public class ReportDetails {

  /**
   * * 1 - Accountant / Comptable * 2 - Bank / Banque * 3 - Caisse populaire / Caisse populaire * 4 - Crown agent / Mandataire de Sa Majesté * 5 - Casino / Casino * 6 - Co-op credit society / Coopérative de crédit  * 9 - Life insurance broker or agent / Courtier ou représentant d'assurance-vie * 10 - Life insurance Company / Société d'assurance-vie * 11 - Money services business / Entreprise de services monétaires * 12 - Provincial savings office / Caisse d'épargne provinciale * 13 - Real estate / Immobilier * 14 - Credit union / Mutuelle de crédit * 15 - Securities dealer / Courtier en valeurs mobilières * 16 - Trust and/or loan / Société de fiducie et/ou de prêt * 17 - British Columbia notary / Notaire de la Colombie-Britannique * 18 - Dealer in precious metals and stones / Négociant en métaux précieux et pierres précieuses * 19 - Credit union central / Centrale de coopérative de crédit  * 20 - Financial services cooperative / Coopérative de service financiers  * 21 - Foreign money services business / Entreprise de services monétaires étrangères 
   */
  public enum ActivitySectorCodeEnum {
    NUMBER_1(1),
    
    NUMBER_2(2),
    
    NUMBER_3(3),
    
    NUMBER_4(4),
    
    NUMBER_5(5),
    
    NUMBER_6(6),
    
    NUMBER_9(9),
    
    NUMBER_10(10),
    
    NUMBER_11(11),
    
    NUMBER_12(12),
    
    NUMBER_13(13),
    
    NUMBER_14(14),
    
    NUMBER_15(15),
    
    NUMBER_16(16),
    
    NUMBER_17(17),
    
    NUMBER_18(18),
    
    NUMBER_19(19),
    
    NUMBER_20(20),
    
    NUMBER_21(21);

    private Integer value;

    ActivitySectorCodeEnum(Integer value) {
      this.value = value;
    }

    @JsonValue
    public Integer getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static ActivitySectorCodeEnum fromValue(Integer value) {
      for (ActivitySectorCodeEnum b : ActivitySectorCodeEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  @JsonProperty("activitySectorCode")
  private ActivitySectorCodeEnum activitySectorCode;

  @JsonProperty("reportingEntityNumber")
  private Integer reportingEntityNumber;

  @JsonProperty("submittingReportingEntityNumber")
  private Integer submittingReportingEntityNumber;

  @JsonProperty("reportingEntityReportReference")
  private String reportingEntityReportReference;

  @JsonProperty("twentyFourHourRule")
  private TwentyFourHourRule twentyFourHourRule;

  @JsonProperty("reportingEntityContactId")
  private Integer reportingEntityContactId;

  /**
   * * `IR2020` - IR2020 / IR2020             
   */
  public enum MinisterialDirectiveCodeEnum {
    IR2020("IR2020");

    private String value;

    MinisterialDirectiveCodeEnum(String value) {
      this.value = value;
    }

    @JsonValue
    public String getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static MinisterialDirectiveCodeEnum fromValue(String value) {
      for (MinisterialDirectiveCodeEnum b : MinisterialDirectiveCodeEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  @JsonProperty("ministerialDirectiveCode")
  private MinisterialDirectiveCodeEnum ministerialDirectiveCode;

  public ReportDetails activitySectorCode(ActivitySectorCodeEnum activitySectorCode) {
    this.activitySectorCode = activitySectorCode;
    return this;
  }

  /**
   * * 1 - Accountant / Comptable * 2 - Bank / Banque * 3 - Caisse populaire / Caisse populaire * 4 - Crown agent / Mandataire de Sa Majesté * 5 - Casino / Casino * 6 - Co-op credit society / Coopérative de crédit  * 9 - Life insurance broker or agent / Courtier ou représentant d'assurance-vie * 10 - Life insurance Company / Société d'assurance-vie * 11 - Money services business / Entreprise de services monétaires * 12 - Provincial savings office / Caisse d'épargne provinciale * 13 - Real estate / Immobilier * 14 - Credit union / Mutuelle de crédit * 15 - Securities dealer / Courtier en valeurs mobilières * 16 - Trust and/or loan / Société de fiducie et/ou de prêt * 17 - British Columbia notary / Notaire de la Colombie-Britannique * 18 - Dealer in precious metals and stones / Négociant en métaux précieux et pierres précieuses * 19 - Credit union central / Centrale de coopérative de crédit  * 20 - Financial services cooperative / Coopérative de service financiers  * 21 - Foreign money services business / Entreprise de services monétaires étrangères 
   * @return activitySectorCode
  */
  @NotNull 
  @Schema(name = "activitySectorCode", description = "* 1 - Accountant / Comptable * 2 - Bank / Banque * 3 - Caisse populaire / Caisse populaire * 4 - Crown agent / Mandataire de Sa Majesté * 5 - Casino / Casino * 6 - Co-op credit society / Coopérative de crédit  * 9 - Life insurance broker or agent / Courtier ou représentant d'assurance-vie * 10 - Life insurance Company / Société d'assurance-vie * 11 - Money services business / Entreprise de services monétaires * 12 - Provincial savings office / Caisse d'épargne provinciale * 13 - Real estate / Immobilier * 14 - Credit union / Mutuelle de crédit * 15 - Securities dealer / Courtier en valeurs mobilières * 16 - Trust and/or loan / Société de fiducie et/ou de prêt * 17 - British Columbia notary / Notaire de la Colombie-Britannique * 18 - Dealer in precious metals and stones / Négociant en métaux précieux et pierres précieuses * 19 - Credit union central / Centrale de coopérative de crédit  * 20 - Financial services cooperative / Coopérative de service financiers  * 21 - Foreign money services business / Entreprise de services monétaires étrangères ", requiredMode = Schema.RequiredMode.REQUIRED)
  public ActivitySectorCodeEnum getActivitySectorCode() {
    return activitySectorCode;
  }

  public void setActivitySectorCode(ActivitySectorCodeEnum activitySectorCode) {
    this.activitySectorCode = activitySectorCode;
  }

  public ReportDetails reportingEntityNumber(Integer reportingEntityNumber) {
    this.reportingEntityNumber = reportingEntityNumber;
    return this;
  }

  /**
   * Get reportingEntityNumber
   * @return reportingEntityNumber
  */
  @NotNull 
  @Schema(name = "reportingEntityNumber", requiredMode = Schema.RequiredMode.REQUIRED)
  public Integer getReportingEntityNumber() {
    return reportingEntityNumber;
  }

  public void setReportingEntityNumber(Integer reportingEntityNumber) {
    this.reportingEntityNumber = reportingEntityNumber;
  }

  public ReportDetails submittingReportingEntityNumber(Integer submittingReportingEntityNumber) {
    this.submittingReportingEntityNumber = submittingReportingEntityNumber;
    return this;
  }

  /**
   * Get submittingReportingEntityNumber
   * @return submittingReportingEntityNumber
  */
  
  @Schema(name = "submittingReportingEntityNumber", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public Integer getSubmittingReportingEntityNumber() {
    return submittingReportingEntityNumber;
  }

  public void setSubmittingReportingEntityNumber(Integer submittingReportingEntityNumber) {
    this.submittingReportingEntityNumber = submittingReportingEntityNumber;
  }

  public ReportDetails reportingEntityReportReference(String reportingEntityReportReference) {
    this.reportingEntityReportReference = reportingEntityReportReference;
    return this;
  }

  /**
   * Get reportingEntityReportReference
   * @return reportingEntityReportReference
  */
  @NotNull @Pattern(regexp = "^[A-Za-z0-9-_]{1,100}$") 
  @Schema(name = "reportingEntityReportReference", requiredMode = Schema.RequiredMode.REQUIRED)
  public String getReportingEntityReportReference() {
    return reportingEntityReportReference;
  }

  public void setReportingEntityReportReference(String reportingEntityReportReference) {
    this.reportingEntityReportReference = reportingEntityReportReference;
  }

  public ReportDetails twentyFourHourRule(TwentyFourHourRule twentyFourHourRule) {
    this.twentyFourHourRule = twentyFourHourRule;
    return this;
  }

  /**
   * Get twentyFourHourRule
   * @return twentyFourHourRule
  */
  @NotNull @Valid 
  @Schema(name = "twentyFourHourRule", requiredMode = Schema.RequiredMode.REQUIRED)
  public TwentyFourHourRule getTwentyFourHourRule() {
    return twentyFourHourRule;
  }

  public void setTwentyFourHourRule(TwentyFourHourRule twentyFourHourRule) {
    this.twentyFourHourRule = twentyFourHourRule;
  }

  public ReportDetails reportingEntityContactId(Integer reportingEntityContactId) {
    this.reportingEntityContactId = reportingEntityContactId;
    return this;
  }

  /**
   * Get reportingEntityContactId
   * @return reportingEntityContactId
  */
  @NotNull 
  @Schema(name = "reportingEntityContactId", requiredMode = Schema.RequiredMode.REQUIRED)
  public Integer getReportingEntityContactId() {
    return reportingEntityContactId;
  }

  public void setReportingEntityContactId(Integer reportingEntityContactId) {
    this.reportingEntityContactId = reportingEntityContactId;
  }

  public ReportDetails ministerialDirectiveCode(MinisterialDirectiveCodeEnum ministerialDirectiveCode) {
    this.ministerialDirectiveCode = ministerialDirectiveCode;
    return this;
  }

  /**
   * * `IR2020` - IR2020 / IR2020             
   * @return ministerialDirectiveCode
  */
  
  @Schema(name = "ministerialDirectiveCode", description = "* `IR2020` - IR2020 / IR2020             ", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public MinisterialDirectiveCodeEnum getMinisterialDirectiveCode() {
    return ministerialDirectiveCode;
  }

  public void setMinisterialDirectiveCode(MinisterialDirectiveCodeEnum ministerialDirectiveCode) {
    this.ministerialDirectiveCode = ministerialDirectiveCode;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ReportDetails reportReportDetails = (ReportDetails) o;
    return Objects.equals(this.activitySectorCode, reportReportDetails.activitySectorCode) &&
        Objects.equals(this.reportingEntityNumber, reportReportDetails.reportingEntityNumber) &&
        Objects.equals(this.submittingReportingEntityNumber, reportReportDetails.submittingReportingEntityNumber) &&
        Objects.equals(this.reportingEntityReportReference, reportReportDetails.reportingEntityReportReference) &&
        Objects.equals(this.twentyFourHourRule, reportReportDetails.twentyFourHourRule) &&
        Objects.equals(this.reportingEntityContactId, reportReportDetails.reportingEntityContactId) &&
        Objects.equals(this.ministerialDirectiveCode, reportReportDetails.ministerialDirectiveCode);
  }

  @Override
  public int hashCode() {
    return Objects.hash(activitySectorCode, reportingEntityNumber, submittingReportingEntityNumber, reportingEntityReportReference, twentyFourHourRule, reportingEntityContactId, ministerialDirectiveCode);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ReportReportDetails {\n");
    sb.append("    activitySectorCode: ").append(toIndentedString(activitySectorCode)).append("\n");
    sb.append("    reportingEntityNumber: ").append(toIndentedString(reportingEntityNumber)).append("\n");
    sb.append("    submittingReportingEntityNumber: ").append(toIndentedString(submittingReportingEntityNumber)).append("\n");
    sb.append("    reportingEntityReportReference: ").append(toIndentedString(reportingEntityReportReference)).append("\n");
    sb.append("    twentyFourHourRule: ").append(toIndentedString(twentyFourHourRule)).append("\n");
    sb.append("    reportingEntityContactId: ").append(toIndentedString(reportingEntityContactId)).append("\n");
    sb.append("    ministerialDirectiveCode: ").append(toIndentedString(ministerialDirectiveCode)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

