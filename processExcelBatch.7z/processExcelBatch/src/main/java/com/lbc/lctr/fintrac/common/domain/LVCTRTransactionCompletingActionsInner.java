package com.lbc.lctr.fintrac.common.domain;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.annotation.Generated;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * LVCTRTransactionCompletingActionsInner
 */

@JsonTypeName("LVCTRTransaction_completingActions_inner")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-03-29T08:53:00.631912700-04:00[America/New_York]")
public class LVCTRTransactionCompletingActionsInner {

  @JsonProperty("details")
  private LVCTRTransactionCompletingActionsInnerDetails details;

  @JsonProperty("involvements")
  @Valid
  private List<LVCTRTransactionCompletingActionsInnerInvolvementsInner> involvements = null;

  @JsonProperty("beneficiaries")
  @Valid
  private List<LVCTRTransactionCompletingActionsInnerBeneficiariesInner> beneficiaries = null;

  public LVCTRTransactionCompletingActionsInner details(LVCTRTransactionCompletingActionsInnerDetails details) {
    this.details = details;
    return this;
  }

  /**
   * Get details
   * @return details
  */
  @NotNull @Valid 
  @Schema(name = "details", requiredMode = Schema.RequiredMode.REQUIRED)
  public LVCTRTransactionCompletingActionsInnerDetails getDetails() {
    return details;
  }

  public void setDetails(LVCTRTransactionCompletingActionsInnerDetails details) {
    this.details = details;
  }

  public LVCTRTransactionCompletingActionsInner involvements(List<LVCTRTransactionCompletingActionsInnerInvolvementsInner> involvements) {
    this.involvements = involvements;
    return this;
  }

  public LVCTRTransactionCompletingActionsInner addInvolvementsItem(LVCTRTransactionCompletingActionsInnerInvolvementsInner involvementsItem) {
    if (this.involvements == null) {
      this.involvements = new ArrayList<>();
    }
    this.involvements.add(involvementsItem);
    return this;
  }

  /**
   * Get involvements
   * @return involvements
  */
  @Valid 
  @Schema(name = "involvements", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public List<LVCTRTransactionCompletingActionsInnerInvolvementsInner> getInvolvements() {
    return involvements;
  }

  public void setInvolvements(List<LVCTRTransactionCompletingActionsInnerInvolvementsInner> involvements) {
    this.involvements = involvements;
  }

  public LVCTRTransactionCompletingActionsInner beneficiaries(List<LVCTRTransactionCompletingActionsInnerBeneficiariesInner> beneficiaries) {
    this.beneficiaries = beneficiaries;
    return this;
  }

  public LVCTRTransactionCompletingActionsInner addBeneficiariesItem(LVCTRTransactionCompletingActionsInnerBeneficiariesInner beneficiariesItem) {
    if (this.beneficiaries == null) {
      this.beneficiaries = new ArrayList<>();
    }
    this.beneficiaries.add(beneficiariesItem);
    return this;
  }

  /**
   * Get beneficiaries
   * @return beneficiaries
  */
  @Valid 
  @Schema(name = "beneficiaries", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public List<LVCTRTransactionCompletingActionsInnerBeneficiariesInner> getBeneficiaries() {
    return beneficiaries;
  }

  public void setBeneficiaries(List<LVCTRTransactionCompletingActionsInnerBeneficiariesInner> beneficiaries) {
    this.beneficiaries = beneficiaries;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    LVCTRTransactionCompletingActionsInner lvCTRTransactionCompletingActionsInner = (LVCTRTransactionCompletingActionsInner) o;
    return Objects.equals(this.details, lvCTRTransactionCompletingActionsInner.details) &&
        Objects.equals(this.involvements, lvCTRTransactionCompletingActionsInner.involvements) &&
        Objects.equals(this.beneficiaries, lvCTRTransactionCompletingActionsInner.beneficiaries);
  }

  @Override
  public int hashCode() {
    return Objects.hash(details, involvements, beneficiaries);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class LVCTRTransactionCompletingActionsInner {\n");
    sb.append("    details: ").append(toIndentedString(details)).append("\n");
    sb.append("    involvements: ").append(toIndentedString(involvements)).append("\n");
    sb.append("    beneficiaries: ").append(toIndentedString(beneficiaries)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

