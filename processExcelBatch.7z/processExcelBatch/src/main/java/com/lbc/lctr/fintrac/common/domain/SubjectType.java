package com.lbc.lctr.fintrac.common.domain;

import java.io.Serializable;

public enum SubjectType implements Serializable{
	PERSON, //3
    ENTITY,  //4
    THIRD_PARTY_PERSON, //1
    THIRD_PARTY_ENTITTY  //2
}
