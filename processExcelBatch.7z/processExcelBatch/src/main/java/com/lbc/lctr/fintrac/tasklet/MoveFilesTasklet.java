package com.lbc.lctr.fintrac.tasklet;

import java.util.Collection;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class MoveFilesTasklet implements Tasklet {
	private String inputPath;
	private String successPath;
	
	/**
	* Below method is to move the success files to processed folder location. 
	*
	* @author  Santosh Kumar Balekari
	* @version 1.0
	* @since   01-Jan-2023 
	*/
	@Override
	public RepeatStatus execute(StepContribution stepContribution, ChunkContext chunkContext) throws Exception {
		Collection<StepExecution> stepExecutions = chunkContext.getStepContext().getStepExecution().getJobExecution()
				.getStepExecutions();
		for (StepExecution stepExecution : stepExecutions) {
			if (stepExecution.getExecutionContext().containsKey("fileName")
					&& ExitStatus.COMPLETED.equals(stepExecution.getExitStatus())
					&& stepExecution.getFailureExceptions().size() <= 0) {
				String filePath = (String) stepExecution.getExecutionContext().get("fileName");
				String fileName = FilenameUtils.getName(filePath);
				FileUtils.moveFile(FileUtils.getFile(inputPath + fileName),
						FileUtils.getFile(successPath + fileName));
				
			}
			
			
		}

		return RepeatStatus.FINISHED;

	}

}
