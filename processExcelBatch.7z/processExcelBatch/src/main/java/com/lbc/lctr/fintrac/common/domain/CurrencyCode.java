package com.lbc.lctr.fintrac.common.domain;

import javax.annotation.Generated;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

/**
 * * 'CAD' - Canadian Dollar / Dollar canadien * 'USD' - United States Dollar / Dollar américain * 'ATS' - Afghani / Afghani * 'AUD' - Afghani / Afghani * 'BEL' - Algerian Dinar / Dinar algérien * 'CHF' - Andorran Peseta / Peseta (Andorre) * 'CYP' - Argentine Peso / Peso argentin * 'DKK' - Argentine Peso / Peso argentin * 'ESP' - Armenian Dram / Dram arménien * 'FIM' - Aruba Florin / Florin d'Aruba * 'DEM' - Aruban Guilder / Florin d'Aruba * 'FRF' - Australian Dollar / Dollar australien * 'GBP' - Azerbaijan Manat  / Manat azerbaïdjanais * 'GRD' - Azerbaijanian Manat / Manat (Azerbaïdjan) * 'HKD' - Bahamian Dollar / Dollar des Bahamas * 'IEP' - Bahraini Dinar / Dinar de Bahreïn * 'INR' - Baht (Thailand) / Baht (Thaïlande) * 'ITL' - Balboa (Panama) / Balboa (Panama) * 'JPY' - Barbados Dollar / Dollar de la Barbade * 'KWD' - Belarusian Ruble / Rouble bélorusse * 'MTP' - Belarusian Ruble / Rouble bélorusse * 'MYR' - Belgian Franc (convertible) / Franc belge  (convertible) * 'NLG' - Belgian Franc (financial) / Franc Belge  (financier) * 'NOK' - Belgian Franc / Franc belge * 'NZD' - Belize Dollar / Dollar de Belize * 'PTE' - Bermudian Dollar / Dollar des Bermudes * 'SEK' - Bhutan Rupee / Roupie du Bhoutan * 'SGD' - Bitcoin / Bitcoin * 'THB' - Bolivar (Venezuela) / Bolivar (Venezuela) * 'TND' - Bolívar / Bolívar * 'XBD' - Bolívar Soberano / Bolívar Soberano * 'ZAR' - Bolivian Peso / Peso bolivien * 'XEU' - Boliviano / Boliviano * 'XOF' - Brazilian Real / Réal brésilien * 'YUN' - Brunei Dollar / Dollar de Brunei * 'ZAL' - Bulgarian Lev / Leva (Bulgarie) * 'ZWD' - Burundi Franc / Franc du Burundi * 'SYP' - Cape Verde Escudo / Escudo du Cap-Vert * 'SZL' - Cayman Islands Dollar / Dollar des Îles Caïmans * 'TJS' - Cedi (Ghana) / Cédi (Ghana) * 'TPE' - Cedi (Ghana) / Cédi (Ghana) * 'TRL' - CFA Franc BCEAO / Franc CFA - BCEAO * 'TZS' - CFA Franc BEAC / Franc CFA - BEAC * 'UAH' - CFP Franc (French Polynesia) / Franc CFP (Polynésie française) * 'UGS' - Chilean Peso / Peso chilien * 'TOP' - Colombian Peso / Peso colombien * 'TTD' - Comorian Franc / Franc des Comores * 'UYP' - Congolese Franc / Franc congolais * 'UZS' - Convert. Marks (Bosnia/Herzegovina) / Mark convertible (Bosnie et Herzégovine) * 'VEB' - Convertible Mark / Mark convertible * 'VND' - Cordoba / Cordoba * 'VUV' - Cordoba Oro / Cordoba d'or * 'WST' - Costa Rican Colon / Colon du Costa Rica * 'XAF' - Croatian Kuna / Kuna (Croatie) * 'XCD' - Cruzeiro / Cruzeiro * 'XAU' - Cuban Peso / Peso cubain * 'XBA' - Cyprus Pound / Livre chypriote * 'XBB' - Czech Koruna / Couronne tchèque * 'XBC' - Dalasi (Gambia) / Dalasi (Gambie) * 'XDR' - Danish Krone / Couronne danoise * 'XPF' - Denar (Macedonia) / Denar (Macédoine) * 'YDD' - Deutsche Mark / Mark allemand * 'YER' - Djibouti Franc / Franc djiboutien * 'YUD' - Dobra (Sao Tome and Principa) / Dobra (Sao Tomé et Principe) * 'ZMK' - Dobra / Dobra * 'SAR' - Dominican Peso / Peso dominicain * 'HNL' - Dong (Vietnam) / Dong (Vietnam) * 'HRK' - Drachma / Drachme * 'HTG' - East Caribbean Dollar / Dollar des Caraïbes orientales * 'HUF' - Egyptian Pound / Livre égyptienne * 'IDR' - Ekwele / Ekue * 'ILS' - El Salvador Colon / Colon du Salvador * 'IQD' - Ethiopian Birr / Birr éthiopien * 'ISK' - Euro / Euro * 'JMD' - European Composite Unit (EURCO) / Unité composite européenne (EURCO) * 'JOD' - European Currency Unit / Unité monétaire européenne (ECU) * 'KES' - European Monetary Unit (E.M.U. - 6) / Unité monétaire européenne - 6 monnaie * 'KGS' - European Unit of Account 17 / Unité européenne de compte 17 * 'KHR' - European Unit of Account 9 (E.U.A. - 9) / Unité européenne de compte 9 * 'KMF' - Falkland Islands Pound / Livre des Îles Malouines * 'KRW' - Fiji Dollar / Dollar fidjien * 'KZT' - Forint (Hungary) / Forint (Hongrie) * 'LAK' - French Franc / Franc français * 'LBP' - Gibraltar Pound / Livre de Gibraltar * 'KPW' - Gold (in ounces) / Or (en onces) * 'LKR' - Gold-Franc (Special Settlement Currency) / Franc-or (monnaie de règlement spécial) * 'LRD' - Gourde (Haiti) / Gourde (Haïti) * 'LSL' - Guarani (Paraguay) / Guarani (Paraguay) * 'LSM' - Guinea-Bissau Peso / Peso de Guinée-Bissau * 'LTL' - Guinean Franc / Franc guinéen * 'LUF' - Guyana Dollar / Dollar de Guyana * 'LVL' - Hong Kong Dollar / Dollar de Hong Kong * 'LYD' - Hryvnia (Ukraine) / Grivna (Ukraine) * 'MAD' - Iceland Krona / Couronne islandaise * 'MDL' - Indian Rupee / Roupie indienne * 'MGF' - Iranian Rial / Rial iranien * 'MLF' - Iraqi Dinar / Dinar irakien * 'MMK' - Irish Pound / Livre irlandaise * 'MNT' - Jamaican Dollar / Dollar de la Jamaïque * 'MOP' - Jordanian Dinar / Dinar jordanien * 'MRO' - Kenyan Shilling / Shilling du Kenya * 'MTL' - Kina (Papua New Guinea) / Kina (Papouaise-Nouvelle-Guinée) * 'MUR' - Koruna (Czechoslovakia) / Couronne * 'MVR' - Kroon (Estonia) / Couronne estonienne * 'MWK' - Kuwaiti Dinar / Dinar koweïtien * 'MXP' - Kwacha (Zambia) / Kwacha (Zambie) * 'MZM' - Kwacha (Zambia) / Kwacha (Zambie) * 'NAD' - Kwanza (Angola) / Kwanza (Angola) * 'NGN' - Kwanza / Kwanza * 'NIC' - Kyat (Myanmar) / Kyat (Myanmar) * 'NIO' - Kyat / Kyat * 'NPR' - Lao Kip / Laos Kip * 'OMR' - Lari (Georgia) / Lari (Georgia) * 'PAB' - Latvian Lat / Lats letton * 'PEN' - Lebanese Pound / Livre libanaise * 'PES' - Lek (Albania) / Lek (Albanie) * 'PGK' - Lempira (Honduras) / Lempira (Honduras) * 'PHP' - Leone (Sierra Leone) / Leone (Sierra Leone) * 'PKR' - Lev / Lev * 'PLZ' - Liberian Dollar / Dollar libérien * 'PYG' - Libyan Dinar / Dinar lybien * 'QAR' - Lilangeni (Swaziland) / Lilangeni (Swaziland) * 'ROL' - Lira / Lire * 'RUR' - Lithuanian Litas / Litas lituanien * 'RWF' - Loti (Lesotho) / Loti (Lesotho) * 'SBL' - Luigino / Luigino * 'SCR' - Luxembourg Franc / Franc luxembourgeois * 'SDD' - Malagasy Ariary (Madagascar) / Malagasy Ariary (Madagascar) * 'SDP' - Malagasy Franc / Franc malgache * 'SHP' - Malawi Kwacha / Malawi Kwacha * 'SIT' - Malaysian Ringgit / Ringgit malaisien * 'SKK' - Mali Franc / Franc malien * 'SLL' - Maloti / Maloti * 'SOS' - Maltese Lira / Lire maltaise * 'SRG' - Maltese Pound / Livre maltaise * 'STD' - Manat (Turkmenistan) / Manat (Turkménistan) * 'SUR' - Manat (Turkmenistan) / Manat (Turkménistan) * 'SVC' - Mark der DDR / Mark der DDR * 'GYD' - Markka / Markka * 'AED' - Mauritian Rupee / Roupie de Maurice * 'AFA' - Metical (Mosambique) / Metical (Mozambique) * 'ALL' - Metical (Mozambique) / Metical (Mozambique) * 'ANG' - Mexcian Peso / Nouveau peso mexicain * 'AOK' - Mexican Peso / Peso mexicain * 'AMD' - Mexican Unidad de Inversion / Unidad de Inversion (Mexique) * 'AON' - Moldovan Leu / Leu de Modovie * 'ARP' - Moroccan Dirham / Dirham marocain * 'AWF' - Mvdol (Bolivia) / Mvdol (Bolivie) * 'AZM' - Naira (Nigeria) / Naira (Nigeria) * 'BAK' - Nakfa (Eritrea) / Nakfa (Érythrée) * 'BBD' - Namibian Dollar / Dollar namibien * 'BDT' - Nepalese Rupee / Roupie népalaise * 'BEC' - Netherlands Antillian Guilder / Florin des Antilles néerlandaises * 'BEF' - Netherlands Guilder / Florin néerlandais * 'BGL' - New Dinar / Nouveau dinar * 'BHD' - New Israeli Shekel / Nouveau shekel israëli * 'BIF' - New Kwanza / Nouveau kwanza * 'BMD' - New Leu (Romania) / Leu (Nouveau) (Roumanie) * 'BND' - New Taiwan Dollar / Nouveau dollar taïwanais * 'BOB' - New Turkish Lira / Livre turque (nouvelle) * 'BOP' - New Zaire / Nouveau zaïre * 'BRC' - New Zealand Dollar / Dollar néo-zélandais * 'BRL' - Ngultrum (Bhutan) / Ngultrum (Bhoutan) * 'BSD' - No currency code / Pas de code de change * 'BTN' - North Korean Won / Won nord-coréen * 'BTR' - Norwegian Krone / Couronne norvégienne * 'BUK' - Old Leu (Romania) / Leu (Roumanie) * 'BWP' - Old Turkish Lira / Livre turque (l'ancienne) * 'BYR' - Omani Rial / Riyal omanais * 'BZD' - Ouguiya (Mauritania) / Ouguiya (Mauritanie) * 'CDF' - Ouguiya / Ouguiya * 'CDZ' - Pa'anga (Tonga) / Pa'anga (Tonga) * 'CLP' - Pakistan Rupee / Roupie pakistanaise * 'CNY' - Palladium (in ounces) / Palladium (en onces) * 'COP' - Pataca (Macau) / Pataca (Macau) * 'CRC' - Peso Convertible / Peso convertible * 'CSK' - Philippine Peso / Peso philippin * 'CUP' - Platinum (in ounces) / Platine (en onces) * 'CVE' - Portugese Escudo / Escudo portugais * 'CZK' - Pound Sterling (United Kingdom) / Livre sterling (Royaume-Uni) * 'DDM' - Pula (Botswana) / Pula (Botswana) * 'DJF' - Qatari Rial / Riyal qatari * 'DOP' - Quetzal (Guatemala) / Quetzal (Guatemala) * 'DZD' - Rand (financial) / Rand (financier) * 'ECS' - Rand (Lesotho, Namibia, South Africa) / Rand (Lesotho, Namibie, Afrique du Sud) * 'EEK' - Riel (Cambodia) / Riel (Cambodge) * 'EGP' - Ruble / Rouble * 'ERN' - Rufiyaa (Maldives) / Rufiyaa (Maldives) * 'ETB' - Rupiah (Indonesia) / Rupiah (Indonésie) * 'EUR' - Russian Ruble / Rouble russe * 'FJD' - Russian Ruble / Rouble russe * 'FKP' - Rwandan Franc / Franc du Rwanda * 'GEL' - Saint Helena Pound / Livre de Sainte-Hélène * 'GHC' - Saudi Riyal / Riyal saoudien * 'GIP' - Schilling (Austria) / Schilling (Autriche) * 'GMD' - Serbian Dinar / Dinar serbe * 'GNF' - Serbian Dinar / Dinar serbe * 'GNS' - Seychelles Rupee / Roupie seychelloise * 'GQE' - Silver (in ounces) / Argent (en onces) * 'GTQ' - Singapore Dollar / Dollar de Singapour * 'GWP' - Slovak Koruna / Couronne slovaque * 'ADP' - Sol / Sol * 'AOA' - Sol / Sol * 'ARS' - Solomon Islands Dollar / Dollar des Îles Salomon * 'AWG' - Som (Kyrgyzstan) / Som (Kirghizistan) * 'BAM' - Som (Uzbekistan) / Soum (Ouzbékistan) * 'BGN' - Somalian Shilling / Shilling somalien * 'BOV' - Somoni (Tajikistan) / Somoni (Tadjikistan) * 'CLF' - South Sudanese Pound / Livre sud-soudanaise * 'IRR' - Spanish Peseta / Peseta espagnole * 'KYD' - Special Drawing Rights (IMF) / Droits de tirage spéciaux (FMI) * 'MXN' - Sri Lankan Rupee / Roupie sri-lankaise * 'MXV' - Sucre / Sucre * 'PLN' - SUCRE / SUCRE * 'RUB' - Sudanese Dinar / Dinar soudanaise * 'SBD' - Sudanese Pound / Livre soudanaise * 'TJR' - Sudanese Pound / Livre soudanaise * 'TMM' - Surinam Dollar / Dollar de Surinam * 'TWD' - Suriname Guilder / Guinée de Surinam * 'USN' - Swedish Krona / Couronne suédoise * 'UYU' - Swiss Franc (Liechtenstein) / Franc suisse (Liechtenstein) * 'XAG' - Syli / Syli * 'XFO' - Syrian Pound / Livre syrienne * 'XFU' - Tajik Ruble / Rouble tadjik * 'XPD' - Taka (Bangladesh) / Taka (Bangladesh) * 'XPT' - Tala (Samoa) / Tala (Samoa) * 'XXX' - Tanzanian Shilling / Shilling tanzanien * 'YUM' - Tenge (Kazakstan) / Tengue (Kazakhstan) * 'UGX' - Timor Escudo / Escudo du Timor oriental * 'COU' - Tolar (Slovenia) / Tolar (Slovénie) * 'MKD' - Trinidad and Tobago Dollar / Dollar de Trinité-et-Tobago * 'MGA' - Tugrik (Mongolia) / Tugrik (Mongolie) * 'RON' - Tunisian Dinar / Dinar tunisien * 'CSD' - Uganda Shilling / Shilling ougandais * 'SRD' - Uganda Shilling / Shilling ougandais * 'CHW' - UIC-Franc (Special Settlement Currency) / Franc UIC (monnaie de règlement spécial) * 'CHE' - Unidad de Valor Real (Columbia) / Unidad de Valor Real (Columbie) * 'USS' - Unidad Previsional / Unidad Previsional * 'AFN' - Unidades de Formento (Chile) / Unidades chilien * 'TRY' - United Arab Emirates Dirham / Dirham des Émirats arabes unis * 'AZN' - United States Dollar, next day / Dollar américain, lendemain * 'GHS' - Uruguay Peso en Unidades Indexadas / Uruguay Peso en Unidades Indexadas * 'MZN' - Uruguayan Peso / Peso uruguayen * 'RSD' - Uruguayan Peso / Peso uruguayen * 'SDG' - US Dollar (same day) / Dollar des États-Unis (même jour) * 'VEF' - Vatu (Vanuatu) / Vatu (Vanuatu) * 'UYI' - WIR Euro (Suisse) / WIR Euro (Suisse) * 'TMT' - WIR Franc Switzerland / WIR Franc (Suisse) * 'ZMW' - Won (South Korea) / Won (Corée du Sud) * 'XBT' - Yemeni Dinar / Dinar yéménite * 'CUC' - Yemeni Rial / Riyal yéménite * 'SSP' - Yen (Japan) / Yen (Japon) * 'XSU' - Yuan Renminbi (China) / Yuan Ren-Min-Bi (Chine) * 'ZWL' - Yugoslav New Dinar / Nouveau dinar yougoslave * 'BYN' - Yugoslavian Dinar / Dinar yougoslave * 'STN' - Zimbabwe Dollar / Dollar zimbabwéen * 'MRU' - Zimbabwe Dollar / Dollar zimbabwéen * 'VES' - Zloty (Poland) / Zloty (Pologne) * 'UYW' - Zloty / Zloty * 'ZZZ' - Unknown / Inconnu 
 */

@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-03-29T08:53:00.631912700-04:00[America/New_York]")
public enum CurrencyCode {
  
  CAD("CAD"),
  
  USD("USD"),
  
  ATS("ATS"),
  
  AUD("AUD"),
  
  BEL("BEL"),
  
  CHF("CHF"),
  
  CYP("CYP"),
  
  DKK("DKK"),
  
  ESP("ESP"),
  
  FIM("FIM"),
  
  DEM("DEM"),
  
  FRF("FRF"),
  
  GBP("GBP"),
  
  GRD("GRD"),
  
  HKD("HKD"),
  
  IEP("IEP"),
  
  INR("INR"),
  
  ITL("ITL"),
  
  JPY("JPY"),
  
  KWD("KWD"),
  
  MTP("MTP"),
  
  MYR("MYR"),
  
  NLG("NLG"),
  
  NOK("NOK"),
  
  NZD("NZD"),
  
  PTE("PTE"),
  
  SEK("SEK"),
  
  SGD("SGD"),
  
  THB("THB"),
  
  TND("TND"),
  
  XBD("XBD"),
  
  ZAR("ZAR"),
  
  XEU("XEU"),
  
  XOF("XOF"),
  
  YUN("YUN"),
  
  ZAL("ZAL"),
  
  ZWD("ZWD"),
  
  SYP("SYP"),
  
  SZL("SZL"),
  
  TJS("TJS"),
  
  TPE("TPE"),
  
  TRL("TRL"),
  
  TZS("TZS"),
  
  UAH("UAH"),
  
  UGS("UGS"),
  
  TOP("TOP"),
  
  TTD("TTD"),
  
  UYP("UYP"),
  
  UZS("UZS"),
  
  VEB("VEB"),
  
  VND("VND"),
  
  VUV("VUV"),
  
  WST("WST"),
  
  XAF("XAF"),
  
  XCD("XCD"),
  
  XAU("XAU"),
  
  XBA("XBA"),
  
  XBB("XBB"),
  
  XBC("XBC"),
  
  XDR("XDR"),
  
  XPF("XPF"),
  
  YDD("YDD"),
  
  YER("YER"),
  
  YUD("YUD"),
  
  ZMK("ZMK"),
  
  SAR("SAR"),
  
  HNL("HNL"),
  
  HRK("HRK"),
  
  HTG("HTG"),
  
  HUF("HUF"),
  
  IDR("IDR"),
  
  ILS("ILS"),
  
  IQD("IQD"),
  
  ISK("ISK"),
  
  JMD("JMD"),
  
  JOD("JOD"),
  
  KES("KES"),
  
  KGS("KGS"),
  
  KHR("KHR"),
  
  KMF("KMF"),
  
  KRW("KRW"),
  
  KZT("KZT"),
  
  LAK("LAK"),
  
  LBP("LBP"),
  
  KPW("KPW"),
  
  LKR("LKR"),
  
  LRD("LRD"),
  
  LSL("LSL"),
  
  LSM("LSM"),
  
  LTL("LTL"),
  
  LUF("LUF"),
  
  LVL("LVL"),
  
  LYD("LYD"),
  
  MAD("MAD"),
  
  MDL("MDL"),
  
  MGF("MGF"),
  
  MLF("MLF"),
  
  MMK("MMK"),
  
  MNT("MNT"),
  
  MOP("MOP"),
  
  MRO("MRO"),
  
  MTL("MTL"),
  
  MUR("MUR"),
  
  MVR("MVR"),
  
  MWK("MWK"),
  
  MXP("MXP"),
  
  MZM("MZM"),
  
  NAD("NAD"),
  
  NGN("NGN"),
  
  NIC("NIC"),
  
  NIO("NIO"),
  
  NPR("NPR"),
  
  OMR("OMR"),
  
  PAB("PAB"),
  
  PEN("PEN"),
  
  PES("PES"),
  
  PGK("PGK"),
  
  PHP("PHP"),
  
  PKR("PKR"),
  
  PLZ("PLZ"),
  
  PYG("PYG"),
  
  QAR("QAR"),
  
  ROL("ROL"),
  
  RUR("RUR"),
  
  RWF("RWF"),
  
  SBL("SBL"),
  
  SCR("SCR"),
  
  SDD("SDD"),
  
  SDP("SDP"),
  
  SHP("SHP"),
  
  SIT("SIT"),
  
  SKK("SKK"),
  
  SLL("SLL"),
  
  SOS("SOS"),
  
  SRG("SRG"),
  
  STD("STD"),
  
  SUR("SUR"),
  
  SVC("SVC"),
  
  GYD("GYD"),
  
  AED("AED"),
  
  AFA("AFA"),
  
  ALL("ALL"),
  
  ANG("ANG"),
  
  AOK("AOK"),
  
  AMD("AMD"),
  
  AON("AON"),
  
  ARP("ARP"),
  
  AWF("AWF"),
  
  AZM("AZM"),
  
  BAK("BAK"),
  
  BBD("BBD"),
  
  BDT("BDT"),
  
  BEC("BEC"),
  
  BEF("BEF"),
  
  BGL("BGL"),
  
  BHD("BHD"),
  
  BIF("BIF"),
  
  BMD("BMD"),
  
  BND("BND"),
  
  BOB("BOB"),
  
  BOP("BOP"),
  
  BRC("BRC"),
  
  BRL("BRL"),
  
  BSD("BSD"),
  
  BTN("BTN"),
  
  BTR("BTR"),
  
  BUK("BUK"),
  
  BWP("BWP"),
  
  BYR("BYR"),
  
  BZD("BZD"),
  
  CDF("CDF"),
  
  CDZ("CDZ"),
  
  CLP("CLP"),
  
  CNY("CNY"),
  
  COP("COP"),
  
  CRC("CRC"),
  
  CSK("CSK"),
  
  CUP("CUP"),
  
  CVE("CVE"),
  
  CZK("CZK"),
  
  DDM("DDM"),
  
  DJF("DJF"),
  
  DOP("DOP"),
  
  DZD("DZD"),
  
  ECS("ECS"),
  
  EEK("EEK"),
  
  EGP("EGP"),
  
  ERN("ERN"),
  
  ETB("ETB"),
  
  EUR("EUR"),
  
  FJD("FJD"),
  
  FKP("FKP"),
  
  GEL("GEL"),
  
  GHC("GHC"),
  
  GIP("GIP"),
  
  GMD("GMD"),
  
  GNF("GNF"),
  
  GNS("GNS"),
  
  GQE("GQE"),
  
  GTQ("GTQ"),
  
  GWP("GWP"),
  
  ADP("ADP"),
  
  AOA("AOA"),
  
  ARS("ARS"),
  
  AWG("AWG"),
  
  BAM("BAM"),
  
  BGN("BGN"),
  
  BOV("BOV"),
  
  CLF("CLF"),
  
  IRR("IRR"),
  
  KYD("KYD"),
  
  MXN("MXN"),
  
  MXV("MXV"),
  
  PLN("PLN"),
  
  RUB("RUB"),
  
  SBD("SBD"),
  
  TJR("TJR"),
  
  TMM("TMM"),
  
  TWD("TWD"),
  
  USN("USN"),
  
  UYU("UYU"),
  
  XAG("XAG"),
  
  XFO("XFO"),
  
  XFU("XFU"),
  
  XPD("XPD"),
  
  XPT("XPT"),
  
  XXX("XXX"),
  
  YUM("YUM"),
  
  UGX("UGX"),
  
  COU("COU"),
  
  MKD("MKD"),
  
  MGA("MGA"),
  
  RON("RON"),
  
  CSD("CSD"),
  
  SRD("SRD"),
  
  CHW("CHW"),
  
  CHE("CHE"),
  
  USS("USS"),
  
  AFN("AFN"),
  
  TRY("TRY"),
  
  AZN("AZN"),
  
  GHS("GHS"),
  
  MZN("MZN"),
  
  RSD("RSD"),
  
  SDG("SDG"),
  
  VEF("VEF"),
  
  UYI("UYI"),
  
  TMT("TMT"),
  
  ZMW("ZMW"),
  
  XBT("XBT"),
  
  CUC("CUC"),
  
  SSP("SSP"),
  
  XSU("XSU"),
  
  ZWL("ZWL"),
  
  BYN("BYN"),
  
  STN("STN"),
  
  MRU("MRU"),
  
  VES("VES"),
  
  UYW("UYW"),
  
  ZZZ("ZZZ");

  private String value;

  CurrencyCode(String value) {
    this.value = value;
  }

  @JsonValue
  public String getValue() {
    return value;
  }

  @Override
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static CurrencyCode fromValue(String value) {
    for (CurrencyCode b : CurrencyCode.values()) {
      if (b.value.equals(value)) {
        return b;
      }
    }
    throw new IllegalArgumentException("Unexpected value '" + value + "'");
  }
}

