package com.lbc.lctr.fintrac.common.domain;

import java.util.Objects;

import javax.annotation.Generated;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * Report submitted / Déclaration soumise
 */

@Schema(name = "SubmitReportResponse_message", description = "Report submitted / Déclaration soumise")
@JsonTypeName("SubmitReportResponse_message")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-03-29T08:53:00.631912700-04:00[America/New_York]")
public class SubmitReportResponseMessage {

  @JsonProperty("en")
  private String en;

  @JsonProperty("fr")
  private String fr;

  public SubmitReportResponseMessage en(String en) {
    this.en = en;
    return this;
  }

  /**
   * Get en
   * @return en
  */
  
  @Schema(name = "en", example = "Report submitted successfully.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getEn() {
    return en;
  }

  public void setEn(String en) {
    this.en = en;
  }

  public SubmitReportResponseMessage fr(String fr) {
    this.fr = fr;
    return this;
  }

  /**
   * Get fr
   * @return fr
  */
  
  @Schema(name = "fr", example = "Soumission de la déclaration réussie.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getFr() {
    return fr;
  }

  public void setFr(String fr) {
    this.fr = fr;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    SubmitReportResponseMessage submitReportResponseMessage = (SubmitReportResponseMessage) o;
    return Objects.equals(this.en, submitReportResponseMessage.en) &&
        Objects.equals(this.fr, submitReportResponseMessage.fr);
  }

  @Override
  public int hashCode() {
    return Objects.hash(en, fr);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SubmitReportResponseMessage {\n");
    sb.append("    en: ").append(toIndentedString(en)).append("\n");
    sb.append("    fr: ").append(toIndentedString(fr)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

