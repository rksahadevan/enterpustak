package com.lbc.lctr.fintrac.common.domain;

import java.util.Objects;

import javax.annotation.Generated;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.fasterxml.jackson.annotation.JsonValue;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * LVCTRTransactionCompletingActionsInnerDetailsAccountHoldersInner
 */

@JsonTypeName("LVCTRTransaction_completingActions_inner_details_account_holders_inner")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-03-29T08:53:00.631912700-04:00[America/New_York]")
public class LVCTRTransactionCompletingActionsInnerDetailsAccountHoldersInner {

  /**
   * * `1` - Person name / Nom de la personne * `2` - Entity name / Nom de l'entité 
   */
  public enum TypeCodeEnum {
    NUMBER_1(1),
    
    NUMBER_2(2);

    private Integer value;

    TypeCodeEnum(Integer value) {
      this.value = value;
    }

    @JsonValue
    public Integer getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static TypeCodeEnum fromValue(Integer value) {
      for (TypeCodeEnum b : TypeCodeEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  @JsonProperty("typeCode")
  private TypeCodeEnum typeCode;

  @JsonProperty("refId")
  private String refId;

  @JsonProperty("username")
  private String username;

  public LVCTRTransactionCompletingActionsInnerDetailsAccountHoldersInner typeCode(TypeCodeEnum typeCode) {
    this.typeCode = typeCode;
    return this;
  }

  /**
   * * `1` - Person name / Nom de la personne * `2` - Entity name / Nom de l'entité 
   * @return typeCode
  */
  @NotNull 
  @Schema(name = "typeCode", description = "* `1` - Person name / Nom de la personne * `2` - Entity name / Nom de l'entité ", requiredMode = Schema.RequiredMode.REQUIRED)
  public TypeCodeEnum getTypeCode() {
    return typeCode;
  }

  public void setTypeCode(TypeCodeEnum typeCode) {
    this.typeCode = typeCode;
  }

  public LVCTRTransactionCompletingActionsInnerDetailsAccountHoldersInner refId(String refId) {
    this.refId = refId;
    return this;
  }

  /**
   * Get refId
   * @return refId
  */
  @NotNull @Size(max = 50) 
  @Schema(name = "refId", requiredMode = Schema.RequiredMode.REQUIRED)
  public String getRefId() {
    return refId;
  }

  public void setRefId(String refId) {
    this.refId = refId;
  }

  public LVCTRTransactionCompletingActionsInnerDetailsAccountHoldersInner username(String username) {
    this.username = username;
    return this;
  }

  /**
   * Get username
   * @return username
  */
  @Size(max = 100) 
  @Schema(name = "username", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getUsername() {
    return username;
  }

  public void setUsername(String username) {
    this.username = username;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    LVCTRTransactionCompletingActionsInnerDetailsAccountHoldersInner lvCTRTransactionCompletingActionsInnerDetailsAccountHoldersInner = (LVCTRTransactionCompletingActionsInnerDetailsAccountHoldersInner) o;
    return Objects.equals(this.typeCode, lvCTRTransactionCompletingActionsInnerDetailsAccountHoldersInner.typeCode) &&
        Objects.equals(this.refId, lvCTRTransactionCompletingActionsInnerDetailsAccountHoldersInner.refId) &&
        Objects.equals(this.username, lvCTRTransactionCompletingActionsInnerDetailsAccountHoldersInner.username);
  }

  @Override
  public int hashCode() {
    return Objects.hash(typeCode, refId, username);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class LVCTRTransactionCompletingActionsInnerDetailsAccountHoldersInner {\n");
    sb.append("    typeCode: ").append(toIndentedString(typeCode)).append("\n");
    sb.append("    refId: ").append(toIndentedString(refId)).append("\n");
    sb.append("    username: ").append(toIndentedString(username)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

