package com.lbc.lctr.fintrac.listener;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;

public class PreProcStepListener implements StepExecutionListener {
	
	private static final Logger log = LoggerFactory.getLogger(PreProcStepListener.class);
	
	@Override
	public void beforeStep(StepExecution stepExecution) {
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		List<Throwable> failureExceptions = stepExecution.getFailureExceptions();

		ExitStatus es = stepExecution.getExitStatus();

		if (!failureExceptions.isEmpty() && failureExceptions.size() > 0) {

			return ExitStatus.UNKNOWN;
		}
		if (stepExecution.getReadCount() == 0) {
			log.info("No Files to read !!");

			return ExitStatus.COMPLETED;
		}

		if (es.getExitCode().equalsIgnoreCase("FAILED")) {
			return ExitStatus.UNKNOWN;
		}

		if (stepExecution.getRollbackCount() > 0) {
			return ExitStatus.UNKNOWN;
		}
		if (stepExecution.getReadSkipCount() > 0) {
			return ExitStatus.UNKNOWN;
		}

		return stepExecution.getExitStatus();
	}

}