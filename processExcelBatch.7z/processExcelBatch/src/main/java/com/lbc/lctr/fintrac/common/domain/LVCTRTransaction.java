package com.lbc.lctr.fintrac.common.domain;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.annotation.Generated;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * LVCTRTransaction
 */

@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-03-29T08:53:00.631912700-04:00[America/New_York]")
@JsonTypeInfo(use=JsonTypeInfo.Id.CLASS, include=JsonTypeInfo.As.PROPERTY, property="@class")

public class LVCTRTransaction implements ReportTransaction {

  @JsonProperty("transactionUuid")
  private String transactionUuid;

  @JsonProperty("externalReportUuid")
  private String externalReportUuid;

  @JsonProperty("reportingEntityLocationId")
  private String reportingEntityLocationId;

  @JsonProperty("virtualCurrencyTransactionDetails")
  private LVCTRTransactionVirtualCurrencyTransactionDetails virtualCurrencyTransactionDetails;

  @JsonProperty("startingActions")
  @Valid
  private List<LVCTRTransactionStartingActionsInner> startingActions = new ArrayList<>();

  @JsonProperty("completingActions")
  @Valid
  private List<LVCTRTransactionCompletingActionsInner> completingActions = new ArrayList<>();

  public LVCTRTransaction transactionUuid(String transactionUuid) {
    this.transactionUuid = transactionUuid;
    return this;
  }

  /**
   * Get transactionUuid
   * @return transactionUuid
  */
  @Size(max = 100) 
  @Schema(name = "transactionUuid", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getTransactionUuid() {
    return transactionUuid;
  }

  public void setTransactionUuid(String transactionUuid) {
    this.transactionUuid = transactionUuid;
  }

  public LVCTRTransaction externalReportUuid(String externalReportUuid) {
    this.externalReportUuid = externalReportUuid;
    return this;
  }

  /**
   * Get externalReportUuid
   * @return externalReportUuid
  */
  @NotNull @Size(max = 100) 
  @Schema(name = "externalReportUuid", requiredMode = Schema.RequiredMode.REQUIRED)
  public String getExternalReportUuid() {
    return externalReportUuid;
  }

  public void setExternalReportUuid(String externalReportUuid) {
    this.externalReportUuid = externalReportUuid;
  }

  public LVCTRTransaction reportingEntityLocationId(String reportingEntityLocationId) {
    this.reportingEntityLocationId = reportingEntityLocationId;
    return this;
  }

  /**
   * Get reportingEntityLocationId
   * @return reportingEntityLocationId
  */
  @NotNull @Size(max = 30) 
  @Schema(name = "reportingEntityLocationId", requiredMode = Schema.RequiredMode.REQUIRED)
  public String getReportingEntityLocationId() {
    return reportingEntityLocationId;
  }

  public void setReportingEntityLocationId(String reportingEntityLocationId) {
    this.reportingEntityLocationId = reportingEntityLocationId;
  }

  public LVCTRTransaction virtualCurrencyTransactionDetails(LVCTRTransactionVirtualCurrencyTransactionDetails virtualCurrencyTransactionDetails) {
    this.virtualCurrencyTransactionDetails = virtualCurrencyTransactionDetails;
    return this;
  }

  /**
   * Get virtualCurrencyTransactionDetails
   * @return virtualCurrencyTransactionDetails
  */
  @NotNull @Valid 
  @Schema(name = "virtualCurrencyTransactionDetails", requiredMode = Schema.RequiredMode.REQUIRED)
  public LVCTRTransactionVirtualCurrencyTransactionDetails getVirtualCurrencyTransactionDetails() {
    return virtualCurrencyTransactionDetails;
  }

  public void setVirtualCurrencyTransactionDetails(LVCTRTransactionVirtualCurrencyTransactionDetails virtualCurrencyTransactionDetails) {
    this.virtualCurrencyTransactionDetails = virtualCurrencyTransactionDetails;
  }

  public LVCTRTransaction startingActions(List<LVCTRTransactionStartingActionsInner> startingActions) {
    this.startingActions = startingActions;
    return this;
  }

  public LVCTRTransaction addStartingActionsItem(LVCTRTransactionStartingActionsInner startingActionsItem) {
    this.startingActions.add(startingActionsItem);
    return this;
  }

  /**
   * Get startingActions
   * @return startingActions
  */
  @NotNull @Valid @Size(min = 1, max = 50) 
  @Schema(name = "startingActions", requiredMode = Schema.RequiredMode.REQUIRED)
  public List<LVCTRTransactionStartingActionsInner> getStartingActions() {
    return startingActions;
  }

  public void setStartingActions(List<LVCTRTransactionStartingActionsInner> startingActions) {
    this.startingActions = startingActions;
  }

  public LVCTRTransaction completingActions(List<LVCTRTransactionCompletingActionsInner> completingActions) {
    this.completingActions = completingActions;
    return this;
  }

  public LVCTRTransaction addCompletingActionsItem(LVCTRTransactionCompletingActionsInner completingActionsItem) {
    this.completingActions.add(completingActionsItem);
    return this;
  }

  /**
   * Get completingActions
   * @return completingActions
  */
  @NotNull @Valid 
  @Schema(name = "completingActions", requiredMode = Schema.RequiredMode.REQUIRED)
  public List<LVCTRTransactionCompletingActionsInner> getCompletingActions() {
    return completingActions;
  }

  public void setCompletingActions(List<LVCTRTransactionCompletingActionsInner> completingActions) {
    this.completingActions = completingActions;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    LVCTRTransaction lvCTRTransaction = (LVCTRTransaction) o;
    return Objects.equals(this.transactionUuid, lvCTRTransaction.transactionUuid) &&
        Objects.equals(this.externalReportUuid, lvCTRTransaction.externalReportUuid) &&
        Objects.equals(this.reportingEntityLocationId, lvCTRTransaction.reportingEntityLocationId) &&
        Objects.equals(this.virtualCurrencyTransactionDetails, lvCTRTransaction.virtualCurrencyTransactionDetails) &&
        Objects.equals(this.startingActions, lvCTRTransaction.startingActions) &&
        Objects.equals(this.completingActions, lvCTRTransaction.completingActions);
  }

  @Override
  public int hashCode() {
    return Objects.hash(transactionUuid, externalReportUuid, reportingEntityLocationId, virtualCurrencyTransactionDetails, startingActions, completingActions);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class LVCTRTransaction {\n");
    sb.append("    transactionUuid: ").append(toIndentedString(transactionUuid)).append("\n");
    sb.append("    externalReportUuid: ").append(toIndentedString(externalReportUuid)).append("\n");
    sb.append("    reportingEntityLocationId: ").append(toIndentedString(reportingEntityLocationId)).append("\n");
    sb.append("    virtualCurrencyTransactionDetails: ").append(toIndentedString(virtualCurrencyTransactionDetails)).append("\n");
    sb.append("    startingActions: ").append(toIndentedString(startingActions)).append("\n");
    sb.append("    completingActions: ").append(toIndentedString(completingActions)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

