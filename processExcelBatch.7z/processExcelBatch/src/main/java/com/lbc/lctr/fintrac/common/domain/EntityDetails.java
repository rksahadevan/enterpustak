package com.lbc.lctr.fintrac.common.domain;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.annotation.Generated;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonValue;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * EntityDetails
 */

@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-03-29T08:53:00.631912700-04:00[America/New_York]")
@JsonTypeInfo(use=JsonTypeInfo.Id.CLASS, include=JsonTypeInfo.As.PROPERTY, property="@class")

public class EntityDetails implements SubjectDefination {
	

  @JsonProperty("refId")
  private String refId;

  @JsonProperty("nameOfEntity")
  private String nameOfEntity;

  @JsonProperty("telephoneNumber")
  private String telephoneNumber;

  @JsonProperty("extensionNumber")
  private String extensionNumber;

  @JsonProperty("natureOfPrincipalBusiness")
  private String natureOfPrincipalBusiness;
  
  @JsonProperty("subjectType")

  private SubjectType subjectType = SubjectType.ENTITY;

  
  public SubjectType getSubjectType() {
	return subjectType;
}

  public void setSubjectType(SubjectType subjectType) {
	this.subjectType = subjectType;
  }

/**
   * * `1` - Structured address / Adresse structurée * `2` - Unstructured address / Adresse non structurée 
   */
  public enum AddressTypeCodeEnum {
    NUMBER_1(1),
    
    NUMBER_2(2);

    private Integer value;

    AddressTypeCodeEnum(Integer value) {
      this.value = value;
    }

    @JsonValue
    public Integer getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static AddressTypeCodeEnum fromValue(Integer value) {
      for (AddressTypeCodeEnum b : AddressTypeCodeEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  @JsonProperty("addressTypeCode")
  private AddressTypeCodeEnum addressTypeCode;

  @JsonProperty("address")
  private PersonDetailsAddress address;

  @JsonProperty("identifications")
  @Valid
  private List<EntityDetailsIdentification> identifications = null;

  @JsonProperty("authorizedPersons")
  @Valid
  private List<EntityDetailsAuthorizedPerson> authorizedPersons = null;

  @JsonProperty("registrationIncorporationIndicator")
  private Boolean registrationIncorporationIndicator;

  @JsonProperty("registrationsIncorporations")
  @Valid
  private List<EntityDetailsRegistrationsIncorporation> registrationsIncorporations = null;


 
  public EntityDetails refId(String refId) {
    this.refId = refId;
    return this;
  }

  /**
   * Get refId
   * @return refId
  */
  @NotNull @Size(max = 50) 
  @Schema(name = "refId", requiredMode = Schema.RequiredMode.REQUIRED)
  public String getRefId() {
    return refId;
  }

  public void setRefId(String refId) {
    this.refId = refId;
  }

  public EntityDetails nameOfEntity(String nameOfEntity) {
    this.nameOfEntity = nameOfEntity;
    return this;
  }

  /**
   * Get nameOfEntity
   * @return nameOfEntity
  */
  @Size(max = 100) 
  @Schema(name = "nameOfEntity", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getNameOfEntity() {
    return nameOfEntity;
  }

  public void setNameOfEntity(String nameOfEntity) {
    this.nameOfEntity = nameOfEntity;
  }

  public EntityDetails telephoneNumber(String telephoneNumber) {
    this.telephoneNumber = telephoneNumber;
    return this;
  }

  /**
   * Get telephoneNumber
   * @return telephoneNumber
  */
  @Size(max = 20) 
  @Schema(name = "telephoneNumber", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getTelephoneNumber() {
    return telephoneNumber;
  }

  public void setTelephoneNumber(String telephoneNumber) {
    this.telephoneNumber = telephoneNumber;
  }

  public EntityDetails extensionNumber(String extensionNumber) {
    this.extensionNumber = extensionNumber;
    return this;
  }

  /**
   * Get extensionNumber
   * @return extensionNumber
  */
  @Size(max = 10) 
  @Schema(name = "extensionNumber", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getExtensionNumber() {
    return extensionNumber;
  }

  public void setExtensionNumber(String extensionNumber) {
    this.extensionNumber = extensionNumber;
  }

  public EntityDetails natureOfPrincipalBusiness(String natureOfPrincipalBusiness) {
    this.natureOfPrincipalBusiness = natureOfPrincipalBusiness;
    return this;
  }

  /**
   * Get natureOfPrincipalBusiness
   * @return natureOfPrincipalBusiness
  */
  @Size(max = 20) 
  @Schema(name = "natureOfPrincipalBusiness", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getNatureOfPrincipalBusiness() {
    return natureOfPrincipalBusiness;
  }

  public void setNatureOfPrincipalBusiness(String natureOfPrincipalBusiness) {
    this.natureOfPrincipalBusiness = natureOfPrincipalBusiness;
  }

  public EntityDetails addressTypeCode(AddressTypeCodeEnum addressTypeCode) {
    this.addressTypeCode = addressTypeCode;
    return this;
  }

  /**
   * * `1` - Structured address / Adresse structurée * `2` - Unstructured address / Adresse non structurée 
   * @return addressTypeCode
  */
  
  @Schema(name = "addressTypeCode", description = "* `1` - Structured address / Adresse structurée * `2` - Unstructured address / Adresse non structurée ", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public AddressTypeCodeEnum getAddressTypeCode() {
    return addressTypeCode;
  }

  public void setAddressTypeCode(AddressTypeCodeEnum addressTypeCode) {
    this.addressTypeCode = addressTypeCode;
  }

  public EntityDetails address(PersonDetailsAddress address) {
    this.address = address;
    return this;
  }

  /**
   * Get address
   * @return address
  */
  @Valid 
  @Schema(name = "address", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public PersonDetailsAddress getAddress() {
    return address;
  }

  public void setAddress(PersonDetailsAddress address) {
    this.address = address;
  }

  public EntityDetails identifications(List<EntityDetailsIdentification> identifications) {
    this.identifications = identifications;
    return this;
  }

  public EntityDetails addIdentificationsItem(EntityDetailsIdentification identificationsItem) {
    if (this.identifications == null) {
      this.identifications = new ArrayList<>();
    }
    this.identifications.add(identificationsItem);
    return this;
  }

  /**
   * Get identifications
   * @return identifications
  */
  @Valid 
  @Schema(name = "identifications", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public List<EntityDetailsIdentification> getIdentifications() {
    return identifications;
  }

  public void setIdentifications(List<EntityDetailsIdentification> identifications) {
    this.identifications = identifications;
  }

  public EntityDetails authorizedPersons(List<EntityDetailsAuthorizedPerson> authorizedPersons) {
    this.authorizedPersons = authorizedPersons;
    return this;
  }

  public EntityDetails addAuthorizedPersonsItem(EntityDetailsAuthorizedPerson authorizedPersonsItem) {
    if (this.authorizedPersons == null) {
      this.authorizedPersons = new ArrayList<>();
    }
    this.authorizedPersons.add(authorizedPersonsItem);
    return this;
  }

  /**
   * Get authorizedPersons
   * @return authorizedPersons
  */
  @Valid 
  @Schema(name = "authorizedPersons", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public List<EntityDetailsAuthorizedPerson> getAuthorizedPersons() {
    return authorizedPersons;
  }

  public void setAuthorizedPersons(List<EntityDetailsAuthorizedPerson> authorizedPersons) {
    this.authorizedPersons = authorizedPersons;
  }

  public EntityDetails registrationIncorporationIndicator(Boolean registrationIncorporationIndicator) {
    this.registrationIncorporationIndicator = registrationIncorporationIndicator;
    return this;
  }

  /**
   * Get registrationIncorporationIndicator
   * @return registrationIncorporationIndicator
  */
  
  @Schema(name = "registrationIncorporationIndicator", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public Boolean getRegistrationIncorporationIndicator() {
    return registrationIncorporationIndicator;
  }

  public void setRegistrationIncorporationIndicator(Boolean registrationIncorporationIndicator) {
    this.registrationIncorporationIndicator = registrationIncorporationIndicator;
  }

  public EntityDetails registrationsIncorporations(List<EntityDetailsRegistrationsIncorporation> registrationsIncorporations) {
    this.registrationsIncorporations = registrationsIncorporations;
    return this;
  }

  public EntityDetails addRegistrationsIncorporationsItem(EntityDetailsRegistrationsIncorporation registrationsIncorporationsItem) {
    if (this.registrationsIncorporations == null) {
      this.registrationsIncorporations = new ArrayList<>();
    }
    this.registrationsIncorporations.add(registrationsIncorporationsItem);
    return this;
  }

  /**
   * Get registrationsIncorporations
   * @return registrationsIncorporations
  */
  @Valid 
  @Schema(name = "registrationsIncorporations", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public List<EntityDetailsRegistrationsIncorporation> getRegistrationsIncorporations() {
    return registrationsIncorporations;
  }

  public void setRegistrationsIncorporations(List<EntityDetailsRegistrationsIncorporation> registrationsIncorporations) {
    this.registrationsIncorporations = registrationsIncorporations;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    EntityDetails entityDetails = (EntityDetails) o;
    return Objects.equals(this.subjectType, entityDetails.subjectType) &&
        Objects.equals(this.refId, entityDetails.refId) &&
        Objects.equals(this.nameOfEntity, entityDetails.nameOfEntity) &&
        Objects.equals(this.telephoneNumber, entityDetails.telephoneNumber) &&
        Objects.equals(this.extensionNumber, entityDetails.extensionNumber) &&
        Objects.equals(this.natureOfPrincipalBusiness, entityDetails.natureOfPrincipalBusiness) &&
        Objects.equals(this.addressTypeCode, entityDetails.addressTypeCode) &&
        Objects.equals(this.address, entityDetails.address) &&
        Objects.equals(this.identifications, entityDetails.identifications) &&
        Objects.equals(this.authorizedPersons, entityDetails.authorizedPersons) &&
        Objects.equals(this.registrationIncorporationIndicator, entityDetails.registrationIncorporationIndicator) &&
        Objects.equals(this.registrationsIncorporations, entityDetails.registrationsIncorporations);
  }

  @Override
  public int hashCode() {
    return Objects.hash(subjectType, refId, nameOfEntity, telephoneNumber, extensionNumber, natureOfPrincipalBusiness, addressTypeCode, address, identifications, authorizedPersons, registrationIncorporationIndicator, registrationsIncorporations);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class EntityDetails {\n");
    sb.append("    typeCode: ").append(toIndentedString(subjectType)).append("\n");
    sb.append("    refId: ").append(toIndentedString(refId)).append("\n");
    sb.append("    nameOfEntity: ").append(toIndentedString(nameOfEntity)).append("\n");
    sb.append("    telephoneNumber: ").append(toIndentedString(telephoneNumber)).append("\n");
    sb.append("    extensionNumber: ").append(toIndentedString(extensionNumber)).append("\n");
    sb.append("    natureOfPrincipalBusiness: ").append(toIndentedString(natureOfPrincipalBusiness)).append("\n");
    sb.append("    addressTypeCode: ").append(toIndentedString(addressTypeCode)).append("\n");
    sb.append("    address: ").append(toIndentedString(address)).append("\n");
    sb.append("    identifications: ").append(toIndentedString(identifications)).append("\n");
    sb.append("    authorizedPersons: ").append(toIndentedString(authorizedPersons)).append("\n");
    sb.append("    registrationIncorporationIndicator: ").append(toIndentedString(registrationIncorporationIndicator)).append("\n");
    sb.append("    registrationsIncorporations: ").append(toIndentedString(registrationsIncorporations)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

