package com.lbc.lctr.fintrac.tasklet;

import java.util.Collection;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class MoveErrorFilesTasklet implements Tasklet {
	private String inputPath;
	private String errorPath;

	
	/**
	* Below method is to move the failure files to Error folder location. 
	*
	* @author  Santosh Kumar Balekari
	* @version 1.0
	* @since   01-Jan-2023 
	*/
	
	
	@Override
	public RepeatStatus execute(StepContribution stepContribution, ChunkContext chunkContext) throws Exception {
		Collection<StepExecution> stepExecutions = chunkContext.getStepContext().getStepExecution().getJobExecution()
				.getStepExecutions();
		
		for (StepExecution stepExecution : stepExecutions) {
			if (stepExecution.getExecutionContext().containsKey("fileName")) {
				String filePath = (String) stepExecution.getExecutionContext().get("fileName");
				String fileName = FilenameUtils.getName(filePath);
				if (stepExecution.getRollbackCount() > 0
						|| stepExecution.getExitStatus().getExitCode().equalsIgnoreCase("FAILED")) {
					FileUtils.moveFile(FileUtils.getFile(inputPath + fileName), FileUtils.getFile(errorPath + fileName));
				}
		}
		}
		return RepeatStatus.FINISHED;

	}

}
