package com.lbc.lctr.fintrac.common.domain;

import javax.annotation.Generated;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;


@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-03-29T08:53:00.631912700-04:00[America/New_York]")
public enum ProvinceStateCode {
	  AB("AB"),
	  
	  BC("BC"),
	  
	  MB("MB"),
	  
	  NB("NB"),
	  
	  NL("NL"),
	  
	  NT("NT"),
	  
	  NS("NS"),
	  
	  NU("NU"),
	  
	  ON("ON"),
	  
	  PE("PE"),
	  
	  QC("QC"),
	  
	  SK("SK"),
	  
	  YT("YT");

	  private String value;

	  ProvinceStateCode(String value) {
	    this.value = value;
	  }

	  @JsonValue
	  public String getValue() {
	    return value;
	  }

	  @Override
	  public String toString() {
	    return String.valueOf(value);
	  }

	  @JsonCreator
	  public static ProvinceStateCode fromValue(String value) {
	    for (ProvinceStateCode b : ProvinceStateCode.values()) {
	      if (b.value.equals(value)) {
	        return b;
	      }
	    }
	    throw new IllegalArgumentException("Unexpected value '" + value + "'");
	  }
}
