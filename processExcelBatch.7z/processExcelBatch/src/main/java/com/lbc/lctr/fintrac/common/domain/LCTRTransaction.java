package com.lbc.lctr.fintrac.common.domain;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.annotation.Generated;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * LCTRTransaction
 */

@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-03-29T08:53:00.631912700-04:00[America/New_York]")
@JsonTypeInfo(use=JsonTypeInfo.Id.CLASS, include=JsonTypeInfo.As.PROPERTY, property="@class")

public class LCTRTransaction implements ReportTransaction {

  @JsonProperty("transactionUuid")
  private String transactionUuid;

  @JsonProperty("externalReportUuid")
  private String externalReportUuid;

  @JsonProperty("reportingEntityLocationId")
  private String reportingEntityLocationId;

  @JsonProperty("largeCashTransactionDetails")
  private LCTRTransactionDetails largeCashTransactionDetails;

  @JsonProperty("startingActions")
  @Valid
  private List<LCTRStartingAction> startingActions = new ArrayList<>();

  @JsonProperty("completingActions")
  @Valid
  private List<LCTRCompletingAction> completingActions = new ArrayList<>();

  public LCTRTransaction transactionUuid(String transactionUuid) {
    this.transactionUuid = transactionUuid;
    return this;
  }

  /**
   * Get transactionUuid
   * @return transactionUuid
  */
  @Size(max = 100) 
  @Schema(name = "transactionUuid", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getTransactionUuid() {
    return transactionUuid;
  }

  public void setTransactionUuid(String transactionUuid) {
    this.transactionUuid = transactionUuid;
  }

  public LCTRTransaction externalReportUuid(String externalReportUuid) {
    this.externalReportUuid = externalReportUuid;
    return this;
  }

  /**
   * Get externalReportUuid
   * @return externalReportUuid
  */
  @NotNull @Size(max = 100) 
  @Schema(name = "externalReportUuid", requiredMode = Schema.RequiredMode.REQUIRED)
  public String getExternalReportUuid() {
    return externalReportUuid;
  }

  public void setExternalReportUuid(String externalReportUuid) {
    this.externalReportUuid = externalReportUuid;
  }

  public LCTRTransaction reportingEntityLocationId(String reportingEntityLocationId) {
    this.reportingEntityLocationId = reportingEntityLocationId;
    return this;
  }

  /**
   * Get reportingEntityLocationId
   * @return reportingEntityLocationId
  */
  @NotNull @Size(max = 30) 
  @Schema(name = "reportingEntityLocationId", requiredMode = Schema.RequiredMode.REQUIRED)
  public String getReportingEntityLocationId() {
    return reportingEntityLocationId;
  }

  public void setReportingEntityLocationId(String reportingEntityLocationId) {
    this.reportingEntityLocationId = reportingEntityLocationId;
  }

  public LCTRTransaction largeCashTransactionDetails(LCTRTransactionDetails largeCashTransactionDetails) {
    this.largeCashTransactionDetails = largeCashTransactionDetails;
    return this;
  }

  /**
   * Get largeCashTransactionDetails
   * @return largeCashTransactionDetails
  */
  @NotNull @Valid 
  @Schema(name = "largeCashTransactionDetails", requiredMode = Schema.RequiredMode.REQUIRED)
  public LCTRTransactionDetails getLargeCashTransactionDetails() {
    return largeCashTransactionDetails;
  }

  public void setLargeCashTransactionDetails(LCTRTransactionDetails largeCashTransactionDetails) {
    this.largeCashTransactionDetails = largeCashTransactionDetails;
  }

  public LCTRTransaction startingActions(List<LCTRStartingAction> startingActions) {
    this.startingActions = startingActions;
    return this;
  }

  public LCTRTransaction addStartingActionsItem(LCTRStartingAction startingActionsItem) {
    this.startingActions.add(startingActionsItem);
    return this;
  }

  /**
   * Get startingActions
   * @return startingActions
  */
  @NotNull @Valid @Size(min = 1, max = 50) 
  @Schema(name = "startingActions", requiredMode = Schema.RequiredMode.REQUIRED)
  public List<LCTRStartingAction> getStartingActions() {
    return startingActions;
  }

  public void setStartingActions(List<LCTRStartingAction> startingActions) {
    this.startingActions = startingActions;
  }

  public LCTRTransaction completingActions(List<LCTRCompletingAction> completingActions) {
    this.completingActions = completingActions;
    return this;
  }

  public LCTRTransaction addCompletingActionsItem(LCTRCompletingAction completingActionsItem) {
    this.completingActions.add(completingActionsItem);
    return this;
  }

  /**
   * Get completingActions
   * @return completingActions
  */
  @NotNull @Valid 
  @Schema(name = "completingActions", requiredMode = Schema.RequiredMode.REQUIRED)
  public List<LCTRCompletingAction> getCompletingActions() {
    return completingActions;
  }

  public void setCompletingActions(List<LCTRCompletingAction> completingActions) {
    this.completingActions = completingActions;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    LCTRTransaction lcTRTransaction = (LCTRTransaction) o;
    return Objects.equals(this.transactionUuid, lcTRTransaction.transactionUuid) &&
        Objects.equals(this.externalReportUuid, lcTRTransaction.externalReportUuid) &&
        Objects.equals(this.reportingEntityLocationId, lcTRTransaction.reportingEntityLocationId) &&
        Objects.equals(this.largeCashTransactionDetails, lcTRTransaction.largeCashTransactionDetails) &&
        Objects.equals(this.startingActions, lcTRTransaction.startingActions) &&
        Objects.equals(this.completingActions, lcTRTransaction.completingActions);
  }

  @Override
  public int hashCode() {
    return Objects.hash(transactionUuid, externalReportUuid, reportingEntityLocationId, largeCashTransactionDetails, startingActions, completingActions);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class LCTRTransaction {\n");
    sb.append("    transactionUuid: ").append(toIndentedString(transactionUuid)).append("\n");
    sb.append("    externalReportUuid: ").append(toIndentedString(externalReportUuid)).append("\n");
    sb.append("    reportingEntityLocationId: ").append(toIndentedString(reportingEntityLocationId)).append("\n");
    sb.append("    largeCashTransactionDetails: ").append(toIndentedString(largeCashTransactionDetails)).append("\n");
    sb.append("    startingActions: ").append(toIndentedString(startingActions)).append("\n");
    sb.append("    completingActions: ").append(toIndentedString(completingActions)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

