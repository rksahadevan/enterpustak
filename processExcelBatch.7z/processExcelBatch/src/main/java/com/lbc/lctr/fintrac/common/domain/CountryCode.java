package com.lbc.lctr.fintrac.common.domain;

import javax.annotation.Generated;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

/**
 * * 'CA' - Canada / Canada * 'US' - United States / États-Unis d'Amérique * 'AF' - Afghanistan / Afghanistan * 'AX' - Åland Islands / Îles d'Åland * 'AL' - Albania / Albanie * 'DZ' - Algeria / Algérie * 'AS' - American Samoa / Samoa américaine * 'AD' - Andorra / Andorre * 'AO' - Angola / Angola * 'AI' - Anguilla / Anguilla * 'AQ' - Antarctica / Antarctique * 'AG' - Antigua and Barbuda / Antigua-et-Barbuda * 'AR' - Argentina / Argentine * 'AM' - Armenia / Arménie * 'AW' - Aruba / Aruba * 'AU' - Australia / Australie * 'AT' - Austria / Autriche * 'AZ' - Azerbaijan / Azerbaïdjan * 'BS' - Bahamas / Bahamas * 'BH' - Bahrain / Bahreïn * 'BD' - Bangladesh / Bangladesh * 'BB' - Barbados / Barbade * 'BY' - Belarus / Bélarus * 'BE' - Belgium / Belgique * 'BZ' - Belize / Belize * 'BJ' - Benin / Bénin * 'BM' - Bermuda / Bermudes * 'BT' - Bhutan / Bhoutan * 'BO' - Bolivia (Plurinational State of) / Bolivie (État plurinational de) * 'BQ' - Bonaire (Sint Eustatius and Saba) / Bonaire (Saint-Eustache et Saba) * 'BA' - Bosnia and Herzegovina / Bosnie-Herzégovine * 'BW' - Botswana / Botswana * 'BV' - Bouvet Island / Île Bouvet * 'BR' - Brazil / Brésil * 'IO' - British Indian Ocean Territory / Territoire britan. de l'océan indien * 'BN' - Brunei Darussalam / Brunéi Darussalam * 'BG' - Bulgaria / Bulgarie * 'BF' - Burkina Faso / Burkina Faso * 'BI' - Burundi / Burundi * 'CV' - Cabo Verde / Cap-Vert * 'KH' - Cambodia / Cambodge * 'CM' - Cameroon / Cameroun * 'KY' - Cayman Islands / Îles Caïmans * 'CF' - Central African Republic / République centrafricaine * 'TD' - Chad / Tchad * 'CL' - Chile / Chili * 'CN' - China / Chine * 'CX' - Christmas Island / Île Christmas * 'CC' - Cocos (Keeling) Islands / Îles Cocos  (Keeling) * 'CO' - Colombia / Colombie * 'KM' - Comoros (the) / Comores (les) * 'CD' - Congo (the Democratic Republic of the) / Congo (la République démocratique du) * 'CG' - Congo (the) / Congo (le) * 'CK' - Cook Islands / Îles Cook * 'CR' - Costa Rica / Costa Rica * 'CI' - Cote d'Ivoire / Côte d'Ivoire * 'HR' - Croatia (Hrvatska) / Croatie (Hrvatska) * 'CU' - Cuba / Cuba * 'CW' - Curaçao / Curaçao * 'CY' - Cyprus / Chypre * 'CZ' - Czech Republic / République tchèque * 'DK' - Denmark / Danemark * 'DJ' - Djibouti / Djibouti * 'DM' - Dominica / Dominique * 'DO' - Dominican Republic / République dominicaine * 'EC' - Ecuador / Équateur * 'EG' - Egypt / Égypte * 'SV' - El Salvador / El Salvador * 'GQ' - Equatorial Guinea / Guinée équatoriale * 'ER' - Eritrea / Érythrée * 'EE' - Estonia / Estonie * 'SZ' - Eswatini / Eswatini * 'ET' - Ethiopia / Éthiopie * 'FK' - Falkland Islands (Malvinas) / Îles Malouines (Falkland; Malvinas) * 'FO' - Faroe Islands / Îles Féroé * 'FJ' - Fiji / Fidji * 'FI' - Finland / Finlande * 'FR' - France / France * 'FX' - France, Metropolitan / France, Région métropolitaine * 'GF' - French Guiana / Guyane française * 'PF' - French Polynesia / Polynésie française * 'TF' - French Southern Territories / Territoires méridionaux français * 'GA' - Gabon / Gabon * 'GM' - Gambia / Gambie * 'GE' - Georgia / Géorgie * 'DE' - Germany / Allemagne * 'GH' - Ghana / Ghana * 'GI' - Gibraltar / Gibraltar * 'GR' - Greece / Grèce * 'GL' - Greenland / Groenland * 'GD' - Grenada / Grenade * 'GP' - Guadeloupe / Guadeloupe * 'GU' - Guam / Guam * 'GT' - Guatemala / Guatemala * 'GG' - Guernsey, C.I. / Guernesey * 'GN' - Guinea / Guinée * 'GW' - Guinea-Bissau / Guinée-Bissau * 'GY' - Guyana / Guyana * 'HT' - Haiti / Haïti * 'HM' - Heard and McDonald Islands / Îles Heard et McDonald * 'VA' - Holy See (the) / Saint-Siège (le) * 'HN' - Honduras / Honduras * 'HK' - Hong Kong / Hong Kong * 'HU' - Hungary / Hongrie * 'IS' - Iceland / Islande * 'IN' - India / Inde * 'ID' - Indonesia / Indonésie * 'IR' - Iran (Islamic Republic of) / Iran (République Islamique d') * 'IQ' - Iraq / Iraq * 'IE' - Ireland / Irlande * 'IM' - Isle of Man / Île de Man * 'IL' - Israel / Israël * 'IT' - Italy / Italie * 'JM' - Jamaica / Jamaïque * 'JP' - Japan / Japon * 'JE' - Jersey, C.I. / Jersey * 'JO' - Jordan / Jordanie * 'KZ' - Kazakhstan / Kazakhstan * 'KE' - Kenya / Kenya * 'KI' - Kiribati / Kiribati * 'KP' - Korea (Dem. People's Rep. of) / Corée (la Rép. populaire dém. de) * 'KR' - Korea (the Republic of) / Corée (la République de) * 'KW' - Kuwait / Koweït * 'KG' - Kyrgystan / Kirghizistan * 'LA' - Lao People's Dem. Republic / Laos (République dém. populaire du) * 'LV' - Latvia / Lettonie * 'LB' - Lebanon / Liban * 'LS' - Lesotho / Lesotho * 'LR' - Liberia / Libéria * 'LY' - Libyan Arab Jamahiriya / Jamahiriya arabe libyenne * 'LI' - Liechtenstein / Liechtenstein * 'LT' - Lithuania / Lithuanie * 'LU' - Luxembourg / Luxembourg * 'MO' - Macao / Macao * 'MK' - Macedonia (Former Yugoslav Republic) / Macédoine (Ex république yougoslave) * 'MG' - Madagascar / Madagascar * 'MW' - Malawi / Malawi * 'MY' - Malaysia / Malaisie * 'MV' - Maldives / Maldives * 'ML' - Mali / Mali * 'MT' - Malta / Malte * 'MH' - Marshall Islands / Îles Marshall * 'MQ' - Martinique / Martinique * 'MR' - Mauritania / Mauritanie * 'MU' - Mauritius / Maurice (Île) * 'YT' - Mayotte / Mayotte * 'MX' - Mexico / Mexique * 'FM' - Micronesia (Federated States of) / Micronésie (États fédérés de) * 'MD' - Moldova (the Republic of) / Moldova (République de) * 'MC' - Monaco / Monaco * 'MN' - Mongolia / Mongolie * 'ME' - Montenegro / Monténégro * 'MS' - Montserrat / Montserrat * 'MA' - Morocco / Maroc * 'MZ' - Mozambique / Mozambique * 'MM' - Myanmar / Myanmar * 'NA' - Namibia / Namibie * 'NR' - Nauru / Nauru * 'NP' - Nepal / Népal * 'NL' - Netherlands / Pays-Bas * 'AN' - Netherlands Antilles / Antilles néerlandaises * 'NC' - New Caledonia / Nouvelle-Calédonie * 'NZ' - New Zealand / Nouvelle-Zélande * 'NI' - Nicaragua / Nicaragua * 'NE' - Niger / Niger * 'NG' - Nigeria / Nigéria * 'NU' - Niue / Niue * 'NF' - Norfolk Island / Île Norfolk * 'MP' - Northern Mariana Islands / Îles Mariannes du Nord * 'NO' - Norway / Norvège * 'OM' - Oman / Oman * 'PK' - Pakistan / Pakistan * 'PW' - Palau / Palaos * 'PS' - Palestine (State of) / Palestine (État de) * 'PA' - Panama / Panama * 'PG' - Papua New Guinea / Papouasie-Nouvelle-Guinée * 'PY' - Paraguay / Paraguay * 'PE' - Peru / Pérou * 'PH' - Philippines / Philippines * 'PN' - Pitcairn / Pitcairn * 'PL' - Poland / Pologne * 'PT' - Portugal / Portugal * 'PR' - Puerto Rico / Puerto Rico * 'QA' - Qatar / Qatar * 'RE' - Reunion Island / Réunion (Île de la) * 'RO' - Romania / Roumanie * 'RU' - Russian Federation (the) / Russie (la Fédération de) * 'RW' - Rwanda / Rwanda * 'BL' - Saint Barthélemy / Saint-Barthélemy * 'SH' - Saint Helena / Sainte-Hélène * 'KN' - Saint Kitts and Nevis / Saint-Kitts-et-Nevis * 'LC' - Saint Lucia / Sainte-Lucie * 'MF' - Saint Martin (French part) / Saint-Martin (partie française) * 'PM' - Saint Pierre and Miquelon / Saint-Pierre-et-Miquelon * 'VC' - Saint Vincent and the Grenadines / Saint-Vincent-et-les-Grenadines * 'WS' - Samoa / Samoa * 'SM' - San Marino / Saint-Marin * 'ST' - Sao Tome and Principe / Sao Tomé-et-Principe * 'SA' - Saudi Arabia / Arabie saoudite * 'SN' - Senegal / Sénégal * 'RS' - Serbia / Serbie * 'CS' - Serbia and Montenegro / Serbie-et-Monténégro * 'SC' - Seychelles / Seychelles * 'SL' - Sierra Leone / Sierra Leone * 'SG' - Singapore / Singapour * 'SX' - Sint Maarten (Dutch part) / Saint-Martin (partie néerlandaise) * 'SK' - Slovakia (Slovak Republic) / Slovaquie (République slovaque) * 'SI' - Slovenia / Slovénie * 'GS' - So. Georgia and So. Sandwich Islands / Îles Géorgie du Sud et Sandwich du Sud * 'SB' - Solomon Islands / Îles Salomon * 'SO' - Somalia / Somalie * 'ZA' - South Africa / Afrique du Sud * 'SS' - South Sudan / Soudan du Sud (le) * 'ES' - Spain / Espagne * 'LK' - Sri Lanka / Sri Lanka * 'SD' - Sudan / Soudan * 'SR' - Suriname / Suriname * 'SJ' - Svalbard and Jan Mayen Islands / Îles Svalbard et Jan Mayen * 'SE' - Sweden / Suède * 'CH' - Switzerland / Suisse * 'SY' - Syrian Arab Republic / République arabe syrienne * 'TW' - Taiwan / Taïwan * 'TJ' - Tajikistan / Tadjikistan * 'TZ' - Tanzania (United Republic of) / Tanzanie (République-Unie de) * 'TH' - Thailand / Thaïlande * 'TL' - Timor-Leste / Timor-Leste * 'TG' - Togo / Togo * 'TK' - Tokelau / Tokelau * 'TO' - Tonga / Tonga * 'TT' - Trinidad and Tobago / Trinité-et-Tobago * 'TN' - Tunisia / Tunisie * 'TR' - Turkey / Turquie * 'TM' - Turkmenistan / Turkménistan * 'TC' - Turks and Caicos Islands (the) / Turks-et-Caïcos (les Iles) * 'TV' - Tuvalu / Tuvalu * 'UG' - Uganda / Ouganda * 'UA' - Ukraine / Ukraine * 'AE' - United Arab Emirates (the) / Émirats arabes unis (les) * 'GB' - United Kingdom (the) / Royaume-Uni (le) * 'UM' - United States Minor Outlying Is.'s / Îles mineures éloignées des États-Unis * 'UY' - Uruguay / Uruguay * 'UZ' - Uzbekistan / Ouzbékistan * 'VU' - Vanuatu / Vanuatu * 'VE' - Venezuela (Bolivarian Republic of) / Venezuela (République bolivarienne du) * 'VN' - Viet Nam / Viet Nam * 'VG' - Virgin Islands (British) / Vierges britanniques (les Iles) * 'VI' - Virgin Islands (U.S.) / Vierges des États-Unix (les Iles) * 'WF' - Wallis and Futuna Islands / Îles Wallis et Futuna * 'EH' - Western Sahara / Sahara occidental * 'YE' - Yemen / Yémen * 'ZM' - Zambia / Zambie * 'ZW' - Zimbabwe / Zimbabwe * 'ZZ' - Unknown / Inconnu 
 */

@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-03-29T08:53:00.631912700-04:00[America/New_York]")
public enum CountryCode {
  
  CA("CA"),
  
  US("US"),
  
  AF("AF"),
  
  AX("AX"),
  
  AL("AL"),
  
  DZ("DZ"),
  
  AS("AS"),
  
  AD("AD"),
  
  AO("AO"),
  
  AI("AI"),
  
  AQ("AQ"),
  
  AG("AG"),
  
  AR("AR"),
  
  AM("AM"),
  
  AW("AW"),
  
  AU("AU"),
  
  AT("AT"),
  
  AZ("AZ"),
  
  BS("BS"),
  
  BH("BH"),
  
  BD("BD"),
  
  BB("BB"),
  
  BY("BY"),
  
  BE("BE"),
  
  BZ("BZ"),
  
  BJ("BJ"),
  
  BM("BM"),
  
  BT("BT"),
  
  BO("BO"),
  
  BQ("BQ"),
  
  BA("BA"),
  
  BW("BW"),
  
  BV("BV"),
  
  BR("BR"),
  
  IO("IO"),
  
  BN("BN"),
  
  BG("BG"),
  
  BF("BF"),
  
  BI("BI"),
  
  CV("CV"),
  
  KH("KH"),
  
  CM("CM"),
  
  KY("KY"),
  
  CF("CF"),
  
  TD("TD"),
  
  CL("CL"),
  
  CN("CN"),
  
  CX("CX"),
  
  CC("CC"),
  
  CO("CO"),
  
  KM("KM"),
  
  CG("CG"),
  
  CD("CD"),
  
  CK("CK"),
  
  CR("CR"),
  
  CI("CI"),
  
  HR("HR"),
  
  CU("CU"),
  
  CW("CW"),
  
  CY("CY"),
  
  CZ("CZ"),
  
  DK("DK"),
  
  DJ("DJ"),
  
  DM("DM"),
  
  DO("DO"),
  
  EC("EC"),
  
  EG("EG"),
  
  SV("SV"),
  
  GQ("GQ"),
  
  ER("ER"),
  
  EE("EE"),
  
  SZ("SZ"),
  
  ET("ET"),
  
  FK("FK"),
  
  FO("FO"),
  
  FJ("FJ"),
  
  FI("FI"),
  
  FR("FR"),
  
  FX("FX"),
  
  GF("GF"),
  
  PF("PF"),
  
  TF("TF"),
  
  GA("GA"),
  
  GM("GM"),
  
  GE("GE"),
  
  DE("DE"),
  
  GH("GH"),
  
  GI("GI"),
  
  GR("GR"),
  
  GL("GL"),
  
  GD("GD"),
  
  GP("GP"),
  
  GU("GU"),
  
  GT("GT"),
  
  GG("GG"),
  
  GW("GW"),
  
  GN("GN"),
  
  GY("GY"),
  
  HT("HT"),
  
  HM("HM"),
  
  VA("VA"),
  
  HN("HN"),
  
  HK("HK"),
  
  HU("HU"),
  
  IS("IS"),
  
  IN("IN"),
  
  ID("ID"),
  
  IR("IR"),
  
  IQ("IQ"),
  
  IE("IE"),
  
  IM("IM"),
  
  IL("IL"),
  
  IT("IT"),
  
  JM("JM"),
  
  JP("JP"),
  
  JE("JE"),
  
  JO("JO"),
  
  KZ("KZ"),
  
  KE("KE"),
  
  KI("KI"),
  
  KP("KP"),
  
  KR("KR"),
  
  KW("KW"),
  
  KG("KG"),
  
  LA("LA"),
  
  LV("LV"),
  
  LB("LB"),
  
  LS("LS"),
  
  LR("LR"),
  
  LY("LY"),
  
  LI("LI"),
  
  LT("LT"),
  
  LU("LU"),
  
  MO("MO"),
  
  MK("MK"),
  
  MG("MG"),
  
  MW("MW"),
  
  MY("MY"),
  
  MV("MV"),
  
  ML("ML"),
  
  MT("MT"),
  
  MH("MH"),
  
  MQ("MQ"),
  
  MR("MR"),
  
  MU("MU"),
  
  YT("YT"),
  
  MX("MX"),
  
  FM("FM"),
  
  MD("MD"),
  
  MC("MC"),
  
  MN("MN"),
  
  ME("ME"),
  
  MS("MS"),
  
  MA("MA"),
  
  MZ("MZ"),
  
  MM("MM"),
  
  NA("NA"),
  
  NR("NR"),
  
  NP("NP"),
  
  NL("NL"),
  
  AN("AN"),
  
  NC("NC"),
  
  NZ("NZ"),
  
  NI("NI"),
  
  NE("NE"),
  
  NG("NG"),
  
  NU("NU"),
  
  NF("NF"),
  
  MP("MP"),
  
  NO("NO"),
  
  OM("OM"),
  
  PK("PK"),
  
  PW("PW"),
  
  PS("PS"),
  
  PA("PA"),
  
  PG("PG"),
  
  PY("PY"),
  
  PE("PE"),
  
  PH("PH"),
  
  PN("PN"),
  
  PL("PL"),
  
  PT("PT"),
  
  PR("PR"),
  
  QA("QA"),
  
  RE("RE"),
  
  RO("RO"),
  
  RU("RU"),
  
  RW("RW"),
  
  BL("BL"),
  
  SH("SH"),
  
  KN("KN"),
  
  LC("LC"),
  
  MF("MF"),
  
  PM("PM"),
  
  VC("VC"),
  
  WS("WS"),
  
  SM("SM"),
  
  ST("ST"),
  
  SA("SA"),
  
  SN("SN"),
  
  RS("RS"),
  
  CS("CS"),
  
  SC("SC"),
  
  SL("SL"),
  
  SG("SG"),
  
  SX("SX"),
  
  SK("SK"),
  
  SI("SI"),
  
  GS("GS"),
  
  SB("SB"),
  
  SO("SO"),
  
  ZA("ZA"),
  
  SS("SS"),
  
  ES("ES"),
  
  LK("LK"),
  
  SD("SD"),
  
  SR("SR"),
  
  SJ("SJ"),
  
  SE("SE"),
  
  CH("CH"),
  
  SY("SY"),
  
  TW("TW"),
  
  TJ("TJ"),
  
  TZ("TZ"),
  
  TH("TH"),
  
  TL("TL"),
  
  TG("TG"),
  
  TK("TK"),
  
  TO("TO"),
  
  TT("TT"),
  
  TN("TN"),
  
  TR("TR"),
  
  TM("TM"),
  
  TC("TC"),
  
  TV("TV"),
  
  UG("UG"),
  
  UA("UA"),
  
  AE("AE"),
  
  GB("GB"),
  
  UM("UM"),
  
  UY("UY"),
  
  UZ("UZ"),
  
  VU("VU"),
  
  VE("VE"),
  
  VN("VN"),
  
  VG("VG"),
  
  VI("VI"),
  
  WF("WF"),
  
  EH("EH"),
  
  YE("YE"),
  
  ZM("ZM"),
  
  ZW("ZW"),
  
  ZZ("ZZ");

  private String value;

  CountryCode(String value) {
    this.value = value;
  }

  @JsonValue
  public String getValue() {
    return value;
  }

  @Override
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static CountryCode fromValue(String value) {
    for (CountryCode b : CountryCode.values()) {
      if (b.value.equals(value)) {
        return b;
      }
    }
    throw new IllegalArgumentException("Unexpected value '" + value + "'");
  }
}

