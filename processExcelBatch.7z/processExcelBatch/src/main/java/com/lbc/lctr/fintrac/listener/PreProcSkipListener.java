package com.lbc.lctr.fintrac.listener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.SkipListener;
import org.springframework.batch.core.StepExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;

import com.lbc.lctr.fintrac.common.domain.LCTRReport;

public class PreProcSkipListener implements  SkipListener<LCTRReport, LCTRReport> {

	private static final Logger logger = LoggerFactory.getLogger(PreProcSkipListener.class);

	@Autowired
	@Qualifier("jdbcTemplate")
	private JdbcTemplate jdbcTemplate;
	
	@Value("#{stepExecution}")
	private StepExecution stepExecution;

	@Override
	public void onSkipInRead(Throwable t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onSkipInWrite(LCTRReport item, Throwable t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onSkipInProcess(LCTRReport item, Throwable t) {
		// TODO Auto-generated method stub
		
	}
	

	
}
