package com.lbc.lctr.fintrac.common.domain;

import javax.annotation.Generated;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

/**
 * * 'AG' - Aguascalientas / Aguascalientas * 'BA' - Baja, Calif. (North) / Baja, Calif. (Nord) * 'BJ' - Baja, Calif. (South) / Baja, Calif. (Sud) * 'CE' - Campeche / Campeche * 'CI' - Chiapas / Chiapas * 'CH' - Chihuahua / Chihuahua * 'CU' - Coahuila de Zaragoza / Coahuila de Zaragoza * 'CL' - Colima / Colima * 'DF' - Distrito / Distrito (Federal) * 'DO' - Durango / Durango * 'GU' - Guanajuato / Guanajuato * 'GR' - Guerreo / Guerreo * 'HL' - Hidalgo / Hidalgo * 'JL' - Jalisco / Jalisco * 'MX' - Mexico (State) / Mexico (État) * 'MC' - Michoacan de Ocampo / Michoacan de Ocampo * 'MR' - Morelos / Morelos * 'NA' - Nayarit / Nayarit * 'NL' - Nuevo Leon / Nuevo Leon * 'OA' - Oaxaca / Oaxaca * 'PB' - Puebla / Puebla * 'QU' - Queretaro de Arteaga / Queretaro de Arteaga * 'QR' - Quintana Roo / Quintana Roo * 'SL' - San Luis Potosi / San Luis Potosi * 'SI' - Sinaloa / Sinaloa * 'SO' - Sonora / Sonora * 'TB' - Tabasco / Tabasco * 'TA' - Tamaulipas / Tamaulipas * 'TL' - Tlaxcala / Tlaxcala * 'VC' - Veracruz-Llave / Veracruz-Llave * 'YU' - Yucatan / Yucatan * 'ZA' - Zacatecas / Zacatecas 
 */

@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-03-29T08:53:00.631912700-04:00[America/New_York]")
public enum ProvinceStateCodeOneOf2 {
  
  AG("AG"),
  
  BA("BA"),
  
  BJ("BJ"),
  
  CE("CE"),
  
  CI("CI"),
  
  CH("CH"),
  
  CU("CU"),
  
  CL("CL"),
  
  DF("DF"),
  
  DO("DO"),
  
  GU("GU"),
  
  GR("GR"),
  
  HL("HL"),
  
  JL("JL"),
  
  MX("MX"),
  
  MC("MC"),
  
  MR("MR"),
  
  NA("NA"),
  
  NL("NL"),
  
  OA("OA"),
  
  PB("PB"),
  
  QU("QU"),
  
  QR("QR"),
  
  SL("SL"),
  
  SI("SI"),
  
  SO("SO"),
  
  TB("TB"),
  
  TA("TA"),
  
  TL("TL"),
  
  VC("VC"),
  
  YU("YU"),
  
  ZA("ZA");

  private String value;

  ProvinceStateCodeOneOf2(String value) {
    this.value = value;
  }

  @JsonValue
  public String getValue() {
    return value;
  }

  @Override
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static ProvinceStateCodeOneOf2 fromValue(String value) {
    for (ProvinceStateCodeOneOf2 b : ProvinceStateCodeOneOf2.values()) {
      if (b.value.equals(value)) {
        return b;
      }
    }
    throw new IllegalArgumentException("Unexpected value '" + value + "'");
  }
}

