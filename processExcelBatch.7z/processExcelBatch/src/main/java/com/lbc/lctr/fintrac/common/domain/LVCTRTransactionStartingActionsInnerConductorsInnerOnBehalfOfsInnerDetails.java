package com.lbc.lctr.fintrac.common.domain;

import java.util.Objects;

import javax.annotation.Generated;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.fasterxml.jackson.annotation.JsonValue;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * LVCTRTransactionStartingActionsInnerConductorsInnerOnBehalfOfsInnerDetails
 */

@JsonTypeName("LVCTRTransaction_startingActions_inner_conductors_inner_onBehalfOfs_inner_details")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-03-29T08:53:00.631912700-04:00[America/New_York]")
public class LVCTRTransactionStartingActionsInnerConductorsInnerOnBehalfOfsInnerDetails {

  @JsonProperty("clientNumber")
  private String clientNumber;

  /**
   * * `1` - Accountant / Comptable * `2` - Agent / Mandataire * `3` - Borrower / Emprunteur * `4` - Broker / Courtier   * `5` - Customer / Client * `6` - Employee / Employé * `7` - Friend / Ami * `8` - Relative / Membre de la famille * `9` - Other / Autre * `10` - Legal counsel / Conseiller juridique * `11` - Employer / Employeur * `12` - Joint/Secondary owner / Propriétaire conjoint/secondaire * `13` - Power of attorney / Procuration 
   */
  public enum RelationshipOfConductorCodeEnum {
    NUMBER_1(1),
    
    NUMBER_2(2),
    
    NUMBER_3(3),
    
    NUMBER_4(4),
    
    NUMBER_5(5),
    
    NUMBER_6(6),
    
    NUMBER_7(7),
    
    NUMBER_8(8),
    
    NUMBER_9(9),
    
    NUMBER_10(10),
    
    NUMBER_11(11),
    
    NUMBER_12(12),
    
    NUMBER_13(13);

    private Integer value;

    RelationshipOfConductorCodeEnum(Integer value) {
      this.value = value;
    }

    @JsonValue
    public Integer getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static RelationshipOfConductorCodeEnum fromValue(Integer value) {
      for (RelationshipOfConductorCodeEnum b : RelationshipOfConductorCodeEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  @JsonProperty("relationshipOfConductorCode")
  private RelationshipOfConductorCodeEnum relationshipOfConductorCode;

  @JsonProperty("relationshipOfConductorOther")
  private String relationshipOfConductorOther;

  @JsonProperty("emailAddress")
  private String emailAddress;

  public LVCTRTransactionStartingActionsInnerConductorsInnerOnBehalfOfsInnerDetails clientNumber(String clientNumber) {
    this.clientNumber = clientNumber;
    return this;
  }

  /**
   * Get clientNumber
   * @return clientNumber
  */
  @Size(max = 100) 
  @Schema(name = "clientNumber", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getClientNumber() {
    return clientNumber;
  }

  public void setClientNumber(String clientNumber) {
    this.clientNumber = clientNumber;
  }

  public LVCTRTransactionStartingActionsInnerConductorsInnerOnBehalfOfsInnerDetails relationshipOfConductorCode(RelationshipOfConductorCodeEnum relationshipOfConductorCode) {
    this.relationshipOfConductorCode = relationshipOfConductorCode;
    return this;
  }

  /**
   * * `1` - Accountant / Comptable * `2` - Agent / Mandataire * `3` - Borrower / Emprunteur * `4` - Broker / Courtier   * `5` - Customer / Client * `6` - Employee / Employé * `7` - Friend / Ami * `8` - Relative / Membre de la famille * `9` - Other / Autre * `10` - Legal counsel / Conseiller juridique * `11` - Employer / Employeur * `12` - Joint/Secondary owner / Propriétaire conjoint/secondaire * `13` - Power of attorney / Procuration 
   * @return relationshipOfConductorCode
  */
  
  @Schema(name = "relationshipOfConductorCode", description = "* `1` - Accountant / Comptable * `2` - Agent / Mandataire * `3` - Borrower / Emprunteur * `4` - Broker / Courtier   * `5` - Customer / Client * `6` - Employee / Employé * `7` - Friend / Ami * `8` - Relative / Membre de la famille * `9` - Other / Autre * `10` - Legal counsel / Conseiller juridique * `11` - Employer / Employeur * `12` - Joint/Secondary owner / Propriétaire conjoint/secondaire * `13` - Power of attorney / Procuration ", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public RelationshipOfConductorCodeEnum getRelationshipOfConductorCode() {
    return relationshipOfConductorCode;
  }

  public void setRelationshipOfConductorCode(RelationshipOfConductorCodeEnum relationshipOfConductorCode) {
    this.relationshipOfConductorCode = relationshipOfConductorCode;
  }

  public LVCTRTransactionStartingActionsInnerConductorsInnerOnBehalfOfsInnerDetails relationshipOfConductorOther(String relationshipOfConductorOther) {
    this.relationshipOfConductorOther = relationshipOfConductorOther;
    return this;
  }

  /**
   * Get relationshipOfConductorOther
   * @return relationshipOfConductorOther
  */
  @Size(max = 200) 
  @Schema(name = "relationshipOfConductorOther", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getRelationshipOfConductorOther() {
    return relationshipOfConductorOther;
  }

  public void setRelationshipOfConductorOther(String relationshipOfConductorOther) {
    this.relationshipOfConductorOther = relationshipOfConductorOther;
  }

  public LVCTRTransactionStartingActionsInnerConductorsInnerOnBehalfOfsInnerDetails emailAddress(String emailAddress) {
    this.emailAddress = emailAddress;
    return this;
  }

  /**
   * Get emailAddress
   * @return emailAddress
  */
  @Size(max = 200) 
  @Schema(name = "emailAddress", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getEmailAddress() {
    return emailAddress;
  }

  public void setEmailAddress(String emailAddress) {
    this.emailAddress = emailAddress;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    LVCTRTransactionStartingActionsInnerConductorsInnerOnBehalfOfsInnerDetails lvCTRTransactionStartingActionsInnerConductorsInnerOnBehalfOfsInnerDetails = (LVCTRTransactionStartingActionsInnerConductorsInnerOnBehalfOfsInnerDetails) o;
    return Objects.equals(this.clientNumber, lvCTRTransactionStartingActionsInnerConductorsInnerOnBehalfOfsInnerDetails.clientNumber) &&
        Objects.equals(this.relationshipOfConductorCode, lvCTRTransactionStartingActionsInnerConductorsInnerOnBehalfOfsInnerDetails.relationshipOfConductorCode) &&
        Objects.equals(this.relationshipOfConductorOther, lvCTRTransactionStartingActionsInnerConductorsInnerOnBehalfOfsInnerDetails.relationshipOfConductorOther) &&
        Objects.equals(this.emailAddress, lvCTRTransactionStartingActionsInnerConductorsInnerOnBehalfOfsInnerDetails.emailAddress);
  }

  @Override
  public int hashCode() {
    return Objects.hash(clientNumber, relationshipOfConductorCode, relationshipOfConductorOther, emailAddress);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class LVCTRTransactionStartingActionsInnerConductorsInnerOnBehalfOfsInnerDetails {\n");
    sb.append("    clientNumber: ").append(toIndentedString(clientNumber)).append("\n");
    sb.append("    relationshipOfConductorCode: ").append(toIndentedString(relationshipOfConductorCode)).append("\n");
    sb.append("    relationshipOfConductorOther: ").append(toIndentedString(relationshipOfConductorOther)).append("\n");
    sb.append("    emailAddress: ").append(toIndentedString(emailAddress)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

