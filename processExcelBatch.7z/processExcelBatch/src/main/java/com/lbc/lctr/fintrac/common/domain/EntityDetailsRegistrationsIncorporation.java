package com.lbc.lctr.fintrac.common.domain;

import java.util.Objects;

import javax.annotation.Generated;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.fasterxml.jackson.annotation.JsonValue;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * EntityDetailsRegistrationsIncorporationsInner
 */

@JsonTypeName("EntityDetails_registrationsIncorporations_inner")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-03-29T08:53:00.631912700-04:00[America/New_York]")
public class EntityDetailsRegistrationsIncorporation {

  /**
   * * `1` - Registration / Inscription * `2` - Incorporation / Incorporation 
   */
  public enum TypeCodeEnum {
    NUMBER_1(1),
    
    NUMBER_2(2);

    private Integer value;

    TypeCodeEnum(Integer value) {
      this.value = value;
    }

    @JsonValue
    public Integer getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static TypeCodeEnum fromValue(Integer value) {
      for (TypeCodeEnum b : TypeCodeEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  @JsonProperty("typeCode")
  private TypeCodeEnum typeCode;

  @JsonProperty("number")
  private String number;

  @JsonProperty("jurisdictionOfIssueCountryCode")
  private CountryCode jurisdictionOfIssueCountryCode;

  @JsonProperty("jurisdictionOfIssueProvinceStateCode")
  private ProvinceStateCode jurisdictionOfIssueProvinceStateCode;

  @JsonProperty("jurisdictionOfIssueProvinceStateName")
  private String jurisdictionOfIssueProvinceStateName;

  public EntityDetailsRegistrationsIncorporation typeCode(TypeCodeEnum typeCode) {
    this.typeCode = typeCode;
    return this;
  }

  /**
   * * `1` - Registration / Inscription * `2` - Incorporation / Incorporation 
   * @return typeCode
  */
  @NotNull 
  @Schema(name = "typeCode", description = "* `1` - Registration / Inscription * `2` - Incorporation / Incorporation ", requiredMode = Schema.RequiredMode.REQUIRED)
  public TypeCodeEnum getTypeCode() {
    return typeCode;
  }

  public void setTypeCode(TypeCodeEnum typeCode) {
    this.typeCode = typeCode;
  }

  public EntityDetailsRegistrationsIncorporation number(String number) {
    this.number = number;
    return this;
  }

  /**
   * Get number
   * @return number
  */
  @Size(max = 100) 
  @Schema(name = "number", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getNumber() {
    return number;
  }

  public void setNumber(String number) {
    this.number = number;
  }

  public EntityDetailsRegistrationsIncorporation jurisdictionOfIssueCountryCode(CountryCode jurisdictionOfIssueCountryCode) {
    this.jurisdictionOfIssueCountryCode = jurisdictionOfIssueCountryCode;
    return this;
  }

  /**
   * Get jurisdictionOfIssueCountryCode
   * @return jurisdictionOfIssueCountryCode
  */
  @Valid 
  @Schema(name = "jurisdictionOfIssueCountryCode", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public CountryCode getJurisdictionOfIssueCountryCode() {
    return jurisdictionOfIssueCountryCode;
  }

  public void setJurisdictionOfIssueCountryCode(CountryCode jurisdictionOfIssueCountryCode) {
    this.jurisdictionOfIssueCountryCode = jurisdictionOfIssueCountryCode;
  }

  public EntityDetailsRegistrationsIncorporation jurisdictionOfIssueProvinceStateCode(ProvinceStateCode jurisdictionOfIssueProvinceStateCode) {
    this.jurisdictionOfIssueProvinceStateCode = jurisdictionOfIssueProvinceStateCode;
    return this;
  }

  /**
   * Get jurisdictionOfIssueProvinceStateCode
   * @return jurisdictionOfIssueProvinceStateCode
  */
  @Valid 
  @Schema(name = "jurisdictionOfIssueProvinceStateCode", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public ProvinceStateCode getJurisdictionOfIssueProvinceStateCode() {
    return jurisdictionOfIssueProvinceStateCode;
  }

  public void setJurisdictionOfIssueProvinceStateCode(ProvinceStateCode jurisdictionOfIssueProvinceStateCode) {
    this.jurisdictionOfIssueProvinceStateCode = jurisdictionOfIssueProvinceStateCode;
  }

  public EntityDetailsRegistrationsIncorporation jurisdictionOfIssueProvinceStateName(String jurisdictionOfIssueProvinceStateName) {
    this.jurisdictionOfIssueProvinceStateName = jurisdictionOfIssueProvinceStateName;
    return this;
  }

  /**
   * Get jurisdictionOfIssueProvinceStateName
   * @return jurisdictionOfIssueProvinceStateName
  */
  @Size(max = 100) 
  @Schema(name = "jurisdictionOfIssueProvinceStateName", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getJurisdictionOfIssueProvinceStateName() {
    return jurisdictionOfIssueProvinceStateName;
  }

  public void setJurisdictionOfIssueProvinceStateName(String jurisdictionOfIssueProvinceStateName) {
    this.jurisdictionOfIssueProvinceStateName = jurisdictionOfIssueProvinceStateName;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    EntityDetailsRegistrationsIncorporation entityDetailsRegistrationsIncorporationsInner = (EntityDetailsRegistrationsIncorporation) o;
    return Objects.equals(this.typeCode, entityDetailsRegistrationsIncorporationsInner.typeCode) &&
        Objects.equals(this.number, entityDetailsRegistrationsIncorporationsInner.number) &&
        Objects.equals(this.jurisdictionOfIssueCountryCode, entityDetailsRegistrationsIncorporationsInner.jurisdictionOfIssueCountryCode) &&
        Objects.equals(this.jurisdictionOfIssueProvinceStateCode, entityDetailsRegistrationsIncorporationsInner.jurisdictionOfIssueProvinceStateCode) &&
        Objects.equals(this.jurisdictionOfIssueProvinceStateName, entityDetailsRegistrationsIncorporationsInner.jurisdictionOfIssueProvinceStateName);
  }

  @Override
  public int hashCode() {
    return Objects.hash(typeCode, number, jurisdictionOfIssueCountryCode, jurisdictionOfIssueProvinceStateCode, jurisdictionOfIssueProvinceStateName);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class EntityDetailsRegistrationsIncorporationsInner {\n");
    sb.append("    typeCode: ").append(toIndentedString(typeCode)).append("\n");
    sb.append("    number: ").append(toIndentedString(number)).append("\n");
    sb.append("    jurisdictionOfIssueCountryCode: ").append(toIndentedString(jurisdictionOfIssueCountryCode)).append("\n");
    sb.append("    jurisdictionOfIssueProvinceStateCode: ").append(toIndentedString(jurisdictionOfIssueProvinceStateCode)).append("\n");
    sb.append("    jurisdictionOfIssueProvinceStateName: ").append(toIndentedString(jurisdictionOfIssueProvinceStateName)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

