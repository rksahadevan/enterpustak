package com.lbc.lctr.fintrac.common.domain;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.annotation.Generated;
import javax.validation.Valid;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * LVCTRTransactionStartingActionsInnerDetails
 */

@JsonTypeName("LVCTRTransaction_startingActions_inner_details")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-03-29T08:53:00.631912700-04:00[America/New_York]")
public class LVCTRTransactionStartingActionsInnerDetails {

  @JsonProperty("amount")
  private String amount;

  @JsonProperty("virtualCurrencyTypeCode")
  private VirtualCurrencyCode virtualCurrencyTypeCode;

  @JsonProperty("virtualCurrencyTypeOther")
  private String virtualCurrencyTypeOther;

  @JsonProperty("exchangeRate")
  private String exchangeRate;

  @JsonProperty("sendingVirtualCurrencyAddresses")
  @Valid
  private List<String> sendingVirtualCurrencyAddresses = null;

  @JsonProperty("howVirtualCurrencyObtained")
  private String howVirtualCurrencyObtained;

  @JsonProperty("sourceOfVirtualCurrencyIndicator")
  private Boolean sourceOfVirtualCurrencyIndicator;

  @JsonProperty("conductorIndicator")
  private Boolean conductorIndicator;

  public LVCTRTransactionStartingActionsInnerDetails amount(String amount) {
    this.amount = amount;
    return this;
  }

  /**
   * Get amount
   * @return amount
  */
  @Pattern(regexp = "^\\\\d{1,17}(\\\\.\\\\d{2,10})?$") 
  @Schema(name = "amount", example = "13797.59", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getAmount() {
    return amount;
  }

  public void setAmount(String amount) {
    this.amount = amount;
  }

  public LVCTRTransactionStartingActionsInnerDetails virtualCurrencyTypeCode(VirtualCurrencyCode virtualCurrencyTypeCode) {
    this.virtualCurrencyTypeCode = virtualCurrencyTypeCode;
    return this;
  }

  /**
   * Get virtualCurrencyTypeCode
   * @return virtualCurrencyTypeCode
  */
  @Valid 
  @Schema(name = "virtualCurrencyTypeCode", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public VirtualCurrencyCode getVirtualCurrencyTypeCode() {
    return virtualCurrencyTypeCode;
  }

  public void setVirtualCurrencyTypeCode(VirtualCurrencyCode virtualCurrencyTypeCode) {
    this.virtualCurrencyTypeCode = virtualCurrencyTypeCode;
  }

  public LVCTRTransactionStartingActionsInnerDetails virtualCurrencyTypeOther(String virtualCurrencyTypeOther) {
    this.virtualCurrencyTypeOther = virtualCurrencyTypeOther;
    return this;
  }

  /**
   * Get virtualCurrencyTypeOther
   * @return virtualCurrencyTypeOther
  */
  @Size(max = 200) 
  @Schema(name = "virtualCurrencyTypeOther", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getVirtualCurrencyTypeOther() {
    return virtualCurrencyTypeOther;
  }

  public void setVirtualCurrencyTypeOther(String virtualCurrencyTypeOther) {
    this.virtualCurrencyTypeOther = virtualCurrencyTypeOther;
  }

  public LVCTRTransactionStartingActionsInnerDetails exchangeRate(String exchangeRate) {
    this.exchangeRate = exchangeRate;
    return this;
  }

  /**
   * Get exchangeRate
   * @return exchangeRate
  */
  @Pattern(regexp = "^\\\\d{1,17}(\\\\.\\\\d{2,10})?$") 
  @Schema(name = "exchangeRate", example = "501.7966918945", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getExchangeRate() {
    return exchangeRate;
  }

  public void setExchangeRate(String exchangeRate) {
    this.exchangeRate = exchangeRate;
  }

  public LVCTRTransactionStartingActionsInnerDetails sendingVirtualCurrencyAddresses(List<String> sendingVirtualCurrencyAddresses) {
    this.sendingVirtualCurrencyAddresses = sendingVirtualCurrencyAddresses;
    return this;
  }

  public LVCTRTransactionStartingActionsInnerDetails addSendingVirtualCurrencyAddressesItem(String sendingVirtualCurrencyAddressesItem) {
    if (this.sendingVirtualCurrencyAddresses == null) {
      this.sendingVirtualCurrencyAddresses = new ArrayList<>();
    }
    this.sendingVirtualCurrencyAddresses.add(sendingVirtualCurrencyAddressesItem);
    return this;
  }

  /**
   * Get sendingVirtualCurrencyAddresses
   * @return sendingVirtualCurrencyAddresses
  */
  
  @Schema(name = "sendingVirtualCurrencyAddresses", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public List<String> getSendingVirtualCurrencyAddresses() {
    return sendingVirtualCurrencyAddresses;
  }

  public void setSendingVirtualCurrencyAddresses(List<String> sendingVirtualCurrencyAddresses) {
    this.sendingVirtualCurrencyAddresses = sendingVirtualCurrencyAddresses;
  }

  public LVCTRTransactionStartingActionsInnerDetails howVirtualCurrencyObtained(String howVirtualCurrencyObtained) {
    this.howVirtualCurrencyObtained = howVirtualCurrencyObtained;
    return this;
  }

  /**
   * Get howVirtualCurrencyObtained
   * @return howVirtualCurrencyObtained
  */
  @Size(max = 200) 
  @Schema(name = "howVirtualCurrencyObtained", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getHowVirtualCurrencyObtained() {
    return howVirtualCurrencyObtained;
  }

  public void setHowVirtualCurrencyObtained(String howVirtualCurrencyObtained) {
    this.howVirtualCurrencyObtained = howVirtualCurrencyObtained;
  }

  public LVCTRTransactionStartingActionsInnerDetails sourceOfVirtualCurrencyIndicator(Boolean sourceOfVirtualCurrencyIndicator) {
    this.sourceOfVirtualCurrencyIndicator = sourceOfVirtualCurrencyIndicator;
    return this;
  }

  /**
   * Get sourceOfVirtualCurrencyIndicator
   * @return sourceOfVirtualCurrencyIndicator
  */
  
  @Schema(name = "sourceOfVirtualCurrencyIndicator", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public Boolean getSourceOfVirtualCurrencyIndicator() {
    return sourceOfVirtualCurrencyIndicator;
  }

  public void setSourceOfVirtualCurrencyIndicator(Boolean sourceOfVirtualCurrencyIndicator) {
    this.sourceOfVirtualCurrencyIndicator = sourceOfVirtualCurrencyIndicator;
  }

  public LVCTRTransactionStartingActionsInnerDetails conductorIndicator(Boolean conductorIndicator) {
    this.conductorIndicator = conductorIndicator;
    return this;
  }

  /**
   * Get conductorIndicator
   * @return conductorIndicator
  */
  
  @Schema(name = "conductorIndicator", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public Boolean getConductorIndicator() {
    return conductorIndicator;
  }

  public void setConductorIndicator(Boolean conductorIndicator) {
    this.conductorIndicator = conductorIndicator;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    LVCTRTransactionStartingActionsInnerDetails lvCTRTransactionStartingActionsInnerDetails = (LVCTRTransactionStartingActionsInnerDetails) o;
    return Objects.equals(this.amount, lvCTRTransactionStartingActionsInnerDetails.amount) &&
        Objects.equals(this.virtualCurrencyTypeCode, lvCTRTransactionStartingActionsInnerDetails.virtualCurrencyTypeCode) &&
        Objects.equals(this.virtualCurrencyTypeOther, lvCTRTransactionStartingActionsInnerDetails.virtualCurrencyTypeOther) &&
        Objects.equals(this.exchangeRate, lvCTRTransactionStartingActionsInnerDetails.exchangeRate) &&
        Objects.equals(this.sendingVirtualCurrencyAddresses, lvCTRTransactionStartingActionsInnerDetails.sendingVirtualCurrencyAddresses) &&
        Objects.equals(this.howVirtualCurrencyObtained, lvCTRTransactionStartingActionsInnerDetails.howVirtualCurrencyObtained) &&
        Objects.equals(this.sourceOfVirtualCurrencyIndicator, lvCTRTransactionStartingActionsInnerDetails.sourceOfVirtualCurrencyIndicator) &&
        Objects.equals(this.conductorIndicator, lvCTRTransactionStartingActionsInnerDetails.conductorIndicator);
  }

  @Override
  public int hashCode() {
    return Objects.hash(amount, virtualCurrencyTypeCode, virtualCurrencyTypeOther, exchangeRate, sendingVirtualCurrencyAddresses, howVirtualCurrencyObtained, sourceOfVirtualCurrencyIndicator, conductorIndicator);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class LVCTRTransactionStartingActionsInnerDetails {\n");
    sb.append("    amount: ").append(toIndentedString(amount)).append("\n");
    sb.append("    virtualCurrencyTypeCode: ").append(toIndentedString(virtualCurrencyTypeCode)).append("\n");
    sb.append("    virtualCurrencyTypeOther: ").append(toIndentedString(virtualCurrencyTypeOther)).append("\n");
    sb.append("    exchangeRate: ").append(toIndentedString(exchangeRate)).append("\n");
    sb.append("    sendingVirtualCurrencyAddresses: ").append(toIndentedString(sendingVirtualCurrencyAddresses)).append("\n");
    sb.append("    howVirtualCurrencyObtained: ").append(toIndentedString(howVirtualCurrencyObtained)).append("\n");
    sb.append("    sourceOfVirtualCurrencyIndicator: ").append(toIndentedString(sourceOfVirtualCurrencyIndicator)).append("\n");
    sb.append("    conductorIndicator: ").append(toIndentedString(conductorIndicator)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

