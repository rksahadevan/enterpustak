package com.lbc.lctr.fintrac.common.domain;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.annotation.Generated;
import javax.validation.Valid;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.fasterxml.jackson.annotation.JsonValue;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * LCTRTransactionCompletingActionsInnerDetailsAccount
 */

@JsonTypeName("LCTRTransaction_completingActions_inner_details_account")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-03-29T08:53:00.631912700-04:00[America/New_York]")
public class LCTRAccountDetail {

  @JsonProperty("financialInstitutionNumber")
  private String financialInstitutionNumber;

  @JsonProperty("branchNumber")
  private String branchNumber;

  @JsonProperty("number")
  private String number;

  /**
   * Gets or Sets typeCode
   */
  public enum TypeCodeEnum {
    NUMBER_1(1),
    
    NUMBER_2(2),
    
    NUMBER_3(3),
    
    NUMBER_4(4),
    
    NUMBER_5(5);

    private Integer value;

    TypeCodeEnum(Integer value) {
      this.value = value;
    }

    @JsonValue
    public Integer getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static TypeCodeEnum fromValue(Integer value) {
      for (TypeCodeEnum b : TypeCodeEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  @JsonProperty("typeCode")
  private TypeCodeEnum typeCode;

  @JsonProperty("typeOther")
  private String typeOther;

  @JsonProperty("currencyCode")
  private CurrencyCode currencyCode;

  @JsonProperty("dateOpened")
  private String dateOpened;

  @JsonProperty("holders")
  @Valid
  private List<LCTRAccountHolderDetail> holders = null;

  public LCTRAccountDetail financialInstitutionNumber(String financialInstitutionNumber) {
    this.financialInstitutionNumber = financialInstitutionNumber;
    return this;
  }

  /**
   * Get financialInstitutionNumber
   * @return financialInstitutionNumber
  */
  @Size(max = 50) 
  @Schema(name = "financialInstitutionNumber", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getFinancialInstitutionNumber() {
    return financialInstitutionNumber;
  }

  public void setFinancialInstitutionNumber(String financialInstitutionNumber) {
    this.financialInstitutionNumber = financialInstitutionNumber;
  }

  public LCTRAccountDetail branchNumber(String branchNumber) {
    this.branchNumber = branchNumber;
    return this;
  }

  /**
   * Get branchNumber
   * @return branchNumber
  */
  @Size(max = 50) 
  @Schema(name = "branchNumber", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getBranchNumber() {
    return branchNumber;
  }

  public void setBranchNumber(String branchNumber) {
    this.branchNumber = branchNumber;
  }

  public LCTRAccountDetail number(String number) {
    this.number = number;
    return this;
  }

  /**
   * Get number
   * @return number
  */
  @Size(max = 100) 
  @Schema(name = "number", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getNumber() {
    return number;
  }

  public void setNumber(String number) {
    this.number = number;
  }

  public LCTRAccountDetail typeCode(TypeCodeEnum typeCode) {
    this.typeCode = typeCode;
    return this;
  }

  /**
   * Get typeCode
   * @return typeCode
  */
  
  @Schema(name = "typeCode", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public TypeCodeEnum getTypeCode() {
    return typeCode;
  }

  public void setTypeCode(TypeCodeEnum typeCode) {
    this.typeCode = typeCode;
  }

  public LCTRAccountDetail typeOther(String typeOther) {
    this.typeOther = typeOther;
    return this;
  }

  /**
   * Get typeOther
   * @return typeOther
  */
  @Size(max = 200) 
  @Schema(name = "typeOther", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getTypeOther() {
    return typeOther;
  }

  public void setTypeOther(String typeOther) {
    this.typeOther = typeOther;
  }

  public LCTRAccountDetail currencyCode(CurrencyCode currencyCode) {
    this.currencyCode = currencyCode;
    return this;
  }

  /**
   * Get currencyCode
   * @return currencyCode
  */
  @Valid 
  @Schema(name = "currencyCode", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public CurrencyCode getCurrencyCode() {
    return currencyCode;
  }

  public void setCurrencyCode(CurrencyCode currencyCode) {
    this.currencyCode = currencyCode;
  }

  public LCTRAccountDetail dateOpened(String dateOpened) {
    this.dateOpened = dateOpened;
    return this;
  }

  /**
   * Get dateOpened
   * @return dateOpened
  */
  @Pattern(regexp = "^[0-9]{4}-[0-9]{2}-[0-9]{2}$") 
  @Schema(name = "dateOpened", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getDateOpened() {
    return dateOpened;
  }

  public void setDateOpened(String dateOpened) {
    this.dateOpened = dateOpened;
  }

  public LCTRAccountDetail holders(List<LCTRAccountHolderDetail> holders) {
    this.holders = holders;
    return this;
  }

  public LCTRAccountDetail addHoldersItem(LCTRAccountHolderDetail holdersItem) {
    if (this.holders == null) {
      this.holders = new ArrayList<>();
    }
    this.holders.add(holdersItem);
    return this;
  }

  /**
   * Get holders
   * @return holders
  */
  @Valid 
  @Schema(name = "holders", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public List<LCTRAccountHolderDetail> getHolders() {
    return holders;
  }

  public void setHolders(List<LCTRAccountHolderDetail> holders) {
    this.holders = holders;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    LCTRAccountDetail lcTRTransactionCompletingActionsInnerDetailsAccount = (LCTRAccountDetail) o;
    return Objects.equals(this.financialInstitutionNumber, lcTRTransactionCompletingActionsInnerDetailsAccount.financialInstitutionNumber) &&
        Objects.equals(this.branchNumber, lcTRTransactionCompletingActionsInnerDetailsAccount.branchNumber) &&
        Objects.equals(this.number, lcTRTransactionCompletingActionsInnerDetailsAccount.number) &&
        Objects.equals(this.typeCode, lcTRTransactionCompletingActionsInnerDetailsAccount.typeCode) &&
        Objects.equals(this.typeOther, lcTRTransactionCompletingActionsInnerDetailsAccount.typeOther) &&
        Objects.equals(this.currencyCode, lcTRTransactionCompletingActionsInnerDetailsAccount.currencyCode) &&
        Objects.equals(this.dateOpened, lcTRTransactionCompletingActionsInnerDetailsAccount.dateOpened) &&
        Objects.equals(this.holders, lcTRTransactionCompletingActionsInnerDetailsAccount.holders);
  }

  @Override
  public int hashCode() {
    return Objects.hash(financialInstitutionNumber, branchNumber, number, typeCode, typeOther, currencyCode, dateOpened, holders);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class LCTRTransactionCompletingActionsInnerDetailsAccount {\n");
    sb.append("    financialInstitutionNumber: ").append(toIndentedString(financialInstitutionNumber)).append("\n");
    sb.append("    branchNumber: ").append(toIndentedString(branchNumber)).append("\n");
    sb.append("    number: ").append(toIndentedString(number)).append("\n");
    sb.append("    typeCode: ").append(toIndentedString(typeCode)).append("\n");
    sb.append("    typeOther: ").append(toIndentedString(typeOther)).append("\n");
    sb.append("    currencyCode: ").append(toIndentedString(currencyCode)).append("\n");
    sb.append("    dateOpened: ").append(toIndentedString(dateOpened)).append("\n");
    sb.append("    holders: ").append(toIndentedString(holders)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

