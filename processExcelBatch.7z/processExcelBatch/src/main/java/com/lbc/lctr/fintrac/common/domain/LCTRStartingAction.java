package com.lbc.lctr.fintrac.common.domain;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.annotation.Generated;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * LCTRTransactionStartingActionsInner
 */

@JsonTypeName("LCTRTransaction_startingActions_inner")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-03-29T08:53:00.631912700-04:00[America/New_York]")
public class LCTRStartingAction {

  @JsonProperty("details")
  private LCTRStartingActionsDetails details;

  @JsonProperty("sourcesOfCash")
  @Valid
  private List<LCTRSourcesOfCash> sourcesOfCash = null;

  @JsonProperty("conductors")
  @Valid
  private List<LCTRConductor> conductors = new ArrayList<>();

  public LCTRStartingAction details(LCTRStartingActionsDetails details) {
    this.details = details;
    return this;
  }

  /**
   * Get details
   * @return details
  */
  @NotNull @Valid 
  @Schema(name = "details", requiredMode = Schema.RequiredMode.REQUIRED)
  public LCTRStartingActionsDetails getDetails() {
    return details;
  }

  public void setDetails(LCTRStartingActionsDetails details) {
    this.details = details;
  }

  public LCTRStartingAction sourcesOfCash(List<LCTRSourcesOfCash> sourcesOfCash) {
    this.sourcesOfCash = sourcesOfCash;
    return this;
  }

  public LCTRStartingAction addSourcesOfCashItem(LCTRSourcesOfCash sourcesOfCashItem) {
    if (this.sourcesOfCash == null) {
      this.sourcesOfCash = new ArrayList<>();
    }
    this.sourcesOfCash.add(sourcesOfCashItem);
    return this;
  }

  /**
   * Get sourcesOfCash
   * @return sourcesOfCash
  */
  @Valid 
  @Schema(name = "sourcesOfCash", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public List<LCTRSourcesOfCash> getSourcesOfCash() {
    return sourcesOfCash;
  }

  public void setSourcesOfCash(List<LCTRSourcesOfCash> sourcesOfCash) {
    this.sourcesOfCash = sourcesOfCash;
  }

  public LCTRStartingAction conductors(List<LCTRConductor> conductors) {
    this.conductors = conductors;
    return this;
  }

  public LCTRStartingAction addConductorsItem(LCTRConductor conductorsItem) {
    this.conductors.add(conductorsItem);
    return this;
  }

  /**
   * Get conductors
   * @return conductors
  */
  @NotNull @Valid 
  @Schema(name = "conductors", requiredMode = Schema.RequiredMode.REQUIRED)
  public List<LCTRConductor> getConductors() {
    return conductors;
  }

  public void setConductors(List<LCTRConductor> conductors) {
    this.conductors = conductors;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    LCTRStartingAction lcTRTransactionStartingActionsInner = (LCTRStartingAction) o;
    return Objects.equals(this.details, lcTRTransactionStartingActionsInner.details) &&
        Objects.equals(this.sourcesOfCash, lcTRTransactionStartingActionsInner.sourcesOfCash) &&
        Objects.equals(this.conductors, lcTRTransactionStartingActionsInner.conductors);
  }

  @Override
  public int hashCode() {
    return Objects.hash(details, sourcesOfCash, conductors);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class LCTRTransactionStartingActionsInner {\n");
    sb.append("    details: ").append(toIndentedString(details)).append("\n");
    sb.append("    sourcesOfCash: ").append(toIndentedString(sourcesOfCash)).append("\n");
    sb.append("    conductors: ").append(toIndentedString(conductors)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

