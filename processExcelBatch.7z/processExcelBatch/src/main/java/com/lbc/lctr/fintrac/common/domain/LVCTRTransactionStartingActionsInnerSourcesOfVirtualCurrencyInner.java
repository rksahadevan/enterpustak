package com.lbc.lctr.fintrac.common.domain;

import java.util.Objects;

import javax.annotation.Generated;
import javax.validation.Valid;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.fasterxml.jackson.annotation.JsonValue;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * LVCTRTransactionStartingActionsInnerSourcesOfVirtualCurrencyInner
 */

@JsonTypeName("LVCTRTransaction_startingActions_inner_sourcesOfVirtualCurrency_inner")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-03-29T08:53:00.631912700-04:00[America/New_York]")
public class LVCTRTransactionStartingActionsInnerSourcesOfVirtualCurrencyInner {

  /**
   * * `1` - Person name / Nom de la personne * `2` - Entity name / Nom de l'entité 
   */
  public enum TypeCodeEnum {
    NUMBER_1(1),
    
    NUMBER_2(2);

    private Integer value;

    TypeCodeEnum(Integer value) {
      this.value = value;
    }

    @JsonValue
    public Integer getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static TypeCodeEnum fromValue(Integer value) {
      for (TypeCodeEnum b : TypeCodeEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  @JsonProperty("typeCode")
  private TypeCodeEnum typeCode;

  @JsonProperty("refId")
  private String refId;

  @JsonProperty("details")
  private LVCTRTransactionStartingActionsInnerSourcesOfVirtualCurrencyInnerDetails details;

  public LVCTRTransactionStartingActionsInnerSourcesOfVirtualCurrencyInner typeCode(TypeCodeEnum typeCode) {
    this.typeCode = typeCode;
    return this;
  }

  /**
   * * `1` - Person name / Nom de la personne * `2` - Entity name / Nom de l'entité 
   * @return typeCode
  */
  
  @Schema(name = "typeCode", description = "* `1` - Person name / Nom de la personne * `2` - Entity name / Nom de l'entité ", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public TypeCodeEnum getTypeCode() {
    return typeCode;
  }

  public void setTypeCode(TypeCodeEnum typeCode) {
    this.typeCode = typeCode;
  }

  public LVCTRTransactionStartingActionsInnerSourcesOfVirtualCurrencyInner refId(String refId) {
    this.refId = refId;
    return this;
  }

  /**
   * Get refId
   * @return refId
  */
  @Size(max = 50) 
  @Schema(name = "refId", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getRefId() {
    return refId;
  }

  public void setRefId(String refId) {
    this.refId = refId;
  }

  public LVCTRTransactionStartingActionsInnerSourcesOfVirtualCurrencyInner details(LVCTRTransactionStartingActionsInnerSourcesOfVirtualCurrencyInnerDetails details) {
    this.details = details;
    return this;
  }

  /**
   * Get details
   * @return details
  */
  @Valid 
  @Schema(name = "details", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public LVCTRTransactionStartingActionsInnerSourcesOfVirtualCurrencyInnerDetails getDetails() {
    return details;
  }

  public void setDetails(LVCTRTransactionStartingActionsInnerSourcesOfVirtualCurrencyInnerDetails details) {
    this.details = details;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    LVCTRTransactionStartingActionsInnerSourcesOfVirtualCurrencyInner lvCTRTransactionStartingActionsInnerSourcesOfVirtualCurrencyInner = (LVCTRTransactionStartingActionsInnerSourcesOfVirtualCurrencyInner) o;
    return Objects.equals(this.typeCode, lvCTRTransactionStartingActionsInnerSourcesOfVirtualCurrencyInner.typeCode) &&
        Objects.equals(this.refId, lvCTRTransactionStartingActionsInnerSourcesOfVirtualCurrencyInner.refId) &&
        Objects.equals(this.details, lvCTRTransactionStartingActionsInnerSourcesOfVirtualCurrencyInner.details);
  }

  @Override
  public int hashCode() {
    return Objects.hash(typeCode, refId, details);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class LVCTRTransactionStartingActionsInnerSourcesOfVirtualCurrencyInner {\n");
    sb.append("    typeCode: ").append(toIndentedString(typeCode)).append("\n");
    sb.append("    refId: ").append(toIndentedString(refId)).append("\n");
    sb.append("    details: ").append(toIndentedString(details)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

