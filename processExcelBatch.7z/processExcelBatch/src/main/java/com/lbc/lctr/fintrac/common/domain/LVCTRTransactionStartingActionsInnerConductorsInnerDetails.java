package com.lbc.lctr.fintrac.common.domain;

import java.util.Objects;

import javax.annotation.Generated;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.fasterxml.jackson.annotation.JsonValue;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * LVCTRTransactionStartingActionsInnerConductorsInnerDetails
 */

@JsonTypeName("LVCTRTransaction_startingActions_inner_conductors_inner_details")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-03-29T08:53:00.631912700-04:00[America/New_York]")
public class LVCTRTransactionStartingActionsInnerConductorsInnerDetails {

  @JsonProperty("clientOfReportingEntityIndicator")
  private Boolean clientOfReportingEntityIndicator;

  @JsonProperty("clientNumber")
  private String clientNumber;

  @JsonProperty("username")
  private String username;

  /**
   * * `1` - Computer/Laptop * `2` - Mobile phone / Téléphone mobile * `3` - Tablet / Tablette * `4` - Other / Autre 
   */
  public enum TypeOfDeviceCodeEnum {
    NUMBER_1(1),
    
    NUMBER_2(2),
    
    NUMBER_3(3),
    
    NUMBER_4(4);

    private Integer value;

    TypeOfDeviceCodeEnum(Integer value) {
      this.value = value;
    }

    @JsonValue
    public Integer getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static TypeOfDeviceCodeEnum fromValue(Integer value) {
      for (TypeOfDeviceCodeEnum b : TypeOfDeviceCodeEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  @JsonProperty("typeOfDeviceCode")
  private TypeOfDeviceCodeEnum typeOfDeviceCode;

  @JsonProperty("typeOfDeviceOther")
  private String typeOfDeviceOther;

  @JsonProperty("deviceIdentifierNumber")
  private String deviceIdentifierNumber;

  @JsonProperty("internetProtocolAddress")
  private String internetProtocolAddress;

  @JsonProperty("emailAddress")
  private String emailAddress;

  @JsonProperty("dateTimeOfOnlineSession")
  private String dateTimeOfOnlineSession;

  @JsonProperty("onBehalfOfIndicator")
  private Boolean onBehalfOfIndicator;

  public LVCTRTransactionStartingActionsInnerConductorsInnerDetails clientOfReportingEntityIndicator(Boolean clientOfReportingEntityIndicator) {
    this.clientOfReportingEntityIndicator = clientOfReportingEntityIndicator;
    return this;
  }

  /**
   * Get clientOfReportingEntityIndicator
   * @return clientOfReportingEntityIndicator
  */
  
  @Schema(name = "clientOfReportingEntityIndicator", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public Boolean getClientOfReportingEntityIndicator() {
    return clientOfReportingEntityIndicator;
  }

  public void setClientOfReportingEntityIndicator(Boolean clientOfReportingEntityIndicator) {
    this.clientOfReportingEntityIndicator = clientOfReportingEntityIndicator;
  }

  public LVCTRTransactionStartingActionsInnerConductorsInnerDetails clientNumber(String clientNumber) {
    this.clientNumber = clientNumber;
    return this;
  }

  /**
   * Get clientNumber
   * @return clientNumber
  */
  @Size(max = 100) 
  @Schema(name = "clientNumber", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getClientNumber() {
    return clientNumber;
  }

  public void setClientNumber(String clientNumber) {
    this.clientNumber = clientNumber;
  }

  public LVCTRTransactionStartingActionsInnerConductorsInnerDetails username(String username) {
    this.username = username;
    return this;
  }

  /**
   * Get username
   * @return username
  */
  @Size(max = 100) 
  @Schema(name = "username", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getUsername() {
    return username;
  }

  public void setUsername(String username) {
    this.username = username;
  }

  public LVCTRTransactionStartingActionsInnerConductorsInnerDetails typeOfDeviceCode(TypeOfDeviceCodeEnum typeOfDeviceCode) {
    this.typeOfDeviceCode = typeOfDeviceCode;
    return this;
  }

  /**
   * * `1` - Computer/Laptop * `2` - Mobile phone / Téléphone mobile * `3` - Tablet / Tablette * `4` - Other / Autre 
   * @return typeOfDeviceCode
  */
  
  @Schema(name = "typeOfDeviceCode", description = "* `1` - Computer/Laptop * `2` - Mobile phone / Téléphone mobile * `3` - Tablet / Tablette * `4` - Other / Autre ", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public TypeOfDeviceCodeEnum getTypeOfDeviceCode() {
    return typeOfDeviceCode;
  }

  public void setTypeOfDeviceCode(TypeOfDeviceCodeEnum typeOfDeviceCode) {
    this.typeOfDeviceCode = typeOfDeviceCode;
  }

  public LVCTRTransactionStartingActionsInnerConductorsInnerDetails typeOfDeviceOther(String typeOfDeviceOther) {
    this.typeOfDeviceOther = typeOfDeviceOther;
    return this;
  }

  /**
   * Get typeOfDeviceOther
   * @return typeOfDeviceOther
  */
  @Size(max = 200) 
  @Schema(name = "typeOfDeviceOther", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getTypeOfDeviceOther() {
    return typeOfDeviceOther;
  }

  public void setTypeOfDeviceOther(String typeOfDeviceOther) {
    this.typeOfDeviceOther = typeOfDeviceOther;
  }

  public LVCTRTransactionStartingActionsInnerConductorsInnerDetails deviceIdentifierNumber(String deviceIdentifierNumber) {
    this.deviceIdentifierNumber = deviceIdentifierNumber;
    return this;
  }

  /**
   * Get deviceIdentifierNumber
   * @return deviceIdentifierNumber
  */
  @Size(max = 200) 
  @Schema(name = "deviceIdentifierNumber", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getDeviceIdentifierNumber() {
    return deviceIdentifierNumber;
  }

  public void setDeviceIdentifierNumber(String deviceIdentifierNumber) {
    this.deviceIdentifierNumber = deviceIdentifierNumber;
  }

  public LVCTRTransactionStartingActionsInnerConductorsInnerDetails internetProtocolAddress(String internetProtocolAddress) {
    this.internetProtocolAddress = internetProtocolAddress;
    return this;
  }

  /**
   * Get internetProtocolAddress
   * @return internetProtocolAddress
  */
  @Size(max = 200) 
  @Schema(name = "internetProtocolAddress", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getInternetProtocolAddress() {
    return internetProtocolAddress;
  }

  public void setInternetProtocolAddress(String internetProtocolAddress) {
    this.internetProtocolAddress = internetProtocolAddress;
  }

  public LVCTRTransactionStartingActionsInnerConductorsInnerDetails emailAddress(String emailAddress) {
    this.emailAddress = emailAddress;
    return this;
  }

  /**
   * Get emailAddress
   * @return emailAddress
  */
  @Size(max = 200) 
  @Schema(name = "emailAddress", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getEmailAddress() {
    return emailAddress;
  }

  public void setEmailAddress(String emailAddress) {
    this.emailAddress = emailAddress;
  }

  public LVCTRTransactionStartingActionsInnerConductorsInnerDetails dateTimeOfOnlineSession(String dateTimeOfOnlineSession) {
    this.dateTimeOfOnlineSession = dateTimeOfOnlineSession;
    return this;
  }

  /**
   * Get dateTimeOfOnlineSession
   * @return dateTimeOfOnlineSession
  */
  @Pattern(regexp = "^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}[\\\\-\\\\+][0-9]{2}:[0-9]{2}$") 
  @Schema(name = "dateTimeOfOnlineSession", example = "2020-11-19T23:59:59-05:00", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getDateTimeOfOnlineSession() {
    return dateTimeOfOnlineSession;
  }

  public void setDateTimeOfOnlineSession(String dateTimeOfOnlineSession) {
    this.dateTimeOfOnlineSession = dateTimeOfOnlineSession;
  }

  public LVCTRTransactionStartingActionsInnerConductorsInnerDetails onBehalfOfIndicator(Boolean onBehalfOfIndicator) {
    this.onBehalfOfIndicator = onBehalfOfIndicator;
    return this;
  }

  /**
   * Get onBehalfOfIndicator
   * @return onBehalfOfIndicator
  */
  
  @Schema(name = "onBehalfOfIndicator", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public Boolean getOnBehalfOfIndicator() {
    return onBehalfOfIndicator;
  }

  public void setOnBehalfOfIndicator(Boolean onBehalfOfIndicator) {
    this.onBehalfOfIndicator = onBehalfOfIndicator;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    LVCTRTransactionStartingActionsInnerConductorsInnerDetails lvCTRTransactionStartingActionsInnerConductorsInnerDetails = (LVCTRTransactionStartingActionsInnerConductorsInnerDetails) o;
    return Objects.equals(this.clientOfReportingEntityIndicator, lvCTRTransactionStartingActionsInnerConductorsInnerDetails.clientOfReportingEntityIndicator) &&
        Objects.equals(this.clientNumber, lvCTRTransactionStartingActionsInnerConductorsInnerDetails.clientNumber) &&
        Objects.equals(this.username, lvCTRTransactionStartingActionsInnerConductorsInnerDetails.username) &&
        Objects.equals(this.typeOfDeviceCode, lvCTRTransactionStartingActionsInnerConductorsInnerDetails.typeOfDeviceCode) &&
        Objects.equals(this.typeOfDeviceOther, lvCTRTransactionStartingActionsInnerConductorsInnerDetails.typeOfDeviceOther) &&
        Objects.equals(this.deviceIdentifierNumber, lvCTRTransactionStartingActionsInnerConductorsInnerDetails.deviceIdentifierNumber) &&
        Objects.equals(this.internetProtocolAddress, lvCTRTransactionStartingActionsInnerConductorsInnerDetails.internetProtocolAddress) &&
        Objects.equals(this.emailAddress, lvCTRTransactionStartingActionsInnerConductorsInnerDetails.emailAddress) &&
        Objects.equals(this.dateTimeOfOnlineSession, lvCTRTransactionStartingActionsInnerConductorsInnerDetails.dateTimeOfOnlineSession) &&
        Objects.equals(this.onBehalfOfIndicator, lvCTRTransactionStartingActionsInnerConductorsInnerDetails.onBehalfOfIndicator);
  }

  @Override
  public int hashCode() {
    return Objects.hash(clientOfReportingEntityIndicator, clientNumber, username, typeOfDeviceCode, typeOfDeviceOther, deviceIdentifierNumber, internetProtocolAddress, emailAddress, dateTimeOfOnlineSession, onBehalfOfIndicator);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class LVCTRTransactionStartingActionsInnerConductorsInnerDetails {\n");
    sb.append("    clientOfReportingEntityIndicator: ").append(toIndentedString(clientOfReportingEntityIndicator)).append("\n");
    sb.append("    clientNumber: ").append(toIndentedString(clientNumber)).append("\n");
    sb.append("    username: ").append(toIndentedString(username)).append("\n");
    sb.append("    typeOfDeviceCode: ").append(toIndentedString(typeOfDeviceCode)).append("\n");
    sb.append("    typeOfDeviceOther: ").append(toIndentedString(typeOfDeviceOther)).append("\n");
    sb.append("    deviceIdentifierNumber: ").append(toIndentedString(deviceIdentifierNumber)).append("\n");
    sb.append("    internetProtocolAddress: ").append(toIndentedString(internetProtocolAddress)).append("\n");
    sb.append("    emailAddress: ").append(toIndentedString(emailAddress)).append("\n");
    sb.append("    dateTimeOfOnlineSession: ").append(toIndentedString(dateTimeOfOnlineSession)).append("\n");
    sb.append("    onBehalfOfIndicator: ").append(toIndentedString(onBehalfOfIndicator)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

