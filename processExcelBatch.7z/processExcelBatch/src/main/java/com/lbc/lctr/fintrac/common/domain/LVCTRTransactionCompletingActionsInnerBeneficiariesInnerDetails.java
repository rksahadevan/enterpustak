package com.lbc.lctr.fintrac.common.domain;

import java.util.Objects;

import javax.annotation.Generated;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * LVCTRTransactionCompletingActionsInnerBeneficiariesInnerDetails
 */

@JsonTypeName("LVCTRTransaction_completingActions_inner_beneficiaries_inner_details")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-03-29T08:53:00.631912700-04:00[America/New_York]")
public class LVCTRTransactionCompletingActionsInnerBeneficiariesInnerDetails {

  @JsonProperty("clientNumber")
  private String clientNumber;

  @JsonProperty("emailAddress")
  private String emailAddress;

  @JsonProperty("username")
  private String username;

  public LVCTRTransactionCompletingActionsInnerBeneficiariesInnerDetails clientNumber(String clientNumber) {
    this.clientNumber = clientNumber;
    return this;
  }

  /**
   * Get clientNumber
   * @return clientNumber
  */
  @Size(max = 100) 
  @Schema(name = "clientNumber", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getClientNumber() {
    return clientNumber;
  }

  public void setClientNumber(String clientNumber) {
    this.clientNumber = clientNumber;
  }

  public LVCTRTransactionCompletingActionsInnerBeneficiariesInnerDetails emailAddress(String emailAddress) {
    this.emailAddress = emailAddress;
    return this;
  }

  /**
   * Get emailAddress
   * @return emailAddress
  */
  @Size(max = 200) 
  @Schema(name = "emailAddress", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getEmailAddress() {
    return emailAddress;
  }

  public void setEmailAddress(String emailAddress) {
    this.emailAddress = emailAddress;
  }

  public LVCTRTransactionCompletingActionsInnerBeneficiariesInnerDetails username(String username) {
    this.username = username;
    return this;
  }

  /**
   * Get username
   * @return username
  */
  @Size(max = 100) 
  @Schema(name = "username", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getUsername() {
    return username;
  }

  public void setUsername(String username) {
    this.username = username;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    LVCTRTransactionCompletingActionsInnerBeneficiariesInnerDetails lvCTRTransactionCompletingActionsInnerBeneficiariesInnerDetails = (LVCTRTransactionCompletingActionsInnerBeneficiariesInnerDetails) o;
    return Objects.equals(this.clientNumber, lvCTRTransactionCompletingActionsInnerBeneficiariesInnerDetails.clientNumber) &&
        Objects.equals(this.emailAddress, lvCTRTransactionCompletingActionsInnerBeneficiariesInnerDetails.emailAddress) &&
        Objects.equals(this.username, lvCTRTransactionCompletingActionsInnerBeneficiariesInnerDetails.username);
  }

  @Override
  public int hashCode() {
    return Objects.hash(clientNumber, emailAddress, username);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class LVCTRTransactionCompletingActionsInnerBeneficiariesInnerDetails {\n");
    sb.append("    clientNumber: ").append(toIndentedString(clientNumber)).append("\n");
    sb.append("    emailAddress: ").append(toIndentedString(emailAddress)).append("\n");
    sb.append("    username: ").append(toIndentedString(username)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

