package com.lbc.lctr.fintrac.mapper;

import org.springframework.batch.extensions.excel.RowMapper;
import org.springframework.batch.extensions.excel.support.rowset.RowSet;

import com.lbc.lctr.fintrac.common.domain.LCTRReport;

public class ExcelRowMapper implements RowMapper<LCTRReport> {
 
    @Override
    public LCTRReport mapRow(RowSet rowSet) throws Exception {
    	LCTRReport lctReport = new LCTRReport();
        return lctReport;
    }
}
