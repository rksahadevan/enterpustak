package com.lbc.lctr.fintrac.common.domain;

import com.fasterxml.jackson.annotation.JsonProperty;

public abstract class Subject {
	 @JsonProperty("subjectType")
	  protected SubjectType subjectType;

	  @JsonProperty("refId")
	  protected String refId;

	public SubjectType getSubjectType() {
		return subjectType;
	}

	public void setSubjectType(SubjectType subjectType) {
		this.subjectType = subjectType;
	}

	public String getRefId() {
		return refId;
	}

	public void setRefId(String refId) {
		this.refId = refId;
	}
	
	  
	  
	  
}
