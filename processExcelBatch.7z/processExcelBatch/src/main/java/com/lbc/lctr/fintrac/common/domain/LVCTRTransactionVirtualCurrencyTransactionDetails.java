package com.lbc.lctr.fintrac.common.domain;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.annotation.Generated;
import javax.validation.Valid;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.fasterxml.jackson.annotation.JsonValue;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * LVCTRTransactionVirtualCurrencyTransactionDetails
 */

@JsonTypeName("LVCTRTransaction_virtualCurrencyTransactionDetails")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-03-29T08:53:00.631912700-04:00[America/New_York]")
public class LVCTRTransactionVirtualCurrencyTransactionDetails {

  @JsonProperty("thresholdIndicator")
  private Boolean thresholdIndicator;

  @JsonProperty("dateTimeReceived")
  private String dateTimeReceived;

  /**
   * * `1` - In person / En personne * `7` - Other / Autre * `8` - Online / En ligne * `9` - Virtual currency ATM / Guichet automatique de monnaie virtuelle 
   */
  public enum MethodCodeEnum {
    NUMBER_1(1),
    
    NUMBER_7(7),
    
    NUMBER_8(8),
    
    NUMBER_9(9);

    private Integer value;

    MethodCodeEnum(Integer value) {
      this.value = value;
    }

    @JsonValue
    public Integer getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static MethodCodeEnum fromValue(Integer value) {
      for (MethodCodeEnum b : MethodCodeEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  @JsonProperty("methodCode")
  private MethodCodeEnum methodCode;

  @JsonProperty("methodOther")
  private String methodOther;

  @JsonProperty("ids")
  @Valid
  private List<String> ids = null;

  @JsonProperty("reportingEntityTransactionReference")
  private String reportingEntityTransactionReference;

  @JsonProperty("purposeOfTransaction")
  private String purposeOfTransaction;

  public LVCTRTransactionVirtualCurrencyTransactionDetails thresholdIndicator(Boolean thresholdIndicator) {
    this.thresholdIndicator = thresholdIndicator;
    return this;
  }

  /**
   * Get thresholdIndicator
   * @return thresholdIndicator
  */
  
  @Schema(name = "thresholdIndicator", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public Boolean getThresholdIndicator() {
    return thresholdIndicator;
  }

  public void setThresholdIndicator(Boolean thresholdIndicator) {
    this.thresholdIndicator = thresholdIndicator;
  }

  public LVCTRTransactionVirtualCurrencyTransactionDetails dateTimeReceived(String dateTimeReceived) {
    this.dateTimeReceived = dateTimeReceived;
    return this;
  }

  /**
   * Get dateTimeReceived
   * @return dateTimeReceived
  */
  @Pattern(regexp = "^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}[\\\\-\\\\+][0-9]{2}:[0-9]{2}$") 
  @Schema(name = "dateTimeReceived", example = "2020-11-19T23:59:59-05:00", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getDateTimeReceived() {
    return dateTimeReceived;
  }

  public void setDateTimeReceived(String dateTimeReceived) {
    this.dateTimeReceived = dateTimeReceived;
  }

  public LVCTRTransactionVirtualCurrencyTransactionDetails methodCode(MethodCodeEnum methodCode) {
    this.methodCode = methodCode;
    return this;
  }

  /**
   * * `1` - In person / En personne * `7` - Other / Autre * `8` - Online / En ligne * `9` - Virtual currency ATM / Guichet automatique de monnaie virtuelle 
   * @return methodCode
  */
  
  @Schema(name = "methodCode", description = "* `1` - In person / En personne * `7` - Other / Autre * `8` - Online / En ligne * `9` - Virtual currency ATM / Guichet automatique de monnaie virtuelle ", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public MethodCodeEnum getMethodCode() {
    return methodCode;
  }

  public void setMethodCode(MethodCodeEnum methodCode) {
    this.methodCode = methodCode;
  }

  public LVCTRTransactionVirtualCurrencyTransactionDetails methodOther(String methodOther) {
    this.methodOther = methodOther;
    return this;
  }

  /**
   * Get methodOther
   * @return methodOther
  */
  @Size(max = 200) 
  @Schema(name = "methodOther", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getMethodOther() {
    return methodOther;
  }

  public void setMethodOther(String methodOther) {
    this.methodOther = methodOther;
  }

  public LVCTRTransactionVirtualCurrencyTransactionDetails ids(List<String> ids) {
    this.ids = ids;
    return this;
  }

  public LVCTRTransactionVirtualCurrencyTransactionDetails addIdsItem(String idsItem) {
    if (this.ids == null) {
      this.ids = new ArrayList<>();
    }
    this.ids.add(idsItem);
    return this;
  }

  /**
   * Get ids
   * @return ids
  */
  
  @Schema(name = "ids", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public List<String> getIds() {
    return ids;
  }

  public void setIds(List<String> ids) {
    this.ids = ids;
  }

  public LVCTRTransactionVirtualCurrencyTransactionDetails reportingEntityTransactionReference(String reportingEntityTransactionReference) {
    this.reportingEntityTransactionReference = reportingEntityTransactionReference;
    return this;
  }

  /**
   * Get reportingEntityTransactionReference
   * @return reportingEntityTransactionReference
  */
  @Size(max = 200) 
  @Schema(name = "reportingEntityTransactionReference", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getReportingEntityTransactionReference() {
    return reportingEntityTransactionReference;
  }

  public void setReportingEntityTransactionReference(String reportingEntityTransactionReference) {
    this.reportingEntityTransactionReference = reportingEntityTransactionReference;
  }

  public LVCTRTransactionVirtualCurrencyTransactionDetails purposeOfTransaction(String purposeOfTransaction) {
    this.purposeOfTransaction = purposeOfTransaction;
    return this;
  }

  /**
   * Get purposeOfTransaction
   * @return purposeOfTransaction
  */
  @Size(max = 200) 
  @Schema(name = "purposeOfTransaction", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getPurposeOfTransaction() {
    return purposeOfTransaction;
  }

  public void setPurposeOfTransaction(String purposeOfTransaction) {
    this.purposeOfTransaction = purposeOfTransaction;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    LVCTRTransactionVirtualCurrencyTransactionDetails lvCTRTransactionVirtualCurrencyTransactionDetails = (LVCTRTransactionVirtualCurrencyTransactionDetails) o;
    return Objects.equals(this.thresholdIndicator, lvCTRTransactionVirtualCurrencyTransactionDetails.thresholdIndicator) &&
        Objects.equals(this.dateTimeReceived, lvCTRTransactionVirtualCurrencyTransactionDetails.dateTimeReceived) &&
        Objects.equals(this.methodCode, lvCTRTransactionVirtualCurrencyTransactionDetails.methodCode) &&
        Objects.equals(this.methodOther, lvCTRTransactionVirtualCurrencyTransactionDetails.methodOther) &&
        Objects.equals(this.ids, lvCTRTransactionVirtualCurrencyTransactionDetails.ids) &&
        Objects.equals(this.reportingEntityTransactionReference, lvCTRTransactionVirtualCurrencyTransactionDetails.reportingEntityTransactionReference) &&
        Objects.equals(this.purposeOfTransaction, lvCTRTransactionVirtualCurrencyTransactionDetails.purposeOfTransaction);
  }

  @Override
  public int hashCode() {
    return Objects.hash(thresholdIndicator, dateTimeReceived, methodCode, methodOther, ids, reportingEntityTransactionReference, purposeOfTransaction);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class LVCTRTransactionVirtualCurrencyTransactionDetails {\n");
    sb.append("    thresholdIndicator: ").append(toIndentedString(thresholdIndicator)).append("\n");
    sb.append("    dateTimeReceived: ").append(toIndentedString(dateTimeReceived)).append("\n");
    sb.append("    methodCode: ").append(toIndentedString(methodCode)).append("\n");
    sb.append("    methodOther: ").append(toIndentedString(methodOther)).append("\n");
    sb.append("    ids: ").append(toIndentedString(ids)).append("\n");
    sb.append("    reportingEntityTransactionReference: ").append(toIndentedString(reportingEntityTransactionReference)).append("\n");
    sb.append("    purposeOfTransaction: ").append(toIndentedString(purposeOfTransaction)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

