package com.lbc.lctr.fintrac.common.domain;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.annotation.Generated;
import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * Report
 */

@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-03-29T08:53:00.631912700-04:00[America/New_York]")
public class LCTRReport {

  @JsonProperty("reportDetails")
  private ReportDetails reportDetails;

  @JsonProperty("definitions")
  @Valid
  private List<SubjectDefination> definitions = null;

  @JsonProperty("transactions")
  @Valid
  private List<ReportTransaction> transactions = null;

  public LCTRReport reportDetails(ReportDetails reportDetails) {
    this.reportDetails = reportDetails;
    return this;
  }

  /**
   * Get reportDetails
   * @return reportDetails
  */
  @Valid 
  @Schema(name = "reportDetails", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public ReportDetails getReportDetails() {
    return reportDetails;
  }

  public void setReportDetails(ReportDetails reportDetails) {
    this.reportDetails = reportDetails;
  }

  public LCTRReport definitions(List<SubjectDefination> definitions) {
    this.definitions = definitions;
    return this;
  }

  public LCTRReport addDefinitionsItem(SubjectDefination definitionsItem) {
    if (this.definitions == null) {
      this.definitions = new ArrayList<>();
    }
    this.definitions.add(definitionsItem);
    return this;
  }

  /**
   * Get definitions
   * @return definitions
  */
  @Valid 
  @Schema(name = "definitions", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public List<SubjectDefination> getDefinitions() {
    return definitions;
  }

  public void setDefinitions(List<SubjectDefination> definitions) {
    this.definitions = definitions;
  }

  public LCTRReport transactions(List<ReportTransaction> transactions) {
    this.transactions = transactions;
    return this;
  }

  public LCTRReport addTransactionsItem(ReportTransaction transactionsItem) {
    if (this.transactions == null) {
      this.transactions = new ArrayList<>();
    }
    this.transactions.add(transactionsItem);
    return this;
  }

  /**
   * Get transactions
   * @return transactions
  */
  @Valid 
  @Schema(name = "transactions", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public List<ReportTransaction> getTransactions() {
    return transactions;
  }

  public void setTransactions(List<ReportTransaction> transactions) {
    this.transactions = transactions;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    LCTRReport report = (LCTRReport) o;
    return Objects.equals(this.reportDetails, report.reportDetails) &&
        Objects.equals(this.definitions, report.definitions) &&
        Objects.equals(this.transactions, report.transactions);
  }

  @Override
  public int hashCode() {
    return Objects.hash(reportDetails, definitions, transactions);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Report {\n");
    sb.append("    reportDetails: ").append(toIndentedString(reportDetails)).append("\n");
    sb.append("    definitions: ").append(toIndentedString(definitions)).append("\n");
    sb.append("    transactions: ").append(toIndentedString(transactions)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

