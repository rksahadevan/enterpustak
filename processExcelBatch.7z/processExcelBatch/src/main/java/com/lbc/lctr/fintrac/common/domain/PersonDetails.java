package com.lbc.lctr.fintrac.common.domain;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.annotation.Generated;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonValue;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * PersonDetails
 */

@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-03-29T08:53:00.631912700-04:00[America/New_York]")
@JsonTypeInfo(use=JsonTypeInfo.Id.CLASS, include=JsonTypeInfo.As.PROPERTY, property="@class")
public class PersonDetails implements SubjectDefination {




  @JsonProperty("refId")
  private String refId;

  @JsonProperty("givenName")
  private String givenName;

  @JsonProperty("surname")
  private String surname;

  @JsonProperty("otherNameInitial")
  private String otherNameInitial;

  @JsonProperty("alias")
  private String alias;

  @JsonProperty("telephoneNumber")
  private String telephoneNumber;

  @JsonProperty("extensionNumber")
  private String extensionNumber;

  @JsonProperty("dateOfBirth")
  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
  private LocalDate dateOfBirth;

  @JsonProperty("countryOfResidenceCode")
  private CountryCode countryOfResidenceCode;

  @JsonProperty("occupation")
  private String occupation;

  @JsonProperty("nameOfEmployer")
  private String nameOfEmployer;
  
  @JsonProperty("subjectType")
  private SubjectType subjectType = SubjectType.PERSON;

  
  public SubjectType getSubjectType() {
	return subjectType;
}

  public void setSubjectType(SubjectType subjectType) {
	this.subjectType = subjectType;
  }

  /**
   * * `1` - Structured address / Adresse structurée * `2` - Unstructured address / Adresse non structurée 
   */
  public enum AddressTypeCodeEnum {
    NUMBER_1(1),
    
    NUMBER_2(2);

    private Integer value;

    AddressTypeCodeEnum(Integer value) {
      this.value = value;
    }

    @JsonValue
    public Integer getValue() {
      return value;
    }

    @Override
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static AddressTypeCodeEnum fromValue(Integer value) {
      for (AddressTypeCodeEnum b : AddressTypeCodeEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  @JsonProperty("addressTypeCode")
  private AddressTypeCodeEnum addressTypeCode;

  @JsonProperty("address")
  private PersonDetailsAddress address;

  @JsonProperty("identifications")
  @Valid
  private List<PersonDetailsIdentificationsInner> identifications = null;




  public PersonDetails refId(String refId) {
    this.refId = refId;
    return this;
  }

  /**
   * Get refId
   * @return refId
  */
  @NotNull @Size(max = 50) 
  @Schema(name = "refId", requiredMode = Schema.RequiredMode.REQUIRED)
  public String getRefId() {
    return refId;
  }

  public void setRefId(String refId) {
    this.refId = refId;
  }

  public PersonDetails givenName(String givenName) {
    this.givenName = givenName;
    return this;
  }

  /**
   * Get givenName
   * @return givenName
  */
  @Size(max = 100) 
  @Schema(name = "givenName", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getGivenName() {
    return givenName;
  }

  public void setGivenName(String givenName) {
    this.givenName = givenName;
  }

  public PersonDetails surname(String surname) {
    this.surname = surname;
    return this;
  }

  /**
   * Get surname
   * @return surname
  */
  @Size(max = 100) 
  @Schema(name = "surname", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getSurname() {
    return surname;
  }

  public void setSurname(String surname) {
    this.surname = surname;
  }

  public PersonDetails otherNameInitial(String otherNameInitial) {
    this.otherNameInitial = otherNameInitial;
    return this;
  }

  /**
   * Get otherNameInitial
   * @return otherNameInitial
  */
  @Size(max = 100) 
  @Schema(name = "otherNameInitial", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getOtherNameInitial() {
    return otherNameInitial;
  }

  public void setOtherNameInitial(String otherNameInitial) {
    this.otherNameInitial = otherNameInitial;
  }

  public PersonDetails alias(String alias) {
    this.alias = alias;
    return this;
  }

  /**
   * Get alias
   * @return alias
  */
  @Size(max = 100) 
  @Schema(name = "alias", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getAlias() {
    return alias;
  }

  public void setAlias(String alias) {
    this.alias = alias;
  }

  public PersonDetails telephoneNumber(String telephoneNumber) {
    this.telephoneNumber = telephoneNumber;
    return this;
  }

  /**
   * Get telephoneNumber
   * @return telephoneNumber
  */
  @Size(max = 20) 
  @Schema(name = "telephoneNumber", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getTelephoneNumber() {
    return telephoneNumber;
  }

  public void setTelephoneNumber(String telephoneNumber) {
    this.telephoneNumber = telephoneNumber;
  }

  public PersonDetails extensionNumber(String extensionNumber) {
    this.extensionNumber = extensionNumber;
    return this;
  }

  /**
   * Get extensionNumber
   * @return extensionNumber
  */
  @Size(max = 10) 
  @Schema(name = "extensionNumber", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getExtensionNumber() {
    return extensionNumber;
  }

  public void setExtensionNumber(String extensionNumber) {
    this.extensionNumber = extensionNumber;
  }

  public PersonDetails dateOfBirth(LocalDate dateOfBirth) {
    this.dateOfBirth = dateOfBirth;
    return this;
  }

  /**
   * Get dateOfBirth
   * @return dateOfBirth
  */
  @Valid 
  @Schema(name = "dateOfBirth", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public LocalDate getDateOfBirth() {
    return dateOfBirth;
  }

  public void setDateOfBirth(LocalDate dateOfBirth) {
    this.dateOfBirth = dateOfBirth;
  }

  public PersonDetails countryOfResidenceCode(CountryCode countryOfResidenceCode) {
    this.countryOfResidenceCode = countryOfResidenceCode;
    return this;
  }

  /**
   * Get countryOfResidenceCode
   * @return countryOfResidenceCode
  */
  @Valid 
  @Schema(name = "countryOfResidenceCode", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public CountryCode getCountryOfResidenceCode() {
    return countryOfResidenceCode;
  }

  public void setCountryOfResidenceCode(CountryCode countryOfResidenceCode) {
    this.countryOfResidenceCode = countryOfResidenceCode;
  }

  public PersonDetails occupation(String occupation) {
    this.occupation = occupation;
    return this;
  }

  /**
   * Get occupation
   * @return occupation
  */
  @Size(max = 200) 
  @Schema(name = "occupation", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getOccupation() {
    return occupation;
  }

  public void setOccupation(String occupation) {
    this.occupation = occupation;
  }

  public PersonDetails nameOfEmployer(String nameOfEmployer) {
    this.nameOfEmployer = nameOfEmployer;
    return this;
  }

  /**
   * Get nameOfEmployer
   * @return nameOfEmployer
  */
  @Size(max = 100) 
  @Schema(name = "nameOfEmployer", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getNameOfEmployer() {
    return nameOfEmployer;
  }

  public void setNameOfEmployer(String nameOfEmployer) {
    this.nameOfEmployer = nameOfEmployer;
  }

  public PersonDetails addressTypeCode(AddressTypeCodeEnum addressTypeCode) {
    this.addressTypeCode = addressTypeCode;
    return this;
  }

  /**
   * * `1` - Structured address / Adresse structurée * `2` - Unstructured address / Adresse non structurée 
   * @return addressTypeCode
  */
  
  @Schema(name = "addressTypeCode", description = "* `1` - Structured address / Adresse structurée * `2` - Unstructured address / Adresse non structurée ", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public AddressTypeCodeEnum getAddressTypeCode() {
    return addressTypeCode;
  }

  public void setAddressTypeCode(AddressTypeCodeEnum addressTypeCode) {
    this.addressTypeCode = addressTypeCode;
  }

  public PersonDetails address(PersonDetailsAddress address) {
    this.address = address;
    return this;
  }

  /**
   * Get address
   * @return address
  */
  @Valid 
  @Schema(name = "address", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public PersonDetailsAddress getAddress() {
    return address;
  }

  public void setAddress(PersonDetailsAddress address) {
    this.address = address;
  }

  public PersonDetails identifications(List<PersonDetailsIdentificationsInner> identifications) {
    this.identifications = identifications;
    return this;
  }

  public PersonDetails addIdentificationsItem(PersonDetailsIdentificationsInner identificationsItem) {
    if (this.identifications == null) {
      this.identifications = new ArrayList<>();
    }
    this.identifications.add(identificationsItem);
    return this;
  }

  /**
   * Get identifications
   * @return identifications
  */
  @Valid 
  @Schema(name = "identifications", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public List<PersonDetailsIdentificationsInner> getIdentifications() {
    return identifications;
  }

  public void setIdentifications(List<PersonDetailsIdentificationsInner> identifications) {
    this.identifications = identifications;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PersonDetails personDetails = (PersonDetails) o;
    return Objects.equals(this.subjectType, personDetails.subjectType) &&
        Objects.equals(this.refId, personDetails.refId) &&
        Objects.equals(this.givenName, personDetails.givenName) &&
        Objects.equals(this.surname, personDetails.surname) &&
        Objects.equals(this.otherNameInitial, personDetails.otherNameInitial) &&
        Objects.equals(this.alias, personDetails.alias) &&
        Objects.equals(this.telephoneNumber, personDetails.telephoneNumber) &&
        Objects.equals(this.extensionNumber, personDetails.extensionNumber) &&
        Objects.equals(this.dateOfBirth, personDetails.dateOfBirth) &&
        Objects.equals(this.countryOfResidenceCode, personDetails.countryOfResidenceCode) &&
        Objects.equals(this.occupation, personDetails.occupation) &&
        Objects.equals(this.nameOfEmployer, personDetails.nameOfEmployer) &&
        Objects.equals(this.addressTypeCode, personDetails.addressTypeCode) &&
        Objects.equals(this.address, personDetails.address) &&
        Objects.equals(this.identifications, personDetails.identifications);
  }

  @Override
  public int hashCode() {
    return Objects.hash(subjectType, refId, givenName, surname, otherNameInitial, alias, telephoneNumber, extensionNumber, dateOfBirth, countryOfResidenceCode, occupation, nameOfEmployer, addressTypeCode, address, identifications);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PersonDetails {\n");
    sb.append("    typeCode: ").append(toIndentedString(subjectType)).append("\n");
    sb.append("    refId: ").append(toIndentedString(refId)).append("\n");
    sb.append("    givenName: ").append(toIndentedString(givenName)).append("\n");
    sb.append("    surname: ").append(toIndentedString(surname)).append("\n");
    sb.append("    otherNameInitial: ").append(toIndentedString(otherNameInitial)).append("\n");
    sb.append("    alias: ").append(toIndentedString(alias)).append("\n");
    sb.append("    telephoneNumber: ").append(toIndentedString(telephoneNumber)).append("\n");
    sb.append("    extensionNumber: ").append(toIndentedString(extensionNumber)).append("\n");
    sb.append("    dateOfBirth: ").append(toIndentedString(dateOfBirth)).append("\n");
    sb.append("    countryOfResidenceCode: ").append(toIndentedString(countryOfResidenceCode)).append("\n");
    sb.append("    occupation: ").append(toIndentedString(occupation)).append("\n");
    sb.append("    nameOfEmployer: ").append(toIndentedString(nameOfEmployer)).append("\n");
    sb.append("    addressTypeCode: ").append(toIndentedString(addressTypeCode)).append("\n");
    sb.append("    address: ").append(toIndentedString(address)).append("\n");
    sb.append("    identifications: ").append(toIndentedString(identifications)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

