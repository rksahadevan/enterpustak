package com.lbc.lctr.fintrac.common.domain;

import java.util.Objects;

import javax.annotation.Generated;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * ReportListResponsePayloadContentsInner
 */

@JsonTypeName("ReportListResponse_payload_contents_inner")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-03-29T08:53:00.631912700-04:00[America/New_York]")
public class ReportListResponsePayloadContentsInner {

  @JsonProperty("externalReportUuid")
  private String externalReportUuid;

  @JsonProperty("reportingEntityReportReference")
  private String reportingEntityReportReference;

  @JsonProperty("createDateTime")
  private String createDateTime;

  @JsonProperty("updateDateTime")
  private String updateDateTime;

  public ReportListResponsePayloadContentsInner externalReportUuid(String externalReportUuid) {
    this.externalReportUuid = externalReportUuid;
    return this;
  }

  /**
   * Get externalReportUuid
   * @return externalReportUuid
  */
  
  @Schema(name = "externalReportUuid", example = "0aaa0a0000000000900a0a0a00000a00", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getExternalReportUuid() {
    return externalReportUuid;
  }

  public void setExternalReportUuid(String externalReportUuid) {
    this.externalReportUuid = externalReportUuid;
  }

  public ReportListResponsePayloadContentsInner reportingEntityReportReference(String reportingEntityReportReference) {
    this.reportingEntityReportReference = reportingEntityReportReference;
    return this;
  }

  /**
   * Get reportingEntityReportReference
   * @return reportingEntityReportReference
  */
  
  @Schema(name = "reportingEntityReportReference", example = "00000000-aAAaaaA_00000", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getReportingEntityReportReference() {
    return reportingEntityReportReference;
  }

  public void setReportingEntityReportReference(String reportingEntityReportReference) {
    this.reportingEntityReportReference = reportingEntityReportReference;
  }

  public ReportListResponsePayloadContentsInner createDateTime(String createDateTime) {
    this.createDateTime = createDateTime;
    return this;
  }

  /**
   * Get createDateTime
   * @return createDateTime
  */
  
  @Schema(name = "createDateTime", example = "2023-02-08T16:26:53.837Z", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getCreateDateTime() {
    return createDateTime;
  }

  public void setCreateDateTime(String createDateTime) {
    this.createDateTime = createDateTime;
  }

  public ReportListResponsePayloadContentsInner updateDateTime(String updateDateTime) {
    this.updateDateTime = updateDateTime;
    return this;
  }

  /**
   * Get updateDateTime
   * @return updateDateTime
  */
  
  @Schema(name = "updateDateTime", example = "2023-02-08T16:26:53.837Z", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getUpdateDateTime() {
    return updateDateTime;
  }

  public void setUpdateDateTime(String updateDateTime) {
    this.updateDateTime = updateDateTime;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ReportListResponsePayloadContentsInner reportListResponsePayloadContentsInner = (ReportListResponsePayloadContentsInner) o;
    return Objects.equals(this.externalReportUuid, reportListResponsePayloadContentsInner.externalReportUuid) &&
        Objects.equals(this.reportingEntityReportReference, reportListResponsePayloadContentsInner.reportingEntityReportReference) &&
        Objects.equals(this.createDateTime, reportListResponsePayloadContentsInner.createDateTime) &&
        Objects.equals(this.updateDateTime, reportListResponsePayloadContentsInner.updateDateTime);
  }

  @Override
  public int hashCode() {
    return Objects.hash(externalReportUuid, reportingEntityReportReference, createDateTime, updateDateTime);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ReportListResponsePayloadContentsInner {\n");
    sb.append("    externalReportUuid: ").append(toIndentedString(externalReportUuid)).append("\n");
    sb.append("    reportingEntityReportReference: ").append(toIndentedString(reportingEntityReportReference)).append("\n");
    sb.append("    createDateTime: ").append(toIndentedString(createDateTime)).append("\n");
    sb.append("    updateDateTime: ").append(toIndentedString(updateDateTime)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

