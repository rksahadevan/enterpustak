package com.lbc.lctr.fintrac.common.domain;

public enum SubjectRole {
	
	CONDUCTOR,
	BENEFICIERY,
	SOURCEOFCASH,
	INVVOLVER,
	ACCOUNT_HOLDER,
	ONBEHALF;

}
