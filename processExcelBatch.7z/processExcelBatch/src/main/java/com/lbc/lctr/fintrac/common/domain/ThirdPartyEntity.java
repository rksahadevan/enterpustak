package com.lbc.lctr.fintrac.common.domain;

import java.util.Objects;

import javax.annotation.Generated;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * EntityName
 */

@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2023-03-29T08:53:00.631912700-04:00[America/New_York]")
@JsonTypeInfo(use=JsonTypeInfo.Id.CLASS, include=JsonTypeInfo.As.PROPERTY, property="@class")

public class ThirdPartyEntity implements SubjectDefination {


  @JsonProperty("refId")
  private String refId;

  @JsonProperty("nameOfEntity")
  private String nameOfEntity;

  @JsonProperty("subjectType")
  private SubjectType subjectType = SubjectType.THIRD_PARTY_ENTITTY;

  
  public SubjectType getSubjectType() {
	return subjectType;
}

  public void setSubjectType(SubjectType subjectType) {
	this.subjectType = subjectType;
  }


 
  public ThirdPartyEntity refId(String refId) {
    this.refId = refId;
    return this;
  }

  /**
   * Get refId
   * @return refId
  */
  @NotNull @Size(max = 50) 
  @Schema(name = "refId", requiredMode = Schema.RequiredMode.REQUIRED)
  public String getRefId() {
    return refId;
  }

  public void setRefId(String refId) {
    this.refId = refId;
  }

  public ThirdPartyEntity nameOfEntity(String nameOfEntity) {
    this.nameOfEntity = nameOfEntity;
    return this;
  }

  /**
   * Get nameOfEntity
   * @return nameOfEntity
  */
  @Size(max = 100) 
  @Schema(name = "nameOfEntity", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  public String getNameOfEntity() {
    return nameOfEntity;
  }

  public void setNameOfEntity(String nameOfEntity) {
    this.nameOfEntity = nameOfEntity;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ThirdPartyEntity entityName = (ThirdPartyEntity) o;
    return Objects.equals(this.subjectType, entityName.subjectType) &&
        Objects.equals(this.refId, entityName.refId) &&
        Objects.equals(this.nameOfEntity, entityName.nameOfEntity);
  }

  @Override
  public int hashCode() {
    return Objects.hash(subjectType, refId, nameOfEntity);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class EntityName {\n");
    sb.append("    typeCode: ").append(toIndentedString(subjectType)).append("\n");
    sb.append("    refId: ").append(toIndentedString(refId)).append("\n");
    sb.append("    nameOfEntity: ").append(toIndentedString(nameOfEntity)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

