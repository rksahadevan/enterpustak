package com.lbc.lctr.fintrac.processor;

import org.springframework.batch.item.ItemProcessor;

import com.lbc.lctr.fintrac.common.domain.LCTRReport;

public class ExcelProcessor implements ItemProcessor<LCTRReport, LCTRReport>{

	@Override
	public LCTRReport process(LCTRReport item) throws Exception {
		// TODO Auto-generated method stub
		return item;
	}

}
