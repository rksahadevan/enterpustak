# CiviCRM Developer Guide

-   [Read published version](http://docs.civicrm.org/dev/en/master)
-   [Learn how to edit](https://docs.civicrm.org/dev/en/master/documentation/#how-to-edit)
