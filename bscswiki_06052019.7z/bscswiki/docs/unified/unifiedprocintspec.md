# Unified Inquiry Procedure Interface specification

Detailed specification for each of the interfaces listed below. Definition for the common attributes also provided for the understanding.

### Procedure: HEADER_INFO

Input Parameters:

|    Argument   Name      | Description                                                                                                                                                                                                                                         |
|-------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|    p_Account_ID         | Valid CBCM Account ID. For BIAB, it has to be in the format AccountID-AccountNumber                                                                                                                                                                                                                                                     |
|    p_InvoiceNumber      | This is optional, refer to invoice number without any prefix values                                                                                                                                                                                                                                                    |
|    p_BillDate           | Invoice month in "MMYYYY" format. If no values passed or current month month, it Will be considered as unbilled inquiry   |
|    p_DetailsFLag        |                                                                                                                                                                                                                                                     |
|    p_CallDetailsFlag    |                                                                                                                                                                                                                                                     |
|    p_requestSytem       | Indicates the client system who requested the information.  Eg: CIM, DIGITALAPP, DIWAN                                                                                                                                                                                                                                                     |
|    p_parameter          | Additional instruction to the procedure for a special action. Eg: reqAttribute, UsageFormat                                                                                                                                                                                                                                      |
|    p_parameter_value    | White listed Parameter Values<br>a) lastPayment <br>b) deliveryMode <br>c) INVOICE_HISTORY <br>d) OPEN_INV_COUNT (Applicable only for Unbilled Inquiry)<br>e) AmountOnly (Applicable for Details Info)    |

### Procedure: SUMMARY_INFO

Input Parameters:

|    Argument   Name      | Description                                                                                                    |
|-------------------------|----------------------------------------------------------------------------------------------------------------|
|    p_Account_ID         | Valid CBCM Account ID. For BIAB, it has to be in the format AccountID-AccountNumber                                                                                                               |
|    p_InvoiceNumber      | This is optional, refer to invoice number without any prefix values                                                                                                               |
|    p_BillDate           | Invoice month in "MMYYYY" format. Will be considered as unbilled inquiry if no values passed or current month month                                                                                                       |
|    p_DetailsFLag        |                                                                                                                |
|    p_CallDetailsFlag    |                                                                                                                |
|    p_requestSytem       |                                                                                                                |
|    p_parameter          | ‘reqAttribute’                                                                                                 |
|    p_parameter_value    | Attributes   can be added using  ‘|’ delimiter.   Whitelisted   Parameter Values   a)       INVOICE_HISTORY    |

Output parameters:

|    Argument   Name          | Legacy   Mapping                                                                                   |    Description                                                                                    |
|-----------------------------|----------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------|
|    Cursor: AcctbalInqDetails        |                                                                                                    |                                                                                                   |
|    INVOICE_NUMBER           |                                                                                                    |                                                                                                   |
|    INVOICE_DATE             |                                                                                                    |                                                                                                   |
|    OpeningBalance           | OPENING_BALANCE                                                                                    |    Unbilled-PREVBALANCE   Billed- (Inquiry Month -1) fetch PREV Balance   CUSTOMER_ALL_HISTORY    |
|    TotalUsageAmount         | USAGE_AMOUNT                                                                                       |                                                                                                   |
|    TotalRentalAmount        | RECURRING_AMOUNT                                                                                   |                                                                                                   |
|    PlanRentalAmount         |                                                                                                    |    Total   Rental amount is addition of Plan Rental and add-on Rental                             |
|    AddonRentalAmount        |                                                                                                    |    Total   Rental amount is addition of Plan Rental and add-on Rental                             |
|    PlanDiscountAmount       |                                                                                                    |    Plan   Discount Amount. Plan Rental amount will be after discount.                             |
|    TotalOneTimeCharges      | ONE_TIME_CHARGE_   AMOUNT                                                                          |                                                                                                   |
|    TotalDiscountAmount      |                                                                                                    |                                                                                                   |
|    TotalPaymentAmount       | PAYMENT_AMOUNT                                                                                     |                                                                                                   |
|    TotalAdjustmnetAmount    | ADJUSTMENT_AMOUNT                                                                                  |    Data Products discount is added part of this.                                                  |
|    TotalTaxAmount           | Vat   Amount TOT_ROAM_DUR_HHMMSS   (Status|   INVOICE_DATE |Account_Name|Delivery ID|TAX Amount    |    Total VAT amount for all charges in the bill                                                   |


### Procedure: DETAILS INFO

Input Parameters:

|    Argument   Name      | Description    |
|-------------------------|----------------|
|    p_Account_ID         | Valid CBCM Account ID. For BIAB, it has to be in the format AccountID-AccountNumber               |
|    p_InvoiceNumber      | This is optional, refer to invoice number without any prefix values               |
|    p_BillDate           | Invoice month in "MMYYYY" format. Will be considered as unbilled inquiry if no values passed or current month month       |
|    p_DetailsFLag        |                |
|    p_CallDetailsFlag    |                |
|    p_requestSytem       |                |
|    p_parameter          | USAGEFORMAT    |
|    p_parameter_value    | AMOUNTONLY     |

Output parameters:

|    Argument   Name                      |    Required   / Optional                                   | Description                                                                             |
|-----------------------------------------|------------------------------------------------------------|-----------------------------------------------------------------------------------------|
|           ACCTTRANSACTIONLISTDETAILS    |    TYPE ACCTTRANSACTIONLIST IS TABLE OF ACCTTRANSACTION    |                                                                                         |
|    SERVICEDESC                          |                                                            | Rate plan Description                                                                   |
|    SERVICECODE                          |                                                            | SNCODE                                                                                  |
|    FROMDATE                             |                                                            | Transaction   From Date. For “ONETIME” transactions this is same as Transaction Date    |
|    TODATE                               |                                                            | This is applicable only for recurring transactions                                      |
|    TRANSACTION_TYPE                     |                                                            | PAYMENT   RECURRING   ONETIME   IMMEDIATE   ONEOFF   DISCOUNT   TAX                     |
|    TRANSACTION_DATE                     |                                                            | TRANSACTIONDATE                                                                         |
|    PACKAGEIDDESC                        |                                                            | DISCOUNT   PACK                                                                         |
|    TRANSACTIONMODE                      |                                                            | PAYMENTMODE/   PLAN/   ADDON                                                            |
|    TAXAPPLIEDCHARGE                     |                                                            | TAX APPLIED CHARGE                                                                      |
|    AMOUNT                               |                                                            | AMOUNT                                                                                  |
|    REMARKS                              |                                                            | ADDITIONALINFO                                                                          |
|    ACCTUSGSUMRYLISTDETAILS              |    TYPE ACCTUSGSUMRYLIST   IS TABLE OF ACCTUSGSUMRY        |                                                                                         |
|    MAINGROUP_NAME                       |                                                            |                                                                                         |
|    SUBGROUP_NAME                        |                                                            |                                                                                         |
|    DESCRIPTION                          |                                                            | Description to be displayed for Main group and Subgroup                                 |
|    AMOUNT                               |                                                            |                                                                                         |
|    CHARGEDUNITS                         |                                                            |                                                                                         |
|    CHARGEDTYPE                          |                                                            |                                                                                         |
|    REMARKS                              |                                                            |                                                                                         |
|    MAIN OBJECT TYPE                     |    T_BSCS_UI_DETAILS                                       |                                                                                         |
|    ACCOUNT_ID                           |                                                            |                                                                                         |
|    INVOICE_NUMBER                       |                                                            |                                                                                         |
|    CUSTOMER_ID_LIST                     |                                                            |                                                                                         |
|    ACCTTRANSACTIONLISTDETAILS           |                                                            |                                                                                         |
|    ACCTUSGSUMRYLISTDETAILS              |                                                            |                                                                                         |

### Procedure: FUP_INFO

Input parameters:

|    Argument   Name      | Description    |
|-------------------------|----------------|
|    p_Account_ID         | Valid CBCM Account ID. For BIAB, it has to be in the format AccountID-AccountNumber               |
|    p_BillDate           | Optional.  This is not relevant for this inquiry as result will be always for current month       |
|    p_Fup_Shdes          |                |
|    p_DetailsFLag        |                |
|    p_CallDetailsFlag    |                |
|    p_requestSytem       |                |
|    p_parameter          |                |
|    p_parameter_value    |                |

Output parameters:

|    Argument   Name         | Description                                  |
|----------------------------|----------------------------------------------|
|    AcctPackLevelDetails    |                                              |
|    Package_Name            | Free unit Pack Name.    Example “IDD”        |
|    FreeUnits               | Subscribed   Free units in Minutes.          |
|    Consumed_Units          | Consumed   Free units in Minutes             |
|    LeftOutUnits            | Left   out free unit in Minutes.             |

### Procedure: CALL_DETAILS

Input parameters:

|    Argument   Name      | Description                                                                             |
|-------------------------|-----------------------------------------------------------------------------------------|
|    p_Account_ID         | Valid CBCM Account ID. For BIAB, it has to be in the format AccountID-AccountNumber    |
|    p_InvoiceNumber      |                                                                                         |
|    p_BillDate           | Invoice month in "MMYYYY" format. Will be considered as unbilled inquiry if no values passed or current month month                                                                                |
|    p_DetailsFLag        |                                                                                         |
|    p_startDate          | DDMMYYY, If start date   available end date is mandatory                                |
|    p_endDate            | DDMMYYYY. Priority of start   and end date always go over Bill Date                     |
|    p_CallDetailsFlag    |                                                                                         |
|    p_requestSytem       |                                                                                         |
|    p_parameter          |                                                                                         |
|    p_parameter_value    |                                                                                         |
|    p_pagesize           | Total   number of records for each page                                                 |
|    p_index              | Paginated row offset to calculate                                                       |
|    p_mainGroup          | Optional, Pass usage main group name, in case details required only for this scenario                    |
|    P_subGroup           | Optional, Pass usage sub group name, in case details required only for this scenario                                                               |

Output parameters:

|    Argument   Name                                                   |    Data   Type                              |    Description                                                     |
|----------------------------------------------------------------------|---------------------------------------------|--------------------------------------------------------------------|
|    AcctCallDetails                                                   |    CALL_DETAILS_REC   Oracle Object Type    |    Table of T_BSCS_UI_USAGE                                        |
|    MAINGROUP_NAME                                                    |    String                                   |    Main group name need to decode by client                        |
|    SUBGROUP_NAME                                                     |    String                                   |    Subgroup   name need to decode by client                        |
|    A_PARTY_NUMBER                                                    |    String                                   |    Calling   Number                                                |
|    B_PARTY_NUMBER                                                    |    String                                   |    Called   Number                                                 |
|    CALL_DATE                                                         |    Date                                     |                                                                    |
|    CALL_DURATION                                                     |    String                                   |                                                                    |
|    DURATION_UNITS                                                    |    String                                   |    Time   in seconds(00:00:00) or Data in KB                       |
|    DEST_COUNTRY                                                      |    String                                   |                                                                    |
|    ROAMINGCOUNTRY                                                    |    String                                   |                                                                    |
|    OPERATOR_DESC                                                     |    String                                   |                                                                    |
|    AMOUNT                                                            |    Decimal                                  |                                                                    |
|    REMARKS                                                           |    String                                   |                                                                    |
|    SERVICE                                                           |    String                                   |                                                                    |
|    MAIN OBJECT                             T_BSCS_UI_CALL_DETAILS    |                                             |                                                                    |
|    TOTAL_RECORDS                                                     |    Number                                   |    Total   Number of records. This varies based on online calls    |
|    LAST_PAGE_FLAG                                                    |    String                                   |    ‘Y’   or ‘N’                                                    |

### Procedure: BULK_BALANCE_INQUIRY

Input parameters:

|    Argument Name          |    Required    /    Optional                                                                                                                                                                   |    Data Type      |    Description                                                                                                                                                                                                                                                           |                       |                                                                                                                                                                                                |
|---------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|    P_LINKEDACCOUNTLIST    |    R                                                                                                                                                                                           |    COLLECTION     |    COLLECTION   OF ACCOUNTID                                                                                                                                                                                                                                             |                       |                                                                                                                                                                                                |
|    P_REQUESTSYTEM         |    O                                                                                                                                                                                           |    STRING         |                                                                                                                                                                                                                                                                          |                       |                                                                                                                                                                                                |
|    P_PARAMETER            |    O                                                                                                                                                                                           |    STRING         |                                                                                                                                                                                                                                                                          |                       |                                                                                                                                                                                                |
|    P_PARAMETER_VALUE      |    O                                                                                                                                                                                           |    STRING         |    Valid   inputs:                             RESP=OSONLY          Procedure will return value only     below for below output attributes:     ·             AMOUNTDUE     ·             BILLEDAMT      Other account level attributes will     be NULL                 |      RESP=OSONLY      |      Procedure will return value only     below for below output attributes:     ·             AMOUNTDUE     ·             BILLEDAMT      Other account level attributes will     be NULL      |
|      RESP=OSONLY          |      Procedure will return value only     below for below output attributes:     ·             AMOUNTDUE     ·             BILLEDAMT      Other account level attributes will     be NULL      |                   |                                                                                                                                                                                                                                                                          |                       |                                                                                                                                                                                                |

Output parameters:

|    Argument Name             | Description                                                                                             |
|------------------------------|---------------------------------------------------------------------------------------------------------|
|    P_LINKEDACCOUNTBALANCE    |                                                                                                         |
|    ACCOUNT_ID                | This refers to the account Id in CBCM.                                                                  |
|     AMOUNTDUE                | This is the total Outstanding of each   account.                                                        |
|    BILLEDAMT                 | This   billed amount of previous month. Payable amount of    CBCM                                       |
|    TOTALBILLEDAMTDUE         | Previous Billed Total Amount Due. Closing balance of CBCM                                               |
|    P_ERR_CODE                | Each account Level Error Code                                                                           |
|    P_ERR_MSG                 | Each account Level Error    Message                                                                     |
|    MAINOBJECTTYPE            |                                                                                                         |
|    P_LINKEDACCOUNTBALANCE    |                                                                                                         |
|    P_AGGREGATEDAMOUNT        | Aggregated amount of all accounts ‘AmountDue’.                                                          |
|    P_PAYABLEAMOUNT           | Aggregated amount for all accounts with positive   ‘AmountDue’;  –ve balances will not be considered    |

!!! Info "Procedure response codes and messages"

    Below are the standards response codes and messages from unified inquiry procedures.  Response code 200 considered as success response, and others are failures

    | CODE | Type                    | Description                                                                                           |
    |------|-------------------------|-------------------------------------------------------------------------------------------------------|
    | 200  | OK                      | Success                                                                                               |
    | 400  | Bad Request             | The request could not be understood by the server due to invalid input                              |
    | 404  | Not Found               | The server has not found anything matching the Request                                              |
    | 500  | Internal Server Error   | The server encountered an unexpected condition which prevented it from fulfilling   the request.    |
    | 604  |                         | ACCOUNT_ID   not Payment Responsible, hence invoice will not be available                             |

### UnbilledRental API

Input parameters:

|    Argument   Name    | Description                                    |
|-----------------------|------------------------------------------------|
|    CUSTNUM            | CBCM   Account ID                              |
|    DETAILS            | TRUE/FALSE –Always   returns full list.        |

Output parameters:

|    Argument   Name      | Description                                                                                                                                                       |
|-------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|    SERVICELIST          |                                                                                                                                                                   |
|    PRICE                | Unit Price                                                                                                                                                        |
|    SERVICE_DESC         | Service   description                                                                                                                                             |
|    VALID_FROM_DATE      | Valid   from date                                                                                                                                                 |
|    VALID_TILL_DATE      | Valid   till date                                                                                                                                                 |
|    QUANTITY             | Quantity                                                                                                                                                          |
|    BILLING_FREQUENCY    | Billing   Frequency                                                                                                                                               |
|    MAINOBJECT           |                                                                                                                                                                   |
|    TOTAL_RENTAL         | Total Rental Amount of all subscribed services multiplied   by quantity. No pro-rate will be applied. Rate Matrix and OCC approach Rental   are also included.    |
