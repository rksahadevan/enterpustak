/*
To test DB package BILL_ENQUIRY.UNBILLED_RENTAL

Parameters:
a) CO_ID

Example:
sqlplus BILL_ENQUIRY/password@BSCSR2U2 @UNBILLED_RENTAL_TestScript.sql SA-702393487

*/
SET SERVEROUTPUT ON SIZE 99999
set linesize 200
DECLARE
  P_CO_CODE        VARCHAR2(12);
  P_SERVICE_HIST T_SUBSCRIPTION_DTL;
  P_ERR_CODE     NUMBER;
  P_ERR_MSG      VARCHAR2(32767);
BEGIN
  P_CO_CODE    := '&&1';
  P_ERR_CODE := NULL;
  P_ERR_MSG  := NULL;

  UNBILLED_RENTAL.GET_CURMONTH_SUBSCRIPTION(P_CO_CODE,
                                         P_SERVICE_HIST,
                                         P_ERR_CODE,
                                         P_ERR_MSG);
  COMMIT;
  DBMS_OUTPUT.put_line('==============================================================================');
	DBMS_OUTPUT.put_line('P_CO_CODE :' || P_CO_CODE);
  DBMS_OUTPUT.put_line('P_ERR_CODE:' || p_err_code);
  DBMS_OUTPUT.put_line('P_ERR_MSG :' || p_err_msg);
  DBMS_OUTPUT.put_line(CHR(10));

  IF p_err_code = 200 THEN
    DBMS_OUTPUT.put_line('CoID:' || P_SERVICE_HIST.CO_ID);
  
    DBMS_OUTPUT.put_line(CHR(10));
    DBMS_OUTPUT.put_line('ACCESSFEE:-');
    DBMS_OUTPUT.put_line('TMCODE  SPCODE  SNCODE  SHDES   ACCESSFE  PV_COMBI_ID OVW_AMT  OVW_PRD PresetAmt PresetPrd PSO_AccessFee');
    DBMS_OUTPUT.put_line('------  ------- ------- ------- --------- ----------- -------  ------- --------- --------- -------------');
  
    IF P_SERVICE_HIST.ACCESSFEE.COUNT > 0 THEN
      FOR i IN P_SERVICE_HIST.ACCESSFEE.FIRST .. P_SERVICE_HIST.ACCESSFEE.LAST LOOP
        DBMS_OUTPUT.put_line(RPAD(P_SERVICE_HIST.ACCESSFEE(i).tmcode,8) || 
                            RPAD(P_SERVICE_HIST.ACCESSFEE(i).spcode,8) ||
                            RPAD(P_SERVICE_HIST.ACCESSFEE(i).sncode,8) ||                     
                            RPAD(P_SERVICE_HIST.ACCESSFEE(i).shdes,8) ||
                            RPAD(P_SERVICE_HIST.ACCESSFEE(i).accessfee,10) ||                            
                            RPAD(P_SERVICE_HIST.ACCESSFEE(i).pv_combi_id,12) ||
                            RPAD(P_SERVICE_HIST.ACCESSFEE(i).OVW_RECUR_AMOUNT,10) ||
                            RPAD(P_SERVICE_HIST.ACCESSFEE(i).OVW_PERIOD_LENGTH,10) ||       
                            RPAD(P_SERVICE_HIST.ACCESSFEE(i).preset_charge,15) ||       
                            RPAD(P_SERVICE_HIST.ACCESSFEE(i).preset_period,15) ||
                            RPAD(P_SERVICE_HIST.ACCESSFEE(i).psovw_accessfee,15)
                    );       
      END LOOP;
    END IF;        

    DBMS_OUTPUT.put_line(CHR(10));
    DBMS_OUTPUT.put_line('MPULKPVB:-');
    DBMS_OUTPUT.put_line('SNCODE  PV_COMBI_ID VSCODE SET_ID  ACCESSFEE  DES');
    DBMS_OUTPUT.put_line('------  ----------- ------ ------- ---------- --------------------------- ');
  
    IF P_SERVICE_HIST.MPULKPVB.COUNT > 0 THEN
      FOR i IN P_SERVICE_HIST.MPULKPVB.FIRST .. P_SERVICE_HIST.MPULKPVB.LAST LOOP
        DBMS_OUTPUT.put_line(RPAD(P_SERVICE_HIST.MPULKPVB(i).sncode,8) || RPAD(P_SERVICE_HIST.MPULKPVB(i).pv_combi_id,12) ||
                            RPAD(P_SERVICE_HIST.MPULKPVB(i).vscode,8) ||                     
                            RPAD(P_SERVICE_HIST.MPULKPVB(i).set_id,8) ||
                            RPAD(P_SERVICE_HIST.MPULKPVB(i).accessfee,10) ||                            
                            RPAD(P_SERVICE_HIST.MPULKPVB(i).des,25) 
    );
      END LOOP;
    END IF;
                    
    DBMS_OUTPUT.put_line(CHR(10));
    DBMS_OUTPUT.put_line('CHANGE_HISTORY:-');
    DBMS_OUTPUT.put_line('CHANGE_DATE         TM/SN/SP/PARAM');
    DBMS_OUTPUT.put_line('------------------- ------------------------------------------------------');
  
    IF P_SERVICE_HIST.CHANGE_HIST.COUNT > 0 THEN
      FOR i IN P_SERVICE_HIST.CHANGE_HIST.FIRST .. P_SERVICE_HIST.CHANGE_HIST.LAST LOOP
        DBMS_OUTPUT.put_line(RPAD(TO_CHAR(P_SERVICE_HIST.CHANGE_HIST(i).CHANGE_DATE,'dd-mm-yyyy hh24:mi:ss'),19) || ' / ' ||
                             RPAD(nvl(P_SERVICE_HIST.CHANGE_HIST(i).TM_CHG,' '),5) || '/ ' ||
                             TRIM(P_SERVICE_HIST.CHANGE_HIST(i).SN_CHG) || ' / ' ||
                             TRIM(P_SERVICE_HIST.CHANGE_HIST(i).SP_CHG) || ' / ' ||
                             TRIM(P_SERVICE_HIST.CHANGE_HIST(i).PR_CHG) || ' / ' ||
														 TRIM(P_SERVICE_HIST.CHANGE_HIST(i).QT_CHG)
                             );
			END LOOP;
    END IF;

    DBMS_OUTPUT.put_line(CHR(10));
    DBMS_OUTPUT.put_line('UNCHANGE_HISTORY:-');
    DBMS_OUTPUT.put_line('CHANGE_DATE         TM/SN/SP/PARAM');
    DBMS_OUTPUT.put_line('------------------- ------------------------------------------------------');
  
    IF P_SERVICE_HIST.UNCHANGE_HIST.COUNT > 0 THEN
      FOR i IN P_SERVICE_HIST.UNCHANGE_HIST.FIRST .. P_SERVICE_HIST.UNCHANGE_HIST.LAST LOOP
        DBMS_OUTPUT.put_line(RPAD(TO_CHAR(P_SERVICE_HIST.UNCHANGE_HIST(i).CHANGE_DATE,'dd-mm-yyyy hh24:mi:ss'),19) || ' / ' ||
                             RPAD(nvl(P_SERVICE_HIST.UNCHANGE_HIST(i).TM_CHG,' '),5) || '/ ' ||
                             TRIM(P_SERVICE_HIST.UNCHANGE_HIST(i).SN_CHG) || ' / ' ||
                             TRIM(P_SERVICE_HIST.UNCHANGE_HIST(i).SP_CHG) || ' / ' ||
                             TRIM(P_SERVICE_HIST.UNCHANGE_HIST(i).PR_CHG) || ' / ' ||
														 TRIM(P_SERVICE_HIST.UNCHANGE_HIST(i).QT_CHG)
                             );
			END LOOP;
    END IF;

  ELSE
    DBMS_OUTPUT.put_line(CHR(10));
    DBMS_OUTPUT.put_line('Failure response from BSCS procedure!!!!!' ||
                         p_err_code || ' ' || p_err_MSG);
  END IF;
END;
/
exit

