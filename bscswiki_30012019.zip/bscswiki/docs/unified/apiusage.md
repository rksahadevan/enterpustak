# API Usage and Examples

Below are the rules before using any API in Unified Interface:

!!! Info "Rule of Thumb before using the API"

    a) What is the level of data you want from Inquiry

    -	Summary Level
    -	Detail Level
    -	Account Level
    -	Invoice Level

    b) What is the type of client?

    -	Online
    -	Batch
    -	IVR
    -	Thick client
    -	Thin client

    c) What is the expected response time required for the client?

    -	milliseconds
    -	seconds

    d) What is the nature of Inquiry?

    -	Bulk inquiry
    -	Individual inquiry
    -	Bulk Inquiry with pagination

API's are designed by considering all above aspects. API explorer  matrix will give details about API's

Every API call consists of three elements: the *entity*, *ActionName*, and *parameters*.

For example, consider a few commonly-used entities along with the supported actions and parameters:

|     Entity        |     Description                                        |     Actions                                                  |     Parameters     |
|-------------------|--------------------------------------------------------|--------------------------------------------------------------|--------------------|
|    Account        |    CBCM AccountId with/without billing Month           |    AsOfNowUsage<br>Summary<br>FUP_INFO<br>LastPaymentDetails    |                    |
|    Invoice        |    Invoice Number                                      |    AsOfNowUsage<br>Summary<br>FUP_INFO<br>LastPaymentDetails    |                    |
|    FUP            |    CBCM AccountId                                      |    FUP_INFO                                                  |                    |
|    AccountList    |    AccountId comma delimted                            |    AsOfNowUsage                                              |                    |

(For full, up-to-date details about specific entities and parameters, use the API Explorer)

## API Explorer

* AccountAPI

	* Unbilled

		AsOfNow<br>
		Summary<br>
		Detail<br>

	* Billed

		AsOfNow<br>
		Summary<br>
		Detail<br>

* InvoiceAPI<br>

	AsOfNow<br>
	Summary<br>
	Detail<br>

* FreeUnits API

	FUPINFO

* UnBilled Rentals API<br>

	AsOfNow

## API Examples

### SOAP UI

Given below list of sample requests for different procedures in Unified Bill Inquiry.  This can be referred for testing this API using SOAP UI

Unified Bill Inquiry URL for different environments listed in [SoapUI URLs](../../unified/apiendpoints#api-environments)

#### Header Info request

      <soapenv:Body>
          <onl:OnlineBillInquiryRequest>
             <app:ApplicationHeader>
                <app:TransactionID>63463487686242422</app:TransactionID>
                <app:RequestedSystem>DigitalApp</app:RequestedSystem>
                <app:RequestedDate>?</app:RequestedDate>
             </app:ApplicationHeader>
             <onl:DataHeader>
                <!--You have a CHOICE of the next 4 items at this level
               <onl:AccountID>716741354</onl:AccountID>-->
               <onl:AccountNumber>043469364</onl:AccountNumber>
                 <!--Optional:-->
                <onl:BillDate>122018</onl:BillDate>
                <onl:DetailsFlag>true</onl:DetailsFlag>
                <onl:CallDetailsFlag>false</onl:CallDetailsFlag>
                <!--Optional:-->
                <onl:IdentifierFlag>AsOfNowUsage </onl:IdentifierFlag>
                <!--Zero or more repetitions:-->
                <com:AdditionalInfo>
                   <com:Name>?</com:Name>
                   <com:Value>?</com:Value>
                </com:AdditionalInfo>
             </onl:DataHeader>
          </onl:OnlineBillInquiryRequest>
       </soapenv:Body>


#### Summary Info Request

    <soapenv:Body>
          <onl:OnlineBillInquiryRequest>
             <app:ApplicationHeader>
                <app:TransactionID>63463487686242422</app:TransactionID>
                <app:RequestedSystem>DigitalApp</app:RequestedSystem>
                <app:RequestedDate>?</app:RequestedDate>
             </app:ApplicationHeader>
             <onl:DataHeader>
                <!--You have a CHOICE of the next 4 items at this level
               <onl:AccountID>716741354</onl:AccountID>-->
               <onl:AccountNumber>043469364</onl:AccountNumber>
                 <!--Optional:-->
                <onl:BillDate>122018</onl:BillDate>
                <onl:DetailsFlag>true</onl:DetailsFlag>
                <onl:CallDetailsFlag>false</onl:CallDetailsFlag>
                <!--Optional:-->
                <onl:IdentifierFlag>AsOfNowUsage,Summary </onl:IdentifierFlag>
                <!--Zero or more repetitions:-->
                <com:AdditionalInfo>
                   <com:Name>?</com:Name>
                   <com:Value>?</com:Value>
                </com:AdditionalInfo>
             </onl:DataHeader>
          </onl:OnlineBillInquiryRequest>
       </soapenv:Body>

#### Details Info Request

    <soapenv:Body>
          <onl:OnlineBillInquiryRequest>
             <app:ApplicationHeader>
                <app:TransactionID>63463487686242422</app:TransactionID>
                <app:RequestedSystem>DigitalApp</app:RequestedSystem>
                <app:RequestedDate>?</app:RequestedDate>
             </app:ApplicationHeader>
             <onl:DataHeader>
                <!--You have a CHOICE of the next 4 items at this level
               <onl:AccountID>716741354</onl:AccountID>-->
               <onl:AccountNumber>043469364</onl:AccountNumber>
                 <!--Optional:-->
                <onl:BillDate>122018</onl:BillDate>
                <onl:DetailsFlag>true</onl:DetailsFlag>
                <onl:CallDetailsFlag>false</onl:CallDetailsFlag>
                <!--Optional:-->
                <onl:IdentifierFlag>AsOfNowUsage,Summary </onl:IdentifierFlag>
                <!--Zero or more repetitions:-->
                <com:AdditionalInfo>
                   <com:Name>?</com:Name>
                   <com:Value>?</com:Value>
                </com:AdditionalInfo>
             </onl:DataHeader>
          </onl:OnlineBillInquiryRequest>
       </soapenv:Body>

#### FUP Info Request

      <soapenv:Body>
          <onl:OnlineBillInquiryRequest>
             <app:ApplicationHeader>
                <app:TransactionID>63463487686242422</app:TransactionID>
                <app:RequestedSystem>CIM</app:RequestedSystem>
                <app:RequestedDate>?</app:RequestedDate>
             </app:ApplicationHeader>
             <onl:DataHeader>
                <!--You have a CHOICE of the next 4 items at this level
               <onl:AccountID>638910369</onl:AccountID>-->
               <onl:AccountNumber>065395034</onl:AccountNumber>
                 <!--Optional:-->
                <onl:BillDate>102018</onl:BillDate>
                <onl:DetailsFlag>false</onl:DetailsFlag>
                <onl:CallDetailsFlag>false</onl:CallDetailsFlag>
                <!--Optional:-->
                <onl:IdentifierFlag>FUP_INFO</onl:IdentifierFlag>
                <!--Zero or more repetitions:-->
                <com:AdditionalInfo>
                   <com:Name>FUPONLY</com:Name>
                   <com:Value>YES</com:Value>
                </com:AdditionalInfo>
             </onl:DataHeader>
          </onl:OnlineBillInquiryRequest>
       </soapenv:Body>

#### Unbilled Rental Request

       <soapenv:Body>
          <onl:OnlineBillInquiryRequest>
             <app:ApplicationHeader>
                <app:TransactionID>Test_702349562</app:TransactionID>
                <app:RequestedSystem>CRC</app:RequestedSystem>
                <!--Optional:-->
                <app:RetryLimit></app:RetryLimit>
                <!--Optional:-->
                <app:RequestedDate></app:RequestedDate>
             </app:ApplicationHeader>
             <onl:DataHeader>
                <!--You have a CHOICE of the next 4 items at this level-->
                <!--Optional:-->
                <onl:AccountID>702379931</onl:AccountID>

                <onl:BillDate>112017</onl:BillDate>
                <onl:DetailsFlag>false</onl:DetailsFlag>
                <onl:CallDetailsFlag>false</onl:CallDetailsFlag>
                <!--Optional:-->
             <onl:IdentifierFlag>AsOfNowUsage,UnbilledRentalsBSCS</onl:IdentifierFlag>
                <!--Zero or more repetitions:-->
                <com:AdditionalInfo>
                   <com:Name></com:Name>
                   <com:Value></com:Value>
                </com:AdditionalInfo>
             </onl:DataHeader>
          </onl:Online


### POSTMAN

  Some sample request/response for POSTMAN given below:

#### Unbilled Rental

    Production URL:
    https://bscs.etisalat.corp.ae/bscsrs/rest/ubService/unBilledRental?accountId=696570386

    Sample output:
    {
        "serviceList": [
            {
                "coId": 5713699,
                "tmcode": 44,
                "sncode": 16353,
                "spcode": 110,
                "paramDesc": null,
                "snDesc": "VOIPB",
                "status": "A",
                "valid_from_date": 1515559511000,
                "valid_till_date": null,
                "validFrom": "2018-01-10 08:45:11",
                "validTill": null,
                "quantity": 1,
                "accessFee": 100,
                "typeOfEvent": "SERVICE_CHANGE",
                "rowNum": 0,
                "pvCombiId": 0,
                "quantity_ind": "N",
                "presetOffsetOverride": false
            },
            {
                "coId": 5713699,
                "tmcode": 44,
                "sncode": 1097,
                "spcode": 105,
                "paramDesc": null,
                "snDesc": "TVC82",
                "status": null,
                "valid_from_date": 1462023173000,
                "valid_till_date": null,
                "validFrom": "2016-04-30 05:32:53",
                "validTill": null,
                "quantity": 1,
                "accessFee": 67.15,
                "typeOfEvent": "QUANTITY_CHANGE",
                "rowNum": 1,
                "pvCombiId": 0,
                "quantity_ind": "N",
                "presetOffsetOverride": true
            },
            {
                "coId": 5713699,
                "tmcode": 44,
                "sncode": 1257,
                "spcode": 93,
                "paramDesc": null,
                "snDesc": "USC05",
                "status": "A",
                "valid_from_date": 1359615302000,
                "valid_till_date": null,
                "validFrom": "2013-01-31 10:55:02",
                "validTill": null,
                "quantity": 1,
                "accessFee": 0,
                "typeOfEvent": "SERVICE_CHANGE",
                "rowNum": 3,
                "pvCombiId": 0,
                "quantity_ind": "N",
                "presetOffsetOverride": false
            },
            {
                "coId": 5713699,
                "tmcode": 44,
                "sncode": 1048,
                "spcode": 110,
                "paramDesc": null,
                "snDesc": "ENIS7",
                "status": "A",
                "valid_from_date": 1359615301000,
                "valid_till_date": null,
                "validFrom": "2013-01-31 10:55:01",
                "validTill": null,
                "quantity": 1,
                "accessFee": 0,
                "typeOfEvent": "SERVICE_CHANGE",
                "rowNum": 4,
                "pvCombiId": 0,
                "quantity_ind": "Y",
                "presetOffsetOverride": false
            },
            {
                "coId": 5713699,
                "tmcode": 44,
                "sncode": 924,
                "spcode": 93,
                "paramDesc": null,
                "snDesc": "LQCID",
                "status": "A",
                "valid_from_date": 1359615301000,
                "valid_till_date": null,
                "validFrom": "2013-01-31 10:55:01",
                "validTill": null,
                "quantity": 1,
                "accessFee": 0,
                "typeOfEvent": "SERVICE_CHANGE",
                "rowNum": 4,
                "pvCombiId": 0,
                "quantity_ind": "Y",
                "presetOffsetOverride": false
            },
            {
                "coId": 5713699,
                "tmcode": 44,
                "sncode": 1256,
                "spcode": 93,
                "paramDesc": null,
                "snDesc": "USC03",
                "status": "A",
                "valid_from_date": 1359615301000,
                "valid_till_date": null,
                "validFrom": "2013-01-31 10:55:01",
                "validTill": null,
                "quantity": 1,
               "accessFee": 0,
                "typeOfEvent": "SERVICE_CHANGE",
                "rowNum": 4,
                "pvCombiId": 0,
                "quantity_ind": "N",
                "presetOffsetOverride": false
            },
            {
                "coId": 5713699,
                "tmcode": 44,
                "sncode": 1080,
                "spcode": 110,
                "paramDesc": "Free 30MB",
                "snDesc": "ETPR1",
                "status": "A",
                "valid_from_date": 1359615300000,
                "valid_till_date": null,
                "validFrom": "2013-01-31 10:55:00",
                "validTill": null,
                "quantity": 1,
                "accessFee": 0,
                "typeOfEvent": "SERVICE_CHANGE",
                "rowNum": 5,
                "pvCombiId": 6907,
                "quantity_ind": "N",
                "presetOffsetOverride": false
            },
            {
                "coId": 5713699,
                "tmcode": 44,
                "sncode": 1683,
                "spcode": 93,
                "paramDesc": null,
                "snDesc": "LLRFI",
                "status": "A",
                "valid_from_date": 1359615300000,
                "valid_till_date": null,
                "validFrom": "2013-01-31 10:55:00",
                "validTill": null,
                "quantity": 1,
                "accessFee": 0,
                "typeOfEvent": "SERVICE_CHANGE",
                "rowNum": 5,
                "pvCombiId": 0,
                "quantity_ind": "Y",
                "presetOffsetOverride": false
            },
            {
                "coId": 5713699,
                "tmcode": 44,
                "sncode": 1038,
                "spcode": 110,
                "paramDesc": null,
                "snDesc": "ENI13",
                "status": "A",
                "valid_from_date": 1359615299000,
                "valid_till_date": null,
                "validFrom": "2013-01-31 10:54:59",
                "validTill": null,
                "quantity": 1,
                "accessFee": 0,
                "typeOfEvent": "SERVICE_CHANGE",
                "rowNum": 6,
                "pvCombiId": 0,
                "quantity_ind": "Y",
                "presetOffsetOverride": false
            },
            {
                "coId": 5713699,
                "tmcode": 44,
                "sncode": 1503,
                "spcode": 93,
                "paramDesc": "Free",
                "snDesc": "LOC01",
                "status": "A",
                "valid_from_date": 1359615299000,
                "valid_till_date": null,
                "validFrom": "2013-01-31 10:54:59",
                "validTill": null,
                "quantity": 1,
                "accessFee": 0,
                "typeOfEvent": "SERVICE_CHANGE",
                "rowNum": 6,
                "pvCombiId": 6915,
                "quantity_ind": "N",
                "presetOffsetOverride": false
            },
            {
                "coId": 5713699,
                "tmcode": 44,
                "sncode": 1258,
                "spcode": 93,
                "paramDesc": null,
                "snDesc": "USC07",
                "status": "A",
                "valid_from_date": 1359615299000,
                "valid_till_date": null,
                "validFrom": "2013-01-31 10:54:59",
                "validTill": null,
                "quantity": 1,
                "accessFee": 0,
                "typeOfEvent": "SERVICE_CHANGE",
                "rowNum": 6,
                "pvCombiId": 0,
                "quantity_ind": "N",
                "presetOffsetOverride": false
            },
            {
                "coId": 5713699,
                "tmcode": 44,
                "sncode": 1036,
                "spcode": 110,
                "paramDesc": null,
                "snDesc": "ENI11",
                "status": "A",
                "valid_from_date": 1359615298000,
                "valid_till_date": null,
                "validFrom": "2013-01-31 10:54:58",
                "validTill": null,
                "quantity": 1,
                "accessFee": 0,
                "typeOfEvent": "SERVICE_CHANGE",
                "rowNum": 7,
                "pvCombiId": 0,
                "quantity_ind": "Y",
                "presetOffsetOverride": false
            },
            {
                "coId": 5713699,
                "tmcode": 44,
                "sncode": 1071,
                "spcode": 110,
                "paramDesc": "Free",
                "snDesc": "ENIS1",
                "status": "A",
                "valid_from_date": 1359615298000,
                "valid_till_date": null,
                "validFrom": "2013-01-31 10:54:58",
                "validTill": null,
                "quantity": 1,
                "accessFee": 0,
                "typeOfEvent": "SERVICE_CHANGE",
                "rowNum": 7,
                "pvCombiId": 6905,
                "quantity_ind": "Y",
                "presetOffsetOverride": false
            },
            {
                "coId": 5713699,
                "tmcode": 44,
                "sncode": 1032,
                "spcode": 110,
                "paramDesc": null,
                "snDesc": "ELVM2",
                "status": "A",
                "valid_from_date": 1359615297000,
                "valid_till_date": null,
                "validFrom": "2013-01-31 10:54:57",
                "validTill": null,
                "quantity": 1,
                "accessFee": 0,
                "typeOfEvent": "SERVICE_CHANGE",
                "rowNum": 8,
                "pvCombiId": 0,
                "quantity_ind": "Y",
                "presetOffsetOverride": false
            },
            {
                "coId": 5713699,
                "tmcode": 44,
                "sncode": 1255,
                "spcode": 93,
                "paramDesc": null,
                "snDesc": "USC01",
                "status": "A",
                "valid_from_date": 1359615297000,
                "valid_till_date": null,
                "validFrom": "2013-01-31 10:54:57",
                "validTill": null,
                "quantity": 1,
                "accessFee": 0,
                "typeOfEvent": "SERVICE_CHANGE",
                "rowNum": 8,
                "pvCombiId": 0,
                "quantity_ind": "N",
                "presetOffsetOverride": false
            },
            {
                "coId": 5713699,
                "tmcode": 44,
                "sncode": 944,
                "spcode": 93,
                "paramDesc": null,
                "snDesc": "LLFCP",
                "status": "A",
                "valid_from_date": 1350536504000,
                "valid_till_date": null,
                "validFrom": "2012-10-18 09:01:44",
                "validTill": null,
                "quantity": 1,
                "accessFee": 0,
                "typeOfEvent": "SERVICE_CHANGE",
                "rowNum": 9,
                "pvCombiId": 0,
                "quantity_ind": "N",
                "presetOffsetOverride": false
            },
            {
                "coId": 5713699,
                "tmcode": 44,
                "sncode": 916,
                "spcode": 93,
                "paramDesc": null,
                "snDesc": "LLOCP",
                "status": "A",
                "valid_from_date": 1350536504000,
                "valid_till_date": null,
                "validFrom": "2012-10-18 09:01:44",
                "validTill": null,
                "quantity": 1,
                "accessFee": 20,
                "typeOfEvent": "SERVICE_CHANGE",
                "rowNum": 9,
                "pvCombiId": 0,
                "quantity_ind": "N",
                "presetOffsetOverride": false
            },
            {
                "coId": 5713699,
                "tmcode": 44,
                "sncode": 954,
                "spcode": 93,
                "paramDesc": null,
                "snDesc": "LLRAT",
                "status": "A",
                "valid_from_date": 1350536504000,
                "valid_till_date": null,
                "validFrom": "2012-10-18 09:01:44",
                "validTill": null,
                "quantity": 1,
                "accessFee": 0,
                "typeOfEvent": "SERVICE_CHANGE",
                "rowNum": 9,
                "pvCombiId": 0,
                "quantity_ind": "N",
                "presetOffsetOverride": false
            },
            {
                "coId": 5713699,
                "tmcode": 44,
                "sncode": 1086,
                "spcode": 105,
                "paramDesc": "1st price",
                "snDesc": "TVC74",
                "status": "A",
                "valid_from_date": 1312985942000,
                "valid_till_date": null,
                "validFrom": "2011-08-10 06:19:02",
                "validTill": null,
                "quantity": 1,
                "accessFee": 0,
                "typeOfEvent": "SERVICE_CHANGE",
                "rowNum": 10,
                "pvCombiId": 0,
                "quantity_ind": "N",
                "presetOffsetOverride": true
            },
            {
                "coId": 5713699,
                "tmcode": 44,
                "sncode": 1074,
                "spcode": 110,
                "paramDesc": "Standard",
                "snDesc": "ELMST",
                "status": "A",
                "valid_from_date": 1312985941000,
                "valid_till_date": null,
                "validFrom": "2011-08-10 06:19:01",
                "validTill": null,
                "quantity": 1,
                "accessFee": 0,
                "typeOfEvent": "SERVICE_CHANGE",
                "rowNum": 11,
                "pvCombiId": 0,
                "quantity_ind": "Y",
                "presetOffsetOverride": true
            },
            {
                "coId": 5713699,
                "tmcode": 44,
                "sncode": 945,
                "spcode": 99,
                "paramDesc": null,
                "snDesc": "LLF2F",
                "status": "A",
                "valid_from_date": 1312982932000,
                "valid_till_date": null,
                "validFrom": "2011-08-10 05:28:52",
                "validTill": null,
                "quantity": 1,
                "accessFee": 0,
                "typeOfEvent": "SERVICE_CHANGE",
                "rowNum": 12,
                "pvCombiId": 0,
                "quantity_ind": "N",
                "presetOffsetOverride": false
            }
        ],
        "errorMessage": "OK|5713699|24-01-2019 11.32.02.0201|24-01-2019 11.32.02.9104",
        "errorCode": 200,
        "totalAmount": 187.15,
        "accountId": 696570386,
        "prorate": false
    }

#### Mini Bill SMS

    Production URL:
    https://bscs.etisalat.corp.ae/bscsrs/rest/ubService/miniBillSMS?accountId=724618828&billingMonth=122018

    Sample Output:

    {
        "errorMessage": "OK|20-01-2019 10.38.50.5339|20-01-2019 10.38.50.5506|
        724618828|1644131304|122018|SMS|||01122018000000|31122018235959|
        01012019000000|9749757|9749757|||",
        "errorCode": 200,
        "accountId": 724618828,
        "openingBalance": 499.45,
        "rentalAmount": 198,
        "paymentAmount": 0,
        "adjustmentAmount": -436.45,
        "discountAmount": 0,
        "onetimeAmount": 0,
        "vatAmount": 24.05,
        "totalAmountDue": 565.09,
        "billingMonth": "122018",
        "dueDate": "2019-01-15 12:00:00",
        "fromDate": "2018-12-01 12:00:00",
        "toDate": "2018-12-31 12:00:00",
        "subscription": "Mobile services",
        "usageList": [
            {
                "smsUsageGroup": "Text Messages",
                "usageAmount": 0.54
            },
            {
                "smsUsageGroup": "Local Calls",
                "usageAmount": 150
            },
            {
                "smsUsageGroup": "International calls",
                "usageAmount": 192.5
            }
        ],
        "invoiceNumber": "INV1644131304"
    }

### Java Client Subs

  This will be added in next version.
