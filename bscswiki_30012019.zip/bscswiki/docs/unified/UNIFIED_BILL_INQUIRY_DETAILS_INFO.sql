/*
Usage:
a) Update below input values:
    P_ACCOUNT_ID: CBCM Account ID
    P_BILLDATE     : Billing Month in MMYYYY format 
b) Execute the script from TOAD or from SQL prompt 
*/
SET SERVEROUTPUT ON SIZE 99999
set linesize 200
column TRANSACTION_TYPE format a15
SET TIMING ON
SET VERIFY OFF
DECLARE 
  P_ACCOUNT_ID NUMBER;
  P_INVOICENUMBER NUMBER;
  P_BILLDATE VARCHAR2(32767);
  P_DETAILSFLAG VARCHAR2(32767);
  P_CALLDETAILSFLAG VARCHAR2(32767);
  P_REQUESTSYTEM VARCHAR2(32767);
  P_PARAMETER VARCHAR2(32767);
  P_PARAMETER_VALUE VARCHAR2(32767);
  P_TRANSACTION_DETAILS BILL_ENQUIRY.T_BSCS_UI_DETAILS;
  P_ERR_CODE NUMBER;
  P_ERR_MSG VARCHAR2(32767);
  L_COUNT NUMBER(10);
  L_HDPRINT CHAR(1);
  v_xml XMLTYPE;
BEGIN
  P_ACCOUNT_ID      := '702385343';
  P_BILLDATE := '012019'; --Bill Cycle Start Date in MMYYYY format  
  P_INVOICENUMBER   := NULL;
  P_DETAILSFLAG     := NULL;
  P_CALLDETAILSFLAG := NULL;
  P_REQUESTSYTEM    := NULL;   
  P_PARAMETER       := NULL;  
  P_PARAMETER_VALUE := NULL;  
  P_ERR_CODE := NULL;
  P_ERR_MSG  := NULL;

  BILL_ENQUIRY.UNIFIED_BILL_INQUIRY.DETAILS_INFO(P_ACCOUNT_ID,
                                             P_INVOICENUMBER,
                                             P_BILLDATE,
                                             P_DETAILSFLAG,
                                             P_CALLDETAILSFLAG,
                                             P_REQUESTSYTEM,
                                             P_PARAMETER,
                                             P_PARAMETER_VALUE,
                                             P_TRANSACTION_DETAILS,
                                             P_ERR_CODE,
                                             P_ERR_MSG);
  dbms_output.put_line(chr(10));        
  dbms_output.put_line('===============================================================================================================================');
  dbms_output.put_line('Input : AccountID:' || p_account_id || '|BillDate:' || P_BILLDATE || '|RequestSystem:' || P_REQUESTSYTEM || '|P_PARAMETER:' || P_PARAMETER || '|P_PARAMETER_VALUE:' || P_PARAMETER_VALUE || '|');
  dbms_output.put_line('P_ERR_CODE:' || p_err_code);
  dbms_output.put_line('P_ERR_MSG: ' || p_err_msg);
  dbms_output.put_line(chr(10));                           
  dbms_output.put_line('Result:-');
  
  IF p_err_code = 200 THEN
    dbms_output.put_line('AccountID     : ' || P_TRANSACTION_DETAILS.ACCOUNT_ID);
    dbms_output.put_line('InvoiceNumber : ' ||
                         P_TRANSACTION_DETAILS.INVOICE_NUMBER);
    dbms_output.put_line('CustomerIdList: ' ||
                         P_TRANSACTION_DETAILS.CUSTOMER_ID_LIST);

    dbms_output.put_line(chr(10));                         
    dbms_output.put_line(chr(10));                         
    dbms_output.put_line('Transactions:-');
    dbms_output.put_line('TransType   Date            Amount TransMode                ServiceCode FromDate   ToDate     ServiceDesc                                                                 PackageDesc');
    dbms_output.put_line('----------- ------------ --------- ------------------------ ----------- ---------- ---------- --------------------------------------------------------------------------- --------------------');
    
    IF P_TRANSACTION_DETAILS.ACCTTRANSACTIONLISTDETAILS.COUNT > 0 THEN
        FOR i IN P_TRANSACTION_DETAILS.ACCTTRANSACTIONLISTDETAILS.FIRST .. P_TRANSACTION_DETAILS.ACCTTRANSACTIONLISTDETAILS.LAST LOOP
        IF P_TRANSACTION_DETAILS.ACCTTRANSACTIONLISTDETAILS(i).TRANSACTION_TYPE <> 'TAX' THEN
          DBMS_OUTPUT.put_line(
          rpad(P_TRANSACTION_DETAILS.ACCTTRANSACTIONLISTDETAILS(i).TRANSACTION_TYPE,12)  ||
          to_char(P_TRANSACTION_DETAILS.ACCTTRANSACTIONLISTDETAILS(i).TRANSACTION_DATE,'dd-mm-yyyy') || '  ' ||
          to_char(P_TRANSACTION_DETAILS.ACCTTRANSACTIONLISTDETAILS(i).AMOUNT,'999990.00') || ' ' ||
          rpad(substr(nvl(P_TRANSACTION_DETAILS.ACCTTRANSACTIONLISTDETAILS(i).TRANSACTIONMODE,' '),1,25),25) || 
          rpad(substr(nvl(P_TRANSACTION_DETAILS.ACCTTRANSACTIONLISTDETAILS(i).SERVICECODE,' '),1,11),11) || ' ' ||
          rpad(nvl(to_char(P_TRANSACTION_DETAILS.ACCTTRANSACTIONLISTDETAILS(i).FROMDATE,'dd-mm-yyyy'), ' '), 11) || 
          rpad(nvl(to_char(P_TRANSACTION_DETAILS.ACCTTRANSACTIONLISTDETAILS(i).TODATE,'dd-mm-yyyy'), ' '), 11) ||
          rpad(substr(nvl(P_TRANSACTION_DETAILS.ACCTTRANSACTIONLISTDETAILS(i).SERVICEDESC,' '),1,75),75) || ' ' ||
          rpad(substr(nvl(P_TRANSACTION_DETAILS.ACCTTRANSACTIONLISTDETAILS(i).PACKAGEIDDESC,' '),1,20),20)      
          );
        END IF;
        END LOOP;
        
        L_HDPRINT := 'N';
        FOR i IN P_TRANSACTION_DETAILS.ACCTTRANSACTIONLISTDETAILS.FIRST .. P_TRANSACTION_DETAILS.ACCTTRANSACTIONLISTDETAILS.LAST LOOP
          IF P_TRANSACTION_DETAILS.ACCTTRANSACTIONLISTDETAILS(i).TRANSACTION_TYPE = 'TAX' THEN
          if L_HDPRINT = 'N' then
            dbms_output.put_line('TAX:-');
            dbms_output.put_line('TransType   Date            Amount  TaxAppliedChrg TaxRate  ServiceDesc');
            dbms_output.put_line('----------- ------------ ---------  -------------- -------- ------------------------------------------------');      
            L_HDPRINT := 'Y';
          end if;
          DBMS_OUTPUT.put_line(
          rpad(P_TRANSACTION_DETAILS.ACCTTRANSACTIONLISTDETAILS(i).TRANSACTION_TYPE,12)  ||
          to_char(P_TRANSACTION_DETAILS.ACCTTRANSACTIONLISTDETAILS(i).TRANSACTION_DATE,'dd-mm-yyyy') || '  ' ||
          to_char(P_TRANSACTION_DETAILS.ACCTTRANSACTIONLISTDETAILS(i).AMOUNT,'999990.00') || ' ' ||
          to_char(P_TRANSACTION_DETAILS.ACCTTRANSACTIONLISTDETAILS(i).TAXAPPLIEDCHARGE,'9999999990.00') || ' ' ||
          rpad(P_TRANSACTION_DETAILS.ACCTTRANSACTIONLISTDETAILS(i).TAXRATE,9) || ' ' ||
          rpad(substr(nvl(P_TRANSACTION_DETAILS.ACCTTRANSACTIONLISTDETAILS(i).SERVICEDESC,' '),1,75),75)       
          );
          END IF;
        END LOOP;
        
    ELSE
       dbms_output.put_line('<No transaction available>');
    END IF;
    
    dbms_output.put_line(chr(10));                         
    dbms_output.put_line('Usage Transactions:-');
    dbms_output.put_line('Main Group                                                  Sub Group                                                            Amount   ChargedUnits     ChargdType Description');
    dbms_output.put_line('----------------------------------------------------------- ------------------------------------------------------- ----------- -------------- -------------- ---------------------------------------');
    
    IF P_TRANSACTION_DETAILS.ACCTUSGSUMRYLISTDETAILS.COUNT > 0 THEN
    FOR i IN P_TRANSACTION_DETAILS.ACCTUSGSUMRYLISTDETAILS.FIRST .. P_TRANSACTION_DETAILS.ACCTUSGSUMRYLISTDETAILS.LAST LOOP
      DBMS_OUTPUT.put_line(
      rpad(substr(P_TRANSACTION_DETAILS.ACCTUSGSUMRYLISTDETAILS(i).MAINGROUP_NAME,1,60), 60) ||
      rpad(substr(P_TRANSACTION_DETAILS.ACCTUSGSUMRYLISTDETAILS(i).SUBGROUP_NAME,1,60),60) || '     ' ||      
      to_char(P_TRANSACTION_DETAILS.ACCTUSGSUMRYLISTDETAILS(i).AMOUNT, '999990.00') || '     '  ||
      lpad(P_TRANSACTION_DETAILS.ACCTUSGSUMRYLISTDETAILS(i).CHARGEDUNITS,10) || '     ' ||      
      lpad(P_TRANSACTION_DETAILS.ACCTUSGSUMRYLISTDETAILS(i).CHARGEDTYPE,10)  || ' ' ||      
          rpad(substr(nvl(P_TRANSACTION_DETAILS.ACCTUSGSUMRYLISTDETAILS(i).DESCRIPTION,' '),1,40),40) 
      );
    END LOOP;
    ELSE
       dbms_output.put_line('<No usage available>');
    END IF;
    BEGIN
        v_xml := XMLTYPE(P_TRANSACTION_DETAILS);
        DBMS_OUTPUT.put_line(v_xml.getstringval);  
    EXCEPTION WHEN OTHERS THEN
        --XMLTYPE will not support lengthy outputs
        --This is to suppress ORA-19011: Character string buffer too small
        NULL;
    END;          
  ELSE
    dbms_output.put_line(chr(10));    
    dbms_output.put_line('Failure response from BSCS procedure!!!!!'); 
  END IF;
  dbms_output.put_line('===============================================================================================================================');
END;
/
exit

