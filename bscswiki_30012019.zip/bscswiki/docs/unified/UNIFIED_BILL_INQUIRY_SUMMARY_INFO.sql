/*
Usage:
a) Update below input values:
    P_ACCOUNT_ID: CBCM Account ID
    P_BILLDATE     : Billing Month in MMYYYY format 
b) Execute the script from TOAD or from SQL prompt 
*/

var ACCTSUMMARYINQDETAILS REFCURSOR;
SET TIMING ON
SET SERVEROUTPUT ON SIZE 9999
SET LINESIZE 250
COLUMN TotalTaxAmount FORMAT 999999990.00
DECLARE 
  P_ACCOUNT_ID NUMBER;
  P_INVOICENUMBER NUMBER;  
  P_BILLDATE VARCHAR2(32767);
  P_DETAILSFLAG VARCHAR2(32767);
  P_CALLDETAILSFLAG VARCHAR2(32767);
  P_REQUESTSYTEM VARCHAR2(32767);
  P_PARAMETER VARCHAR2(32767);
  P_PARAMETER_VALUE VARCHAR2(32767);
  P_ERR_CODE NUMBER;
  P_ERR_MSG VARCHAR2(32767);

BEGIN 
  P_ACCOUNT_ID := '702385343'; --CBCM Account ID
  P_BILLDATE := '012019'; --Bill Cycle Start Date in MMYYYY format
  P_INVOICENUMBER := NULL;  
  P_DETAILSFLAG := NULL;
  P_CALLDETAILSFLAG := NULL;
  P_REQUESTSYTEM := NULL;
  P_PARAMETER := NULL;
  P_PARAMETER_VALUE := NULL;
  P_ERR_CODE := NULL;
  P_ERR_MSG := NULL;

  BILL_ENQUIRY.UNIFIED_BILL_INQUIRY.SUMMARY_INFO ( P_ACCOUNT_ID, P_INVOICENUMBER, P_BILLDATE, P_DETAILSFLAG, P_CALLDETAILSFLAG, P_REQUESTSYTEM, P_PARAMETER, P_PARAMETER_VALUE, :ACCTSUMMARYINQDETAILS, P_ERR_CODE, P_ERR_MSG );
  COMMIT; 
  dbms_output.put_line('Completed @ ' || to_char(sysdate,'dd-mm-yyyy hh24:mi:ss'));
  dbms_output.put_line(chr(10));
  dbms_output.put_line('P_ACCOUNT_ID    : ' || P_ACCOUNT_ID);
  dbms_output.put_line('P_BILLDATE      : ' || P_BILLDATE);  
  dbms_output.put_line('RESPONSE CODE   : ' || p_ERR_CODE);
  dbms_output.put_line('RESPONSE MESSAGE: ' || P_ERR_MSG);  
  dbms_output.put_line('============================================================');
END;
/
print ACCTSUMMARYINQDETAILS;
exit
