/*
Script to test procedure output for EMCESU.T_RSSVASREP_TYPE

Input values:
	a) Input list of SNSHDES to be updated in P_SRVCLIST with comma delimiter (sample data given)
	b) P_BILLDATE to be set with Billing Start Date in YYYYMM format (sample data given)
*/
set timing on
SET SERVEROUTPUT ON SIZE 999999
SET LINESIZE 300
column SHDES format A15
column TotalRevenue format 999999999.00
column p_ERR_CODE format 99999999999
column P_ERR_MSG format A100
DECLARE 
  P_BILLDATE VARCHAR2(32767);
  P_SRVCLIST CLOB := '3P070,3P005,3P006';  ---Update list of SN SHDES with , delimiter
  
  SRVCREVENUE EMCESU.T_RSSVASREP_TYPE;
  P_ERR_CODE NUMBER;
  P_ERR_MSG VARCHAR2(32767);
  
BEGIN 
  P_BILLDATE := '201709';		--Update Billing Start Date in YYYYMM format (eg: 201611 for billing month 01-Nov-2016 to 30-Nov-2016
  P_ERR_CODE := NULL;
  P_ERR_MSG := NULL;

  EMCESU.CREATE_RSS_DATA ( P_BILLDATE, P_SRVCLIST, SRVCREVENUE, P_ERR_CODE, P_ERR_MSG );
  COMMIT; 
  dbms_output.put_line('RESPONSE CODE   : ' || p_ERR_CODE);
  dbms_output.put_line('RESPONSE MESSAGE: ' || P_ERR_MSG);	

  IF p_ERR_CODE = 200 THEN
  FOR i IN SRVCREVENUE.FIRST .. SRVCREVENUE.LAST LOOP 
   DBMS_OUTPUT.put_line (SRVCREVENUE(i).SHDES || ',' || to_char(SRVCREVENUE(i).AmountWithoutVAT,'999999.00') || ',' || to_char(SRVCREVENUE(i).AmountWithVAT,'999999.00')); 
  END LOOP; 
  END IF;  
 
END; 
/
exit

