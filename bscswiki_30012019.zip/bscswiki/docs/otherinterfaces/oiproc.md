Below are the list of Oracle stored procedure interfaces for bulk inquiry.

## Bulk Balance Inquiry

List of CBCM Account IDs will be input for the procedure and it returns below information for each account:

* Amount Due
* Billed Amount in last month
* Total Billed Amount

!!! Note "To avoid performance issues, maximum number of accounts in a request is limited to 500, and client has to chunk the request according to this"

!!! Info "Object Information"

    Procedure name: UNIFIED_BULK_INQUIRY.BULK_BALANCE_INQUIRY

    Procedure owner: EMCESU

    Clients: TIBCO

    This procedure implemented only in BSCS database and not available in ODS.

!!! Notes "Test Script"

    Follow below link to download the scripts to test the procedures in DB level:

    [Bulk Balance Inquiry](BULK_BALANCE_INQUIRY_Test.sql)

## Invoice Summary

This procedure implemented only in ODS, and it is a wrapping procedure for SUMMARY_INFO and provides full invoice history for an Account ID:

!!! Info "Object Information"

    Procedure name: INVOICE_SUMMARY

    Procedure owner: ODS

## Get Invoice Details

To provide invoice history details for a requested period.

Input will be Account ID, Billing Month From, and Billing Month to

Below attributes providing in the response:

* Invoice Number
* Invoice Date
* Invoice Amount
* Invoice Open Amount

!!! Info "Object Information"

    Procedure name: GET_INVOICE_DETAILS

    Procedure owner: EMCESU

    This procedure implemented only in BSCS database and not available in ODS.

!!! Notes "Test Script"

    Follow below link to download the scripts to test the procedures in DB level:

    [Get Invoice Details](GET_INVOICE_DETAILS.sql)

## BSCS Usage Group Summary

A wrapping procedure that internally calling UNIFIED_BILL_INQUIRY.CALL_DETAILS and output will be grouped on CallDate, Service, and MainGroupName.

Procedure inputs:

* Account ID
* Start Date
* End Date

Below attributes providing in the response:

* Usage Date
* Service
* MainGroupName
* Total Call Duration

!!! Info "Object Information"

    Procedure name: BSCS_USAGE_GROUP_SUMMARY

    Procedure owner: BILL_ENQUIRY/ODS

## HRMS Rebate Info

This procedure provides summary/detail information for Staff rebate interface with HRMS System.

Procedure inputs:

* Account ID
* Billing Month

Below attributes providing in the response:

* Rebate Summary
* Rebate Service Details

!!! Info "Object Information"

    Procedure name: UNIFIED_BILL_INQUIRY.REBATES_INFO

    Procedure owner: BILL_ENQUIRY/ODS

    Clients: Sharepoint->TIBCO

## RSS Interface - Monthly revenue summary

To share service level revenue for requested services with RSS.  RSS application maintains the list of services relevant for revenue sharing.

Procedure inputs:

* Billing Month
* Service List

Procedure output:

* SHDES
* AmountWithoutVAT
* AmountWithVAT

!!! Info "Object Information"

    Procedure name: CREATE_RSS_DATA

    Procedure owner: EMCESU

    Clients: RSS (via RSSVAS user)

!!! Notes "Test Script"

    Follow below link to download the scripts to test the procedures in DB level:

    [Create RSS Data](CREATE_RSS_DATA_TestScript.sql)

## RSS Interface - ElifeTV Game Transactions

To share eLife TV Gaming service revenue with RSS Application

Procedure inputs:

* Billing Month
* Service List

Procedure response will be revenue details for requested Services along with other agreed information with RSS

!!! Info "Object Information"

    Procedure name: RSS_INTERFACE.GET_ELIFETV_GAME_TRANS

    Procedure owner: ET_SUPPORT

    Clients: RSS (via RSSVAS user)

!!! Notes "Test Script"

    Follow below link to download the scripts to test the procedures in DB level:

    [eLifeTV Gaming Transaction](RSS_GET_ELIFETV_GAME_TRANS_Test.sql)
