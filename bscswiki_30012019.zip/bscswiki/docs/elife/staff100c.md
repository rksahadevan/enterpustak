## eLife TV - My Etisalat Plan 100MBPS (CXO/HOD)

## CRM Package Structure

Package Code: MKTTP11004STFCXOHOD

|    Components                         |    Production RP    |    Amount    |    Comments                                            |
|---------------------------------------|---------------------|-------------:|--------------------------------------------------------|
|    Broadband   100 Mbps Speed         |                     |    0         |    This   is given by default and cannot be removed    |
|    Choice   Basic                     |    RP564671         |    0         |    This   is given by default and cannot be removed    |
|    Router                             |    RPDLINK868R24    |    22.5      |                                                        |
|    eLife   main set top box           |    RP636558         |              |    Recorder   - RP636539                               |
