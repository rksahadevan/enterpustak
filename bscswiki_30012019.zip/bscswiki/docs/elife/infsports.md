!!! Info "Notes"
    * No commitment option for AED 20/month extra; base plan service will be added accordingly
    * CRM Package Code: MKTP3P100MBINFSPORTS
    * BSCS TMCODE: RPEL3

## Package composition

|    Line item                                           |    CBCM RP Code      |    Amount    |    Promo     |      BSCS Service                           |
|--------------------------------------------------------|----------------------|-------------:|-------------:|---------------------------------------------|
|    BroadBand Speed                                     | RPTPINFSPRTSBB<br>RPTPINFSPRTSNCBB                     |    287.00    |              |    SPIPC_WWC02<br>SPIPN_WWC02 (AED307)   |
|    eLife ON                                            |    RP622732          |    30.00     |              |    SPE3S_WWE01                        |
|    On-Demand Unlimited Basic                           |    RP599609          |    39.00     |              |    SPE3S_WWE03                        |
|    On-Demand Unlimited Premium                         |    RPPREMVDPACKS     |    10.00     |              |    EL3TV_WWE12                        |
|    eLife Basic                                         |    RPINFINTEBASIC    |    30.00     |              |    EL3TV_TV333                        |
|    Starzplay                                           |    RPSTARZPLAY       |              |              |                                             |
|    eLife TV - SPORTS - Abu Dhabi   SPORTS              |    RP636656          |    14.00     |              |    SPE3S_WWE07                        |
|    Sports Extra                                        |   RPTPINFSPORTSEXTRA |    30.00     |              |    EL3TV_TV345                        |
|    beIN Full Package                                   |    RP636657          |    110.00    |              |    SPE3S_WWE06                        |
|    eLife Voice                                         |    RPINFVOICE        |    9.00      |              |    SPLAO_LLELV                        |
|    Wireless Telephone (Gigaset)                        |    RP636658          |    5.00      |    -5.00     |    SPE3V_WWC01                        |
|    STB - Recorder                                      |    RP636539          |    30.00     |    -30.00    |    STESV_ST001                        |
|    Router - Basic                                      |    RPDLINK803R24     |    10.00     |    -10.00    |    STESV_ST101                        |
|    Package Price                     |                      |    604.00    |              |                                             |
|    Discount                                            |                      |    -45.00    |              |                                             |
|    **Bundle Price**    |                      |    **559.00**    |              |                                             |
|    Price after 5% VAT                                  |                      |    585.45    |              |                                             |

## Sample Invoice

!!! info "Sample Invoice - Regular subscription"
    ![Sample Invoice](../img/invInfSports.PNG)

!!! info "Sample Invoice - With no commitment option"    
    ![Sample Invoice](../img/invInfSportsNC.PNG)
