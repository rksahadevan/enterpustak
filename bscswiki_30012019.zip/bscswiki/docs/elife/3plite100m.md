## eLife 3P Lite 100 Mbps – 12 Months contract

## CRM Package Structure

Package Code: MKTP3P100MBLITE

|    Components                                       |    Production RP    |    Amount     |    Comments                                                                                                                                                                                                                                                        |
|-----------------------------------------------------|---------------------|--------------:|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|    Broadband   100 Mbps Speed                       |    RP3PLITE100MB    |    694        |    This   component is added automatically while selecting the package, no need to   display in the screen for agent to select. If the screen is displaying the   charges for broadband separately, it should display the cost of      RP3PLITE100MB + RP636661    |
|    eLife Basic (HD TV Box) installment discount)    |    RP636661         |    25         |    This   component is added automatically at the backend, no need to display in the   screen for agent to select                                                                                                                                                  |
|    eLife   On                                       |    RP622732         |    30         |    This   is given by default and cannot be removed                                                                                                                                                                                                                |
|    Wireless   Phone                                 |    RP647057         |    10         |    RP647057-   Should be selected by default:   Should   have an option to choose from any of the below phones as well:   RPGIGAA220TRIO1   RPPANASONICPH1                                                                                                         |
|    Bundled   Router                                 |    RPDLINK868R12    |    45         |    RPDLINK868R12-   Should be selected by default:                                                                                                                                                                                                                 |
|    Bundle   Rental                                  |                     |    AED 749    |                                                                                                                                                                                                                                                                    |

## BSCS Package Structure

|  			 			Plan 			Monthly Rental-eLife Lite with 100Mbps (01/05/15 – 31/05/15) 		 |                                              |                |
|----------------------------------------------------------------------|----------------------------------------------|----------------|
|  			 			                         			Components 		                               |  			 			                            			Amount  (AED) 		 |  			 			Description 		 |
|  			 			eLife - Lite 			- 100Mbps speed 		                                      |  			 			719 		                                       |  			 			HardCoded 		   |
|  			 			eLife main 			set top box 		                                            |  			 			40 		                                        |  			 			HardCoded 		   |
|  			 			Router Model 			Name 		                                                 |  			 			xx 		                                        |  			 			SncodeDesc 		  |
|  			 			eLife On 		                                                          |  			 			30 		                                        |  			 			SncodeDesc 		  |
|  			 			Unlimited 			National Calls 		                                          |  			 			0 		                                         |  			 			HardCoded 		   |
|  			 			Wireless 			Phone 		                                                    |  			 			10 		                                        |  			 			SncodeDesc 		  |
|  			 			Total 			component Value 		                                             |  			 			749 		                                       |  			 			  			 		          |
|  			 			Bundle 			Rental 		                                                     |  			 			799 		                                       |  			 			  			 		          |

## StreamServ Presentation

|  			Offer 		          |  			Description 		                 |  			TMCdoe 		 |  			SPCode 		 |  			SnCode 		                          |  			Clubbed SN 		             |  			PARAM 		 |
|------------------|-------------------------------|----------|----------|-----------------------------------|--------------------------|---------|
|  			MKTP3P20MBLITE 		 |  			eLife Lite - 100 Mbps speed 		 |  			RPEL3 		  |  			E4LTH 		  |  			WWC09 		                           |  			RPEL3->SPE3S->WWE02 			  			 		 |  			  			 		    |
|  			MKTP3P20MBLITE 		 |  			eLife main set top box 		      |  			RPEL3 		  |  			STESP 		  |  			XT058/XT057 		                     |  			  			 		                     |  			  			 		    |
|  			MKTP3P20MBLITE 		 |  			Router Model Name 		           |  			RPEL3 		  |  			STESP 		  |  			XT096/XT097/ 			XT101/XT103/ 			XT106 		 |  			  			 		                     |  			  			 		    |
|  			MKTP3P20MBLITE 		 |  			eLife On 		                    |  			RPEL3 		  |  			SPE3S 		  |  			WWE01 		                           |  			  			 		                     |  			  			 		    |
|  			MKTP3P20MBLITE 		 |  			Wireless Phone 		              |  			RPEL3 		  |  			SPE3S 		  |  			WWC04/ 			WWC06/ WWC05 		             |  			  			 		                     |  			  			 		    |

!!! notes "Key points of Invoice package structure"
    * SNCODEs/Rateplans clubbed together for presenting package structure.  CRM have separate rate plans that needs to be merged in invoice presentation purpose.
