## eLife Lite 50 Mbps (eLife 2P Packages – Etisalat Area)

## CRM Package Structure

Package Code: MKTBSAELIFE2P50MB

|    Components                   |    Production RP    |    Amount    |    Comments                                                                                                                                                                                                                |
|---------------------------------|---------------------|-------------:|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|    Broadband   50 Mbps Speed    |    RP645284         |    569       |    This   is given by default and cannot be removed                                                                                                                                                                        |
|    Home   Router                |    RPDLINK803R12    |    20        |    RPDLINK803R12-   Should be selected by default:   Should   have an option to choose from any of the below routers as well - both on 12   month installment   RP12LINKSYS8500   (80 AED)   RP12DLINKDIR868   (50 AED)    |
|    Wireless   Phone             |    RP647057         |    10        |    RP647057-   Should be selected by default:   Should   have an option to choose from any of the below phones as well (if these are   open for sale):   RPGIGAA220TRIO1   RPPANASONICPH1                                  |
