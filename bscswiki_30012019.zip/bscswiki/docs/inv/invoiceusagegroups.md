# Invoice related Information

## Consumer Usage Groups

Below are the list of agreed Main Groups available in the invoice for Consumer segment to present usage information.

| MAINGROUP NAME                       | DESCRIPTION                                           |
|--------------------------------------|-------------------------------------------------------|
| Etisalat Value-added Service   Usage | Greetune                                              |
| Etisalat Value-added Service   Usage | Value Added Services                                  |
| Etisalat Value-added Service   Usage | Video-On Demand                                       |
| Etisalat Value-added Service   Usage | eLifeOn Subscription                                  |
| International Calls And   Usages     | International Calls                                   |
| International Calls And   Usages     | International SMS Roaming                             |
| International Calls And   Usages     | Outgoing Roaming Calls                                |
| International Roaming Usage          | Etisalat Misr Mobile Data Roaming                     |
| International Roaming Usage          | Incoming Video Calls                                  |
| International Roaming Usage          | Incoming Voice Calls                                  |
| International Roaming Usage          | International 3G Video                                |
| International Roaming Usage          | International Calls                                   |
| International Roaming Usage          | International SMS Roaming                             |
| International Roaming Usage          | Mobile Data Roaming                                   |
| International Roaming Usage          | Mobily Mobile Data Roaming                            |
| International Roaming Usage          | Outgoing Roaming Calls                                |
| International Roaming Usage          | Outgoing Text Messages                                |
| International Roaming Usage          | Outgoing Video Calls                                  |
| International Roaming Usage          | Outgoing Voice Calls                                  |
| International Roaming Usage          | Special daily data roaming pack                       |
| International Roaming Usage          | Unlimited daily data roaming pack                     |
| International Usage                  | International 3G Video                                |
| International Usage                  | International Balance Transfer                        |
| International Usage                  | International Calls                                   |
| International Usage                  | International Calls - Super Off Peak Plan             |
| International Usage                  | International Calls - Super Off Peak Plan -  ES / CPS |
| International Usage                  | International MMS                                     |
| International Usage                  | International Message Manager SMS                     |
| International Usage                  | International SMS                                     |
| International Usage                  | International Telex, Telegram Calls                   |
| International Usage                  | Telex, Telegram Calls                                 |
| Local Usage                          | Blackberry Usage                                      |
| Local Usage                          | CUG calls                                             |
| Local Usage                          | Calls To Land Line                                    |
| Local Usage                          | Calls To Mobile                                       |
| Local Usage                          | Calls To Special Number                               |
| Local Usage                          | Calls To Telephone                                    |
| Local Usage                          | Calls to Land Line                                    |
| Local Usage                          | Calls to Local Mobile                                 |
| Local Usage                          | Calls to Telephone                                    |
| Local Usage                          | Collected Call                                        |
| Local Usage                          | Data balance Transfer                                 |
| Local Usage                          | Dial N Surf Calls                                     |
| Local Usage                          | Directory Enquiry Calls                               |
| Local Usage                          | Etisalat Messenger SMS                                |
| Local Usage                          | Etisalat Messenger Sessions                           |
| Local Usage                          | Ewap Service                                          |
| Local Usage                          | International Calls                                   |
| Local Usage                          | Intra-Company Calls                                   |
| Local Usage                          | Local Message Manager SMS                             |
| Local Usage                          | Location Based Services                               |
| Local Usage                          | MMS Package 1 Push                                    |
| Local Usage                          | Mobile Data                                           |
| Local Usage                          | Multi Media Messages                                  |
| Local Usage                          | National Video calls to Telephone                     |
| Local Usage                          | Operator Calls                                        |
| Local Usage                          | Others                                                |
| Local Usage                          | Premium SMS Calls                                     |
| Local Usage                          | Service 900 Calls                                     |
| Local Usage                          | Telex, Telegram Calls                                 |
| Local Usage                          | Text Messages                                         |
| Local Usage                          | USSD Charges                                          |
| Local Usage                          | Video Calls                                           |
| Local Usage                          | Voice Mail Calls                                      |
| Local Usage                          | Voice SMS                                             |
| Local Usage                          | Voice SMS Retrieval                                   |
| Local Usage                          | Yaas Calls                                            |
| Local Usage                          | iZone Charges                                         |
| Mobile Data Services                 | 3G Data                                               |
| Mobile Data Services                 | Blackberry Usage                                      |
| Mobile Data Services                 | Etisalat Misr Mobile Data Roaming                     |
| Mobile Data Services                 | Ewap Service                                          |
| Mobile Data Services                 | Mobile Data Roaming                                   |
| Mobile Data Services                 | Mobily Mobile Data Roaming                            |
| OTHERS                               | OTHERS                                                |
| Other Usage Charges                  | 3G Data                                               |
| Other Usage Charges                  | 3G Video                                              |
| Other Usage Charges                  | Email2SMS                                             |
| Other Usage Charges                  | INTERNET Email to MMS                                 |
| Other Usage Charges                  | Internet DialUp                                       |
| Other Usage Charges                  | Local SMS                                             |
| Other Usage Charges                  | Out-Of-Bundle Data                                    |
| Other Usage Charges                  | Video-On Demand                                       |
| Play On Demand                       | Play On Demand                                        |
| Third party service usage            | Carrier Billing                                       |
| Third party service usage            | Mawaqif mParking                                      |
| Third party service usage            | Music                                                 |
| Third party service usage            | Premium SMS services                                  |
| Third party service usage            | Subscriptions and Downloads                           |
| Third party service usage            | Third Party Services                                  |
| Third party service usage            | mParking                                              |

[Click here](ConsumerUsageCategory.xls) to download in Excel format.

## Business Usage Groups

Below are the list of agreed Main Groups available in the invoice for Business segment to present usage information.

| MAINGROUP NAME                       | DESCRIPTION                                 |
|--------------------------------------|---------------------------------------------|
| Etisalat Value-added Service   Usage | eLifeOn Subscription                        |
| International Calls And   Usages     | IDD Calls                                   |
| International Calls And   Usages     | IDD Calls - Super Off Peak Plan             |
| International Calls And   Usages     | IDD Calls - Super Off Peak Plan -  ES / CPS |
| International Calls And   Usages     | Incoming Roaming Calls                      |
| International Calls And   Usages     | International 3G Video                      |
| International Calls And   Usages     | International 3G Video Roaming              |
| International Calls And   Usages     | International Calls - Super Off Peak Plan   |
| International Calls And   Usages     | International MMS                           |
| International Calls And   Usages     | International SMS                           |
| International Calls And   Usages     | International SMS Roaming                   |
| International Calls And   Usages     | International Telex, Telegram Calls         |
| International Calls And   Usages     | Outgoing Roaming Calls                      |
| International Calls And   Usages     | Telex, Telegram Calls                       |
| International Roaming Usage          | Outgoing Voice Calls                        |
| Mobile Data Services                 | 3G Data                                     |
| Mobile Data Services                 | 3G Video                                    |
| Mobile Data Services                 | Blackberry Usage                            |
| Mobile Data Services                 | Booster 1 GB Roaming for Postpaid           |
| Mobile Data Services                 | Collected Call                              |
| Mobile Data Services                 | Content Services                            |
| Mobile Data Services                 | Etisalat Messenger SMS                      |
| Mobile Data Services                 | Etisalat Messenger Sessions                 |
| Mobile Data Services                 | Etisalat Misr Mobile Data Roaming           |
| Mobile Data Services                 | Ewap Service                                |
| Mobile Data Services                 | International Message Manager SMS           |
| Mobile Data Services                 | Local Message Manager SMS                   |
| Mobile Data Services                 | Location Based Services                     |
| Mobile Data Services                 | MMS                                         |
| Mobile Data Services                 | MMS Package 1 Push                          |
| Mobile Data Services                 | Mobile Data Roaming                         |
| Mobile Data Services                 | Mobily Mobile Data Roaming                  |
| Mobile Data Services                 | Non Stop IDR 24 hours Pack for enterprises  |
| Mobile Data Services                 | Premium SMS Calls                           |
| Mobile Data Services                 | USSD Charges                                |
| Mobile Data Services                 | Voice SMS                                   |
| Mobile Data Services                 | Voice SMS Retrieval                         |
| Mobile Data Services                 | Yaas Calls                                  |
| Mobile Data Services                 | iZone Charges                               |
| National Calls And Usages            | CUG calls                                   |
| National Calls And Usages            | Calls To Mobile                             |
| National Calls And Usages            | Calls To Special Number                     |
| National Calls And Usages            | Calls To Telephone                          |
| National Calls And Usages            | Calls to Local Mobile                       |
| National Calls And Usages            | Calls to Telephone                          |
| National Calls And Usages            | Dial N Surf Calls                           |
| National Calls And Usages            | Directory Enquiry Calls                     |
| National Calls And Usages            | Greetune                                    |
| National Calls And Usages            | IDD Calls                                   |
| National Calls And Usages            | Intra-Company Calls                         |
| National Calls And Usages            | Local SMS                                   |
| National Calls And Usages            | National Video calls to Telephone           |
| National Calls And Usages            | Operator Calls                              |
| National Calls And Usages            | Others                                      |
| National Calls And Usages            | Service 900 Calls                           |
| National Calls And Usages            | Telex, Telegram Calls                       |
| National Calls And Usages            | Voice Mail Calls                            |
| OTHERS                               | OTHERS                                      |
| Other Usage Charges                  | 3G Data                                     |
| Other Usage Charges                  | 3G Video                                    |
| Other Usage Charges                  | INTERNET Email To SMS                       |
| Other Usage Charges                  | INTERNET Email to MMS                       |
| Other Usage Charges                  | Internet DialUp                             |
| Other Usage Charges                  | Local SMS                                   |
| Other Usage Charges                  | On Demand                                   |
| Other Usage Charges                  | Out-Of-Bundle Data                          |
| Play On Demand                       | Play On Demand                              |

[Click here](BusinessUsageCategory.xls) to download in Excel format.
