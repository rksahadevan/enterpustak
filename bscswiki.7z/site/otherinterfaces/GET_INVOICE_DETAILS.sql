/*
Test script to execute EMCESU.GET_INVOICE_DETAILS directly in database and verify BSCS output
Execute this script in TOAD by giving below 3 input values from TIBCO request
  P_ACCOUNT_ID 
  P_BILLINGMONTHFROM 
  P_BILLINGMONTHTILL 
*/
SET SERVEROUTPUT ON SIZE 99999
DECLARE 
  P_ACCOUNT_ID NUMBER;
  P_BILLINGMONTHFROM VARCHAR2(10);
  P_BILLINGMONTHTILL VARCHAR2(10);
  P_REQUESTSYTEM VARCHAR2(100);
  P_PARAMETER VARCHAR2(100);
  P_PARAMETER_VALUE VARCHAR2(100);
  INVOICEDETAILS emcesu.INVOICE_REC_TYPE;  
  P_ERR_CODE NUMBER;
  P_ERR_MSG VARCHAR2(2000);
  
BEGIN 
  P_ACCOUNT_ID := 702374352;        ---Change as per TIBCO request
  P_BILLINGMONTHFROM := '012013';   ---Change as per TIBCO request
  P_BILLINGMONTHTILL := '112017';   ---Change as per TIBCO request
  P_REQUESTSYTEM := NULL;
  P_PARAMETER := NULL;
  P_PARAMETER_VALUE := NULL;
  P_ERR_CODE := NULL;
  P_ERR_MSG := NULL;

  -- Call the procedure
  EMCESU.GET_INVOICE_DETAILS ( P_ACCOUNT_ID, P_BILLINGMONTHFROM, P_BILLINGMONTHTILL, P_REQUESTSYTEM, P_PARAMETER, P_PARAMETER_VALUE, INVOICEDETAILS, P_ERR_CODE, P_ERR_MSG );

  dbms_output.put_line('Input : ' || p_account_id || '|' || p_billingmonthfrom || '|' || p_billingmonthtill);
  dbms_output.put_line('Output: ' || p_err_code || '|' || p_err_msg);    
  
  IF p_err_code = 200 THEN
    FOR i IN invoicedetails.FIRST .. invoicedetails.LAST LOOP
      DBMS_OUTPUT.put_line(invoicedetails(i)
                           .InvoiceNumber || ',' || invoicedetails(i)
                           .InvoiceDate || ',' ||
                            to_char(invoicedetails(i).InvoiceAmount,
                                    '999999.00') || ',' ||
                            to_char(invoicedetails(i).InvoiceOpenAmount,
                                    '999999.00'));
    
    END LOOP;
  END IF;

end;

