/*
Date: 30-Jan-2018
Purpose: To provide eLife TV Gaming Service revenue for a billing month to RSS

Inputs:
p_BillDate  	Billing Month in "YYYYMM" format; Eg: 201711 for billing month 01-Nov-2017 to 30-Nov-2017
p_srvcList		List of GamingTV Services delimited by comma; pass fixed value as 'EGM01,EGM02'
*/
SET SERVEROUTPUT ON SIZE 99999
DECLARE
   P_BILLDATE        VARCHAR2 (32767);
   P_SRVCLIST        CLOB;
   TRANSACTIONLIST   ET_SUPPORT.T_BSCS_GAME_TRANS;
   P_RESP_CODE       NUMBER;
   P_RESP_MSG        VARCHAR2 (32767);
   v_indx            NUMBER;
BEGIN
   P_BILLDATE := '201712';
   P_SRVCLIST := 'EGM01,EGM02';
   TRANSACTIONLIST := NULL;
   P_RESP_CODE := NULL;
   P_RESP_MSG := NULL;

   ET_SUPPORT.RSS_INTERFACE.GET_ELIFETV_GAME_TRANS (P_BILLDATE,
                                                    P_SRVCLIST,
                                                    TRANSACTIONLIST,
                                                    P_RESP_CODE,
                                                    P_RESP_MSG);

   DBMS_OUTPUT.put_line (p_resp_code);
   DBMS_OUTPUT.put_line (p_resp_msg);

   DBMS_OUTPUT.put_line (
      'UniqueID  From      To        PackID         Amount Description');
   DBMS_OUTPUT.put_line('--------- --------- --------- ----------- --------- -------------------------------');

   FOR v_indx IN 1 .. transactionlist.COUNT
   LOOP
      DBMS_OUTPUT.put_line(   transactionlist (v_indx).customer_id
                           || ' '
                           || transactionlist (v_indx).rented_from
                           || ' '
                           || transactionlist (v_indx).rented_to
                           || ' '
                           || transactionlist (v_indx).package_id
                           || '      '
                           || TO_CHAR (
                                 transactionlist (v_indx).charged_amount,
                                 '999990.00')
                           || ' '
                           || transactionlist (v_indx).game_title);
   END LOOP;
END;
/
