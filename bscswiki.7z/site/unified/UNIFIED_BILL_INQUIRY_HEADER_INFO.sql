--Parameters: 
--a) CBCM Account ID
--b) Invoice Number: If not available, pass the value as 0
--c) Invoice Month in MMYYYY format.  If not available, pass the value as X

-- Eg:
-- sqlplus tibco_eai/Password@BSCSR2U2 @UNIFIED_BILL_INQUIRY_HEADER_INFO.sql 702351249 052017
-- sqlplus tibco_eai/Password@BSCSR2U2 @UNIFIED_BILL_INQUIRY_HEADER_INFO.sql 702351249 X 

var ACCTBALINQDETAILS REFCURSOR;
SET TIMING ON
SET SERVEROUTPUT ON SIZE 9999
SET LINESIZE 300
COLUMN ACCOUNTNAME FORMAT A40
COLUMN ACCOUNTSTATUS FORMAT A10
DECLARE 
  P_ACCOUNT_ID NUMBER; 
  P_INVOICE_NUMBER NUMBER;  
  P_BILLDATE VARCHAR2(32767);
  P_DETAILSFLAG VARCHAR2(32767);
  P_CALLDETAILSFLAG VARCHAR2(32767);
  P_REQUESTSYTEM VARCHAR2(32767);
  P_PARAMETER VARCHAR2(32767);
  P_PARAMETER_VALUE VARCHAR2(32767);
  P_ERR_CODE NUMBER;
  P_ERR_MSG VARCHAR2(32767);
BEGIN 
  dbms_output.put_line('Started @ ' || to_char(sysdate,'dd-mm-yyyy hh24:mi:ss'));
  P_ACCOUNT_ID := &&1;
  select DECODE('&&2','X', NULL, '&&2') into P_BILLDATE from dual;

  P_DETAILSFLAG := NULL;
  P_CALLDETAILSFLAG := NULL;
  P_REQUESTSYTEM := NULL;
  P_PARAMETER := NULL;
  P_PARAMETER_VALUE := NULL;
  
  P_ERR_CODE := NULL;
  P_ERR_MSG := NULL;

  BILL_ENQUIRY.UNIFIED_BILL_INQUIRY.HEADER_INFO ( P_ACCOUNT_ID, P_INVOICE_NUMBER, P_BILLDATE, P_DETAILSFLAG, P_CALLDETAILSFLAG, P_REQUESTSYTEM, P_PARAMETER, P_PARAMETER_VALUE, :ACCTBALINQDETAILS, P_ERR_CODE, P_ERR_MSG );
  COMMIT; 
  dbms_output.put_line('Completed @ ' || to_char(sysdate,'dd-mm-yyyy hh24:mi:ss'));
  dbms_output.put_line(chr(10));
  dbms_output.put_line('P_ACCOUNT_ID    : ' || P_ACCOUNT_ID);
  dbms_output.put_line('P_BILLDATE      : ' || P_BILLDATE);   
  dbms_output.put_line('RESPONSE CODE   : ' || p_ERR_CODE);
  dbms_output.put_line('RESPONSE MESSAGE: ' || P_ERR_MSG);
  dbms_output.put_line('============================================================');  
END;
/
print ACCTBALINQDETAILS;
exit
