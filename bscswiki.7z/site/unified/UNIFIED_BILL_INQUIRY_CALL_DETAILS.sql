/*
Description: Test script for UNIFIED_BILL_INQUIRY.CALL_DETAILS
Ver   : 2.0
Date  : 07-Jan-2018
*/
SET SERVEROUTPUT ON SIZE 99999
set linesize 200
SET VERIFY OFF
DECLARE 
  P_ACCOUNT_ID NUMBER;
  P_INVOICENUMBER NUMBER;
  P_BILLDATE VARCHAR2(32767);P_DETAILSFLAG VARCHAR2(32767);
  P_STARTDATE  VARCHAR2(10);
  P_ENDDATE  VARCHAR2(10);
  P_CALLDETAILSFLAG VARCHAR2(32767);
  P_REQUESTSYTEM VARCHAR2(32767);
  P_PARAMETER VARCHAR2(32767);
  P_PARAMETER_VALUE VARCHAR2(32767);
  P_PAGESIZE NUMBER;
  P_INDEX NUMBER;
  P_MAINGROUP VARCHAR2(32767);
  P_SUBGROUP VARCHAR2(32767);
  ACCTCALLDETAILS T_BSCS_UI_CALL_DETAILS;
  P_ERR_CODE NUMBER;
  P_ERR_MSG VARCHAR2(32767);
  v_xml XMLTYPE;
BEGIN 
  --Change input values as per test case
  P_ACCOUNT_ID        := '726822283';
  P_BILLDATE        := '012019'; --Format: MMYYYY
  P_PAGESIZE        := NULL; 
  P_INDEX            :=  NULL; 
  P_MAINGROUP        := NULL; 
  P_REQUESTSYTEM    := 'atgb2c';
  P_STARTDATE        := NULL; --Format: DDMMYYYY
  P_ENDDATE            := NULL; --Format: DDMMYYYY

  P_INVOICENUMBER   := NULL;
  P_DETAILSFLAG     := NULL;
  P_CALLDETAILSFLAG := NULL;
  P_STARTDATE := NULL; --Format: DDMMYYYY
  P_ENDDATE := NULL;     --Format: DDMMYYYY
  P_PARAMETER := NULL;
  P_PARAMETER_VALUE := NULL;
  P_SUBGROUP := NULL;
  P_ERR_CODE := NULL;
  P_ERR_MSG := NULL;

  UNIFIED_BILL_INQUIRY.CALL_DETAILS ( P_ACCOUNT_ID, P_INVOICENUMBER, P_BILLDATE, P_DETAILSFLAG, P_STARTDATE, P_ENDDATE, P_CALLDETAILSFLAG, P_REQUESTSYTEM, P_PARAMETER, P_PARAMETER_VALUE, P_PAGESIZE, P_INDEX, P_MAINGROUP, P_SUBGROUP, ACCTCALLDETAILS, P_ERR_CODE, P_ERR_MSG );
  COMMIT;

  dbms_output.put_line(chr(10));        
  dbms_output.put_line('================================================================================================================================');
  dbms_output.put_line('Input : AccountID:' || p_account_id || '|BillDate:' || P_BILLDATE || '|RequestSystem:' || P_REQUESTSYTEM || '|P_PAGESIZE:' || P_PAGESIZE || '|P_INDEX:' || P_INDEX || '|P_MAINGROUP:' || P_MAINGROUP || '|P_STARTDATE:' || P_STARTDATE || '|P_ENDDATE:' || P_ENDDATE);
  dbms_output.put_line('P_ERR_CODE:' || p_err_code);
  dbms_output.put_line('P_ERR_MSG: ' || p_err_msg);
  dbms_output.put_line(chr(10));                           
  dbms_output.put_line('Result:-');
  
  IF p_err_code = 200 THEN
    dbms_output.put_line('TOTAL_RECORDS :' || ACCTCALLDETAILS.TOTAL_RECORDS);
    dbms_output.put_line('LAST_PAGE_FLAG:' || ACCTCALLDETAILS.LAST_PAGE_FLAG);

    dbms_output.put_line(chr(10));                         
    dbms_output.put_line(chr(10));                         
    dbms_output.put_line('Call Details:-');
    dbms_output.put_line('Main Group            Sub Group             A-Party             B-Party             Call Date        Duration       Amount Service');
    dbms_output.put_line('--------------------- --------------------- ------------------- ------------------- ---------------- --------- ----------- -------');
   
    IF ACCTCALLDETAILS.CallDetailRecord.COUNT > 0 THEN
        FOR i IN ACCTCALLDETAILS.CallDetailRecord.FIRST .. ACCTCALLDETAILS.CallDetailRecord.LAST LOOP
          DBMS_OUTPUT.put_line(
          rpad(ACCTCALLDETAILS.CallDetailRecord(i).MAINGROUP_NAME,21)  || ' ' ||
          rpad(ACCTCALLDETAILS.CallDetailRecord(i).SUBGROUP_NAME,21)  || ' ' ||
          rpad(ACCTCALLDETAILS.CallDetailRecord(i).A_PARTY_NUMBER,20)  ||
          rpad(ACCTCALLDETAILS.CallDetailRecord(i).B_PARTY_NUMBER,20)  ||
          to_char(ACCTCALLDETAILS.CallDetailRecord(i).CALL_DATE,'dd-mm-yyyy HH24:MI') || ' ' ||
          rpad(ACCTCALLDETAILS.CallDetailRecord(i).CALL_DURATION,12)  || ' ' ||
          to_char(ACCTCALLDETAILS.CallDetailRecord(i).AMOUNT,'9990.00') || ' ' ||
          rpad(ACCTCALLDETAILS.CallDetailRecord(i).SERVICE,10)
          );
        END LOOP;
        
        BEGIN
            v_xml := XMLTYPE(ACCTCALLDETAILS);
            DBMS_OUTPUT.put_line(v_xml.getstringval); 
        EXCEPTION WHEN OTHERS THEN
            --XMLTYPE will not support lengthy outputs
            --This is to suppress ORA-19011: Character string buffer too small
            NULL;
        END;       
    ELSE
       dbms_output.put_line('<No calls available>');
    END IF;    
  ELSE
    dbms_output.put_line(chr(10));    
    dbms_output.put_line('Failure response from BSCS procedure!!!!!'); 
  END IF;
  dbms_output.put_line('================================================================================================================================');
  
END; 
/

