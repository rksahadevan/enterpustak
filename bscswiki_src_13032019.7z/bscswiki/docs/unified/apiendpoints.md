The API has two main interfaces along with the client Code that can be used to access the API.

### TIBCO Services

  TIBCO provides a number of different services to interact with the API through Webservices. The most common interface is SOAP over HTTP. Each user and system should have access to TIBCO services. These are the only interfaces directly exposed outside to etisalat.

!!! info "WSDL used by TIBCO for unified interface: UnifiedBillInquiry.wsdl"

### REST API
  These are REST GET API's accessed directly inside etisalat that requires JSON Web Token (JWT) token to access the services. These are light weight services that can be accessed from directly inside etisalat.

  Further details will be added in next version.

## Requested System
Each requested system have pre-defined timeouts in TIBCO and request will be timed out after this time period. Below Table have already configured requested systems.

## Time Outs
Each system have pre-defined time outs. Below tables mentions pre-configured timeouts.

## API examples
From the API examples menu, you can click on the Examples to find examples of API calls which are based on automated tests within the source code. You can also explore these examples on your Local PC with your own username and Passwords.

## API Examples for your extensions
If you are planning to add your own extensions. Please make sure to document and add examples based on the business scenarios.

### API Environments 	

Below are the URLs used in QA and Production Environments:

Unified Bill Inquiry

    UAT:
    http://tibcononprd.etisalat.corp.ae:9202/Middleware/UnifiedBillInquiry

    RC:
    http://tibcopreprd.etisalat.corp.ae:9202/Middleware/UnifiedBillInquiry

    Pre-Production:
    http://dx930:8202/Middleware/UnifiedBillInquiry

    For request samples, refer [SoapUI URL Request samples](../../unified/apiusage#soap-ui)

Unbilled Rental

    Note: Unbilled rentals will be for the full month without prorate the charges; proration logic not implemented in this API

    Production URL:
    https://bscs.etisalat.corp.ae/bscsrs/rest/ubService/unBilledRental?accountId=696570386

Mini Bill SMS

    Production URL:
    https://bscs.etisalat.corp.ae/bscsrs/rest/ubService/miniBillSMS?accountId=724618828&billingMonth=122018



!!! Warning "Deprecated Services"

    Below are the legacy web services used by CBCM and all these now migrated into Unified Interface; hence these services shouldn't be used.

    * GetInvoicedDuesController.wsdl
    * GetOnlineDuesController.wsdl
    * GetInvoicedCallsController.wsdl
    * GetOnlineCallsController.wsdl

## Changelog
All important changes made to the API are recorded in API changes.
