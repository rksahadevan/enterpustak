Unified Interface has a stable comprehensive API (Application Programming Interface) that can be used to access and manage inquiries in BSCS.  The API is the recommended way for any BSCS extension, CMS module, or external program to interact with BSCS.  This is applicable for B2B and B2C interfaces.  

Utilizing the API is superior to accessing core functions directly (e.g. calling raw SQL, or calling Views or Procedures) because the API offers a consistent interface to BSCS features. It is designed to function predictably with every new release so as to preserve backwards compatibility of the API for several versions of BSCS . If you decide to use other ways to collect data (like your own SQL statements), you risk running into future problems when changes to the schema and BSCS upgrades inevitably occur.

!!! Notes
    * Nonpayment responsible account's unbilled information guided against parent account
    * Rendering the customer data is based on Invoice template attached to the customer
    * Unbilled rentals will be for the full month without prorate the charges; proration logic not implemented in this API
    * Account status refers to the status of the account in Billing that doesn't have relation on CRC status    
    * Data product's interfaces provided from CBCM Billing; this is supported for Invoice inquiry

The best place to begin working with the API is your own test install of SOAP UI or POSTMAN, using the API explorer and the API parameter list. 

For help creating your own API custom calls, see *API Usage and Examples*.
