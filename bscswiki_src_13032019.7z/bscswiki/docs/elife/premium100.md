## eLife 4.0 Premium

## CRM Package Structure

Package Code: MKTP3P100MBULTIMATE

|    Components                         |    Production RP      |    Amount           |    Comments                                                                                                                                          |
|---------------------------------------|-----------------------|--------------------:|------------------------------------------------------------------------------------------------------------------------------------------------------|
|    Broadband 100 Mbps Speed           |    RP636666           |    392              |    This component is added automatically while selecting the package                                                                                 |
|    eLife Basic (HD TV Box)            |    RP636662           |    35               |    This component is added automatically at the backend                                                                                              |
|    Choice   Basic                     |    RP564671           |    30               |    This is given by default and cannot be removed                                                                                                    |
|    Video Pack                         |    RP599609           |    39               |    This is given by default and cannot be removed                                                                                                    |
|    eLife On                           |    RP622732           |    30               |    This is given by default and cannot be removed                                                                                                    |
|    Starzplay                          |    RPSTARZPLAY        |    20               |    This is given by default and cannot be removed                                                                                                    |
|    Premium Video Pack                 |    RPPREMVDPACKS      |    10               |    This is given by default and cannot be removed                                                                                                    |
|    OSN Ultimate Movies                |    RPALACART2         |    120              |    This is given by default and cannot be removed                                                                                                    |
|    OSN Ultimate Sports                |    RPALACART5         |    80               |    This is given by default and cannot be removed                                                                                                    |
|    OSN Get Started                    |    RPALACART6         |    79               |    This is given by default and cannot be removed                                                                                                    |
|    OSN Ultimate Entertainment         |    RPOSNULTIENT       |    33               |    This is given by default and cannot be removed                                                                                                    |
|    beIN Full Package                  |    RP636657           |    110              |    This is given by default and cannot be removed                                                                                                    |
|    eLife TV - SPORTS - AD SPORTS      |    RP636656           |    14               |    This is given by default and cannot be removed                                                                                                    |
|    Extreme Sports                     |    RPEXTREMSPORT      |    7                |    This is given by default and cannot be removed                                                                                                    |
|    eLife main set top box             |    RP636539           |    30               |    This should be the default recorder STB for eLife                                                                                                 |
|    Wireless Phone                     |    RP636658           |    5                |    RP636658 - Should be selected by default:Should have an option to   choose from any of the below phones as well:RPGIGAA220TRIO2,RPPANASONICPH2    |
|    Bundled Router                     |    RP24DLINKDIR868    |    22.5             |    RPDLINK868R24- Should be selected by default:Should have an option to   choose from any of the below routers as well:RP24LINKSYS8500              |
|    Total component Value              |                       |  1034               |                                                                                                                                                      |
|    Bundle Rental                      |                       |   999               |                                                                                                                                                      |

## StreamServ Presentation

|  			Description 		                     |  			TMCode 		 |  			SPCode 		 |  			Primary SnCode 		                                                            |  			Clubbed SNCode 		                                                                            |
|-----------------------------------|----------|----------|-----------------------------------------------------------------------------|---------------------------------------------------------------------------------------------|
|  			Broadband 100 Mbps Speed 		        |  			RPEL3 		  |  			E3PSP 		  |  			WWC02 		                                                                     |  			RPEL3->SPE3S-> WWE04 		                                                                      |
|  			eLife main set top box Recorder 		 |  			RPEL3 		  |  			SPE3S 		  |  			ELMST 		                                                                     |  			RPEL3->STESP->ST001 			RPEL3->STESP->ST002 			  			 		                                                |
|  			Router Model Name 		               |  			RPEL3 		  |  			STESP 		  |  			XT096/XT097/ST101/ST102/XT103 			ST114/XT101/ST110/ST130 			XT106/ 		              |  			  			 		                                                                                        |
|  			Bein Sports 		                     |  			RPEL3 		  |  			SPE3S 		  |  			WWE06 		                                                                     |  			  			 		                                                                                        |
|  			AD Sports 		                       |  			RPEL3 		  |  			SPE3S 		  |  			WWE07 		                                                                     |  			  			 		                                                                                        |
|  			Choice Basic  			 		                  |  			RPEL3 		  |  			EL3TV 		  |  			TVC75,TVC74,TVC73,TVC72, 			TV144,TV143,TV142,TV141, 			TV140,TV139,TV138,TV137 		 |  			PLSQL procedure to return I’st active TV 			service. If Ist one is Ceased take the next one. 		 |
|  			eLife TV - OSN - Premium HD 		     |  			RPEL3 		  |  			SPE3S 		  |  			WWE08 		                                                                     |  			  			 		                                                                                        |
|  			elife TV - Video Packs 		          |  			RPEL3 		  |  			SPE3S 		  |  			WWE03 		                                                                     |  			  			 		                                                                                        |
|  			Startz Play 		                     |  			RPEL3 		  |  			EL3TV 		  |  			WWE11 		                                                                     |  			  			 		                                                                                        |
|  			Premium VideoPacks 		              |  			RPEL3 		  |  			EL3TV 		  |  			WWE12 		                                                                     |  			  			 		                                                                                        |
|  			ExtremSports 		                    |  			RPEL3 		  |  			EL3TV 		  |  			WWE13 		                                                                     |  			  			 		                                                                                        |
|  			eLife On 		                        |  			RPEL3 		  |  			SPE3S 		  |  			WWE01 		                                                                     |  			  			 		                                                                                        |
|  			Wireless Phone 		                  |  			RPEL3 		  |  			SPE3S 		  |  			WWC01/ WWC07/ WWC08 		                                                       |  			  			 		                                                                                        |

!!! notes "Key points of Invoice package structure"
    * SNCODEs/Rateplans clubbed together for presenting package structure.  CRM have separate rate plans that needs to be merged in invoice presentation purpose.

## Sample Invoice

!!! info "Sample Invoice"
    ![Sample Invoice](../img/invPremium100MB.PNG)
