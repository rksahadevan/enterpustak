## eLife TV - My Etisalat Plan 10MBPS (Junior)

## CRM Package Structure

Package Code: MKTKMTP11002STAFG19B

|    Components                         |    Production RP    |    Amount    |    Comments                                            |
|---------------------------------------|---------------------|-------------:|--------------------------------------------------------|
|    Broadband   50 Mbps Speed          |    RP609290         |    0         |    This   is given by default and cannot be removed    |
|    Choice   Basic                     |    RP564671         |    0         |    This   is given by default and cannot be removed    |
|    Router                             |    RPDLINK803R24    |    10        |                                                        |
|    eLife   main set top box           |    RP636558         |    20        |    Recorder   - RP636539                               |
