!!! Info "Notes"
    * elife Entertainment package also known as Movies package
    * No commitment option for AED 20/month extra; base plan service will be added accordingly
    * CRM Package Code: MKTP3P100MBINFMOVWC
    * BSCS TMCODE: RPEL3

## Package composition

|    Line item                                           |    CBCM RP Code       |    Amount    |    Promo     |     BSCS Service                            |
|--------------------------------------------------------|-----------------------|-------------:|-------------:|---------------------------------------------|
|    BroadBand Speed                                     | RPTPINFMOVIESBB<br>RPTPINFMOVIESNCBB                      |    311.00    |              |    SPIEC_WWC02<br>SPIEN_WWC02 (AED331)    |
|    eLife ON                                            |    RP622732           |    30.00     |              |    SPE3S_WWE01                        |
|    On-Demand Unlimited Basic                           |    RP599609           |    39.00     |              |    SPE3S_WWE03                        |
|    On-Demand Unlimited Premium                         |    RPPREMVDPACKS      |    10.00     |              |    EL3TV_WWE12                        |
|    On-Demand Unlimited Ultimate                        |    RPINFODULTIMATE    |    0.00      |              |    EL3TV_TV339                        |
|    eLife Basic                                         |    RPINFINTEBASIC     |    30.00     |              |    EL3TV_TV333                        |
|    Starzplay                                           |    RPSTARZPLAY        |    20.00     |              |    EL3TV_WWE11                        |
|    OSN Ultimate Entertainment +   Movies               |    RP636696           |    150.00    |              |    SPE3S_WWE05                        |
|    eLife Voice                                         |    RPINFVOICE         |    9.00      |              |    SPLAO_LLELV                        |
|    Wireless Telephone (Gigaset)                        |    RP636658           |    5.00      |    -5.00     |    SPE3V_WWC01                        |
|    STB - Recorder                                      |    RP636539           |    30.00     |    -30.00    |    STESV_ST001                        |
|    Router - Basic                                      |    RPDLINK803R24      |    10.00     |    -10.00    |    STESV_ST101                        |
|    **Package Price**                   |                       |    644.00    |              |                                             |
|    **Discount**                                            |                       |    -45.00    |              |                                             |
|    **Bundle Price**                                        |                       |    **599.00**    |              |                                             |
|    **Price after 5% VAT**                                  |                       |    628.95    |              |                                             |


## Sample Invoice

!!! info "Sample Invoice - Regular subscription"
    ![Sample Invoice](../img/invInfEntertainment.PNG)

!!! info "Sample Invoice - With no commitment option"    
    ![Sample Invoice](../img/invInfEntertainmentNC.PNG)
