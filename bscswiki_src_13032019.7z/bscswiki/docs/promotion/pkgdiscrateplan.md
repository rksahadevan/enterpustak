Below list of promotions on packages which are activating/deactivating in BSCS by using the subscription of discounted rate plan along with package's Primary rate plan.

| Primary<br>RatePlan | Discounted<br>RatePlan | BSCS<br>Promo Code | Package Description                            |
|---------------------|------------------------|--------------------|------------------------------------------------|
| RP636664            | RP589673               | E3OSN              | eLife (Combo)                                  |
| RP636697            | RP1P4KSTB24RECORD      | E34KD2             | eLife (Combo)                                  |
| RP636697            | RP1P4KSTB24REGLR       | E34KD2             | eLife (Combo)                                  |
| RP636697            | RP4KSTB24RECORD        | E34KD2             | eLife (Combo)                                  |
| RP636697            | RP4KSTB24REGLR         | E34KD2             | eLife (Combo)                                  |
| RP636697            | RP552283               | E3N2R              | eLife (Combo)                                  |
| RP636697            | RP570589               | E3N2R              | eLife (Combo)                                  |
| RP636697            | RP570590               | E3N3R              | eLife (Combo)                                  |
| RP636697            | RP589690               | E3OSN              | eLife (Combo)                                  |
| RP636697            | RP602889               | E3N2R              | eLife (Combo)                                  |
| RP636697            | RP636539               | E3N3I              | eLife (Combo)                                  |
| RP636697            | RP636558               | E3N2I              | eLife (Combo)                                  |
| RP636697            | RPANAJUNDI             | EL3TVDIS           | eLife (Combo)                                  |
| RP636697            | RPCOMBOUPPROMO         | E3SCU              | eLife (Combo)                                  |
| RP636697            | RPENIGMA               | ENIGC              | eLife (Combo)                                  |
| RP636697            | RPOSNGOLD              | E3OSN              | eLife (Combo)                                  |
| RP636697            | RPOSNPLATINUM          | E3OSN              | eLife (Combo)                                  |
| RP636697            | RPOSNPREMIER           | E3OSN              | eLife (Combo)                                  |
| RP636697            | RPTVPLUS               | STBPLUS            | eLife (Combo)                                  |
| RP636664            | RP1P4KSTB24RECORD      | E34KD2             | eLife Entertainment                            |
| RP636664            | RP1P4KSTB24REGLR       | E34KD2             | eLife Entertainment                            |
| RP636664            | RP4KSTB24RECORD        | E34KD2             | eLife Entertainment                            |
| RP636664            | RP4KSTB24REGLR         | E34KD2             | eLife Entertainment                            |
| RP636664            | RP552283               | E3N2R              | eLife Entertainment                            |
| RP636664            | RP570589               | E3N2R              | eLife Entertainment                            |
| RP636664            | RP570590               | E3N3R              | eLife Entertainment                            |
| RP636664            | RP589690               | E3OSN              | eLife Entertainment                            |
| RP636664            | RP602889               | E3N2R              | eLife Entertainment                            |
| RP636664            | RP636539               | E3N3I              | eLife Entertainment                            |
| RP636664            | RP636558               | E3N2I              | eLife Entertainment                            |
| RP636664            | RPANAJUNDI             | EL3TVDIS           | eLife Entertainment                            |
| RP636664            | RPENIGMA               | ENIGE              | eLife Entertainment                            |
| RP636664            | RPOSNGOLD              | E3OSN              | eLife Entertainment                            |
| RP636664            | RPOSNPLATINUM          | E3OSN              | eLife Entertainment                            |
| RP636664            | RPOSNPREMIER           | E3OSN              | eLife Entertainment                            |
| RP636664            | RPTVPLUS               | STBPLUS            | eLife Entertainment                            |
| RP636663            | RP1P4KSTB24RECORD      | E34KD1             | eLife Family                                   |
| RP636663            | RP1P4KSTB24REGLR       | E34KD1             | eLife Family                                   |
| RP636663            | RP4KSTB24RECORD        | E34KD1             | eLife Family                                   |
| RP636663            | RP4KSTB24REGLR         | E34KD1             | eLife Family                                   |
| RP636663            | RP552283               | E3C2R              | eLife Family                                   |
| RP636663            | RP570589               | E3C2R              | eLife Family                                   |
| RP636663            | RP570590               | E3C2R              | eLife Family                                   |
| RP636663            | RP602889               | E3C2R              | eLife Family                                   |
| RP636663            | RP636539               | E3C2I              | eLife Family                                   |
| RP636663            | RP636558               | E3C2I              | eLife Family                                   |
| RP636663            | RPANAJUNDI             | EL3TVDIS           | eLife Family                                   |
| RP636663            | RPENIGMA               | ENIGF              | eLife Family                                   |
| RP636663            | RPTVPLUS               | STBPLUS            | eLife Family                                   |
| RP645263            | RP647057               | EL3WD              | eLife Lite 12 Mbps                             |
| RP645263            | RP647058               | E3C12              | eLife Lite 12 Mbps                             |
| RP645263            | RP647077               | E3C12              | eLife Lite 12 Mbps                             |
| RP645282            | RP2PELIFEFNF           | E2RC1              | eLife Lite 12 Mbps *                           |
| RP645282            | RP645279               | E3H1I              | eLife Lite 12 Mbps *                           |
| RP645282            | RP647057               | EL3WD              | eLife Lite 12 Mbps *                           |
| RP645282            | RPLITEPROMO            | E2RC1              | eLife Lite 12 Mbps *                           |
| RP645264            | RP647057               | EL3WD              | eLife Lite 25 Mbps                             |
| RP645264            | RP647058               | E3C12              | eLife Lite 25 Mbps                             |
| RP645264            | RP647077               | E3C12              | eLife Lite 25 Mbps                             |
| RP645264            | RPANAEMARATI           | ELL3P              | eLife Lite 25 Mbps                             |
| RP645284            | RP2PELIFEFNF           | E2RC3              | eLife Lite 25 Mbps                             |
| RP645284            | RPANAEMARATI           | ELL2P              | eLife Lite 25 Mbps                             |
| RP645284            | RPLITEPROMO            | E2RC3              | eLife Lite 25 Mbps                             |
| RP645283            | RP2PELIFEFNF           | E2RC2              | eLife Lite 25 Mbps *                           |
| RP645283            | RP645279               | E3H1I              | eLife Lite 25 Mbps *                           |
| RP645283            | RP647057               | EL3WD              | eLife Lite 25 Mbps *                           |
| RP645283            | RPANAEMARATI           | ELL2P              | eLife Lite 25 Mbps *                           |
| RP645283            | RPLITEPROMO            | E2RC2              | eLife Lite 25 Mbps *                           |
| RP645265            | RP647057               | EL3WD              | eLife Lite 50 Mbps                             |
| RP645265            | RP647058               | E3C12              | eLife Lite 50 Mbps                             |
| RP645265            | RP647077               | E3C12              | eLife Lite 50 Mbps                             |
| RP645265            | RPANAEMARATI           | ELL3P              | eLife Lite 50 Mbps                             |
| RP645284            | RP645279               | E3H1I              | eLife Lite 50 Mbps *                           |
| RP645284            | RP647057               | EL3WD              | eLife Lite 50 Mbps *                           |
| RP636666            | RP1P4KSTB24RECORD      | E34KD2             | eLife Premium                                  |
| RP636666            | RP1P4KSTB24REGLR       | E34KD2             | eLife Premium                                  |
| RP636666            | RP4KSTB24RECORD        | E34KD2             | eLife Premium                                  |
| RP636666            | RP4KSTB24REGLR         | E34KD2             | eLife Premium                                  |
| RP636666            | RP552283               | E3N2R              | eLife Premium                                  |
| RP636666            | RP570589               | E3N2R              | eLife Premium                                  |
| RP636666            | RP570590               | E3N3R              | eLife Premium                                  |
| RP636666            | RP589690               | E3OSN              | eLife Premium                                  |
| RP636666            | RP602889               | E3N2R              | eLife Premium                                  |
| RP636666            | RP636539               | E3N3I              | eLife Premium                                  |
| RP636666            | RP636558               | E3N2I              | eLife Premium                                  |
| RP636666            | RPANAJUNDI             | EL3TVDIS           | eLife Premium                                  |
| RP636666            | RPENIGMA               | ENIGP              | eLife Premium                                  |
| RP636666            | RPOSNPLATINUM          | E3OPP              | eLife Premium                                  |
| RP636666            | RPTVPLUS               | STBPLUS            | eLife Premium                                  |
| RP636697            | RP589673               | E3OSN              | eLife Premium                                  |
| RPTP500MB01         | RP1P4KSTB24RECORD      | E34KD2             | eLife Premium 500 Mbps                         |
| RPTP500MB01         | RP1P4KSTB24REGLR       | E34KD2             | eLife Premium 500 Mbps                         |
| RPTP500MB01         | RP24DLINKDIR868        | DLINK868B24M       | eLife Premium 500 Mbps                         |
| RPTP500MB01         | RP4KSTB24RECORD        | E34KD2             | eLife Premium 500 Mbps                         |
| RPTP500MB01         | RP4KSTB24REGLR         | E34KD2             | eLife Premium 500 Mbps                         |
| RPTP500MB01         | RP570589               | E3N2R              | eLife Premium 500 Mbps                         |
| RPTP500MB01         | RP570590               | E3N3R              | eLife Premium 500 Mbps                         |
| RPTP500MB01         | RP602889               | E3N2R              | eLife Premium 500 Mbps                         |
| RPTP500MB01         | RP636539               | E3N3I              | eLife Premium 500 Mbps                         |
| RPTP500MB01         | RP647259               | ULTRPTR            | eLife Premium 500 Mbps                         |
| RPTP500MB01         | RPTVPLUS               | STBPLUS            | eLife Premium 500 Mbps                         |
| RP636665            | RP1P4KSTB24RECORD      | E34KD2             | eLife Sports                                   |
| RP636665            | RP1P4KSTB24REGLR       | E34KD2             | eLife Sports                                   |
| RP636665            | RP4KSTB24RECORD        | E34KD2             | eLife Sports                                   |
| RP636665            | RP4KSTB24REGLR         | E34KD2             | eLife Sports                                   |
| RP636665            | RP552283               | E3N2R              | eLife Sports                                   |
| RP636665            | RP570589               | E3N2R              | eLife Sports                                   |
| RP636665            | RP570590               | E3N3R              | eLife Sports                                   |
| RP636665            | RP602889               | E3N2R              | eLife Sports                                   |
| RP636665            | RP636539               | E3N3I              | eLife Sports                                   |
| RP636665            | RP636558               | E3N2I              | eLife Sports                                   |
| RP636665            | RPANAJUNDI             | EL3TVDIS           | eLife Sports                                   |
| RP636665            | RPENIGMA               | ENIGS              | eLife Sports                                   |
| RP636665            | RPTVPLUS               | STBPLUS            | eLife Sports                                   |
| RPTP1GB01           | RP1P4KSTB24RECORD      | E34KD2             | eLife Ultimate 1Gbps                           |
| RPTP1GB01           | RP1P4KSTB24REGLR       | E34KD2             | eLife Ultimate 1Gbps                           |
| RPTP1GB01           | RP4KSTB24RECORD        | E34KD2             | eLife Ultimate 1Gbps                           |
| RPTP1GB01           | RP4KSTB24REGLR         | E34KD2             | eLife Ultimate 1Gbps                           |
| RPTP1GB01           | RP562822               | ULTSTBAO           | eLife Ultimate 1Gbps                           |
| RPTP1GB01           | RP570589               | E3N2R              | eLife Ultimate 1Gbps                           |
| RPTP1GB01           | RP570590               | E3N3R              | eLife Ultimate 1Gbps                           |
| RPTP1GB01           | RP570591               | ULTSTBAO           | eLife Ultimate 1Gbps                           |
| RPTP1GB01           | RP602889               | E3N2R              | eLife Ultimate 1Gbps                           |
| RPTP1GB01           | RP636539               | E3N3I              | eLife Ultimate 1Gbps                           |
| RPTP1GB01           | RP636560               | ULTSTBAO           | eLife Ultimate 1Gbps                           |
| RPTP1GB01           | RP636561               | ULTSTBAO           | eLife Ultimate 1Gbps                           |
| RPTP1GB01           | RP647259               | ULTRPTR            | eLife Ultimate 1Gbps                           |
| RPTP1GB01           | RPTVPLUS               | STBPLUS            | eLife Ultimate 1Gbps                           |
| RPTPINFMOVIESBB     | RP636539               | E3N3I              | eLife Unlimited Entertainment                  |
| RPTPINFMOVIESBB     | RP636558               | E3N2I              | eLife Unlimited Entertainment                  |
| RPTPINFMOVIESBB     | RPANAJUNDI             | EL3TVDIS           | eLife Unlimited Entertainment                  |
| RPTPINFMOVIESBB     | RPTECHNICLRRTR24M      | RGWPROMO24M        | eLife Unlimited Entertainment                  |
| RPTPINFMOVIESNCBB   | RP636539               | E3N3I              | eLife Unlimited Entertainment - No commitment  |
| RPTPINFMOVIESNCBB   | RP636558               | E3N2I              | eLife Unlimited Entertainment - No commitment  |
| RPTPINFMOVIESNCBB   | RPANAJUNDI             | EL3TVDIS           | eLife Unlimited Entertainment - No commitment  |
| RPTPINFMOVIESNCBB   | RPTECHNICLRRTR24M      | RGWPROMO24M        | eLife Unlimited Entertainment - No commitment  |
| RPTPINFPRM1GBB      | RP636539               | E3N3I              | eLife Unlimited Premium 1G                     |
| RPTPINFPRM1GBB      | RP636558               | E3N2I              | eLife Unlimited Premium 1G                     |
| RPTPINFPRM1GBB      | RPANAJUNDI             | EL3TVDIS           | eLife Unlimited Premium 1G                     |
| RPTPINFPRM1GBB      | RPTECHNICLRRTR24M      | RGWPROMO24M        | eLife Unlimited Premium 1G                     |
| RPTPINFPRM1GNCBB    | RP636539               | E3N3I              | eLife Unlimited Premium 1G - No commitment     |
| RPTPINFPRM1GNCBB    | RP636558               | E3N2I              | eLife Unlimited Premium 1G - No commitment     |
| RPTPINFPRM1GNCBB    | RPANAJUNDI             | EL3TVDIS           | eLife Unlimited Premium 1G - No commitment     |
| RPTPINFPRM1GNCBB    | RPTECHNICLRRTR24M      | RGWPROMO24M        | eLife Unlimited Premium 1G - No commitment     |
| RPTPINFPRM250BB     | RP636539               | E3N3I              | eLife Unlimited Premium 250                    |
| RPTPINFPRM250BB     | RP636558               | E3N2I              | eLife Unlimited Premium 250                    |
| RPTPINFPRM250BB     | RPANAJUNDI             | EL3TVDIS           | eLife Unlimited Premium 250                    |
| RPTPINFPRM250BB     | RPTECHNICLRRTR24M      | RGWPROMO24M        | eLife Unlimited Premium 250                    |
| RPTPINFSTRBB        | RP636539               | E3C2I              | eLife Unlimited Premium 250                    |
| RPTPINFSTRBB        | RP636558               | E3C2I              | eLife Unlimited Premium 250                    |
| RPTPINFSTRBB        | RPANAJUNDI             | EL3TVDIS           | eLife Unlimited Premium 250                    |
| RPTPINFSTRBB        | RPTECHNICLRRTR24M      | RGWPROMO24M        | eLife Unlimited Premium 250                    |
| RPTPINFPRM250NCBB   | RP636539               | E3N3I              | eLife Unlimited Premium 250 - No commitment    |
| RPTPINFPRM250NCBB   | RP636558               | E3N2I              | eLife Unlimited Premium 250 - No commitment    |
| RPTPINFPRM250NCBB   | RPANAJUNDI             | EL3TVDIS           | eLife Unlimited Premium 250 - No commitment    |
| RPTPINFPRM250NCBB   | RPTECHNICLRRTR24M      | RGWPROMO24M        | eLife Unlimited Premium 250 - No commitment    |
| RPTPINFSPRTSBB      | RP636539               | E3N3I              | eLife Unlimited Sports                         |
| RPTPINFSPRTSBB      | RP636558               | E3N2I              | eLife Unlimited Sports                         |
| RPTPINFSPRTSBB      | RPANAJUNDI             | EL3TVDIS           | eLife Unlimited Sports                         |
| RPTPINFSPRTSBB      | RPTECHNICLRRTR24M      | RGWPROMO24M        | eLife Unlimited Sports                         |
| RPTPINFSPRTSNCBB    | RP636539               | E3N3I              | eLife Unlimited Sports - No commitment         |
| RPTPINFSPRTSNCBB    | RP636558               | E3N2I              | eLife Unlimited Sports - No commitment         |
| RPTPINFSPRTSNCBB    | RPANAJUNDI             | EL3TVDIS           | eLife Unlimited Sports - No commitment         |
| RPTPINFSPRTSNCBB    | RPTECHNICLRRTR24M      | RGWPROMO24M        | eLife Unlimited Sports - No commitment         |
| RPTPINFSTRNCBB      | RP636539               | E3C2I              | eLife Unlimited Starter - No commitment        |
| RPTPINFSTRNCBB      | RP636558               | E3C2I              | eLife Unlimited Starter - No commitment        |
| RPTPINFSTRNCBB      | RPANAJUNDI             | EL3TVDIS           | eLife Unlimited Starter - No commitment        |
| RPTPINFSTRNCBB      | RPTECHNICLRRTR24M      | RGWPROMO24M        | eLife Unlimited Starter - No commitment        |
