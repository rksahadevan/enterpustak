Below list of promotions activating/deactivating in BSCS by using Indicator rate plan subscription in CRM.

| Indicator   Rateplan | Qualifier Rateplan/Parameter | Promo Code |
|----------------------|------------------------------|------------|
| RPOSNPROMO           | RPALACART3                   | EOMFU      |
| RPOSNPROMO           | RPALACART2                   | EOUFU      |
| RPOSNPROMO           | RPALACART4                   | EOPFU      |
| RPOSNPROMO           | RPALACART5                   | EOSFU      |
| RPOSNPROMO           | RPALCRPRM1                   | EOEFU      |
| RPRETENSTBRTR        | RP636561                     | ULTSTBAO   |
| RPRETENSTBRTR        | RP636560                     | RETSTBZP   |
| RPRETENSTBRTR        | RPDLINK850L24                | RETPNPO1   |
| RPRETENSTBRTR        | RP12DLINKDIR868A             | RETPNPO2   |
| RPRETENSTBRTR        | RP12LINKSYS8500A             | RETPNPO3   |
| RPRETENSTBRTR        | RP636659                     | RETWP      |
| RPRETENROUTR         | RPDLINK850L24                | RETPNPO1   |
| RPRETENROUTR         | RP12DLINKDIR868A             | RETPNPO2   |
| RPRETENROUTR         | RP12LINKSYS8500A             | RETPNPO3   |
| RP2PLITE100MB        | RPLITEPROMO                  | E2RC4      |
| RP3PPRIM01           | RP645280                     | RGW12      |
| RP3PPRIM02           | RP645280                     | RGW12      |
| RP3PPRIM03           | RP645280                     | RGW12      |
| RP3PPRIM04           | RP645280                     | RGW12      |
| RP3PPRIM05           | RP645280                     | RGW12      |
| RPRETENSTBRTR        | RP636659                     | RETWP      |
| RP2PELIFEFNF         | 12MB                         | E2RC1      |
| RP2PELIFEFNF         | 25MB                         | E2RC2      |
| RP2PELIFEFNF         | 50MB                         | E2RC3      |
| RP2PELIFEFNF         | 100MB                        | E2RC4      |
| RP2PELIFEFNF         | RP2PLITE100MB                | E2RC4      |
| RP2PLITE100MB        | RP645279                     | E3H1I      |
