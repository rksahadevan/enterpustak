## Invoice template mapping between CRM and BSCS

Below are the mapping between CRM and BSCS to assign Invoice Template in BSCS.

| Product<br>Group | Product<br>Code | Account<br>Category        | CBCM<br>Template        | BILL<br>Medium  |
|--------------------|--------------|-------------------------|---------------------|-------|
| M                  | GS           | Board Member            | MOBCONSUMER         | T0099 |
| M                  | GS           | Consumer Via Retailer   | MOBCONSUMER         | T0099 |
| M                  | GS           | Etisalat Staff          | MOBCONSUMER         | T0099 |
| M                  | GS           | Key Retailer            | MOBCONSUMER         | T0099 |
| M                  | GS           | Other VIP               | MOBCONSUMER         | T0099 |
| M                  | GS           | Residential             | MOBCONSUMER         | T0099 |
| M                  | GS           | Special Need Individual | MOBCONSUMER         | T0099 |
| M                  | GS           | Staff Rebate            | MOBCONSUMER         | T0099 |
| M                  | GS           | Visitors                | MOBCONSUMER         | T0099 |
| TP                 | 1P           | Board Member            | TRIPLEPLAYCONSUMER  | T0102 |
| TP                 | 1P           | Consumer Via Retailer   | TRIPLEPLAYCONSUMER  | T0102 |
| TP                 | 1P           | Etisalat Staff          | TRIPLEPLAYCONSUMER  | T0102 |
| TP                 | 1P           | Key Retailer            | TRIPLEPLAYCONSUMER  | T0102 |
| TP                 | 1P           | Other VIP               | TRIPLEPLAYCONSUMER  | T0102 |
| TP                 | 1P           | Residential             | TRIPLEPLAYCONSUMER  | T0102 |
| TP                 | 1P           | Special Need Individual | TRIPLEPLAYCONSUMER  | T0102 |
| TP                 | 1P           | Staff Rebate            | TRIPLEPLAYCONSUMER  | T0102 |
| TP                 | 1P           | Visitors                | TRIPLEPLAYCONSUMER  | T0102 |
| TP                 | 2P           | Board Member            | TRIPLEPLAYCONSUMER  | T0102 |
| TP                 | 2P           | Consumer Via Retailer   | TRIPLEPLAYCONSUMER  | T0102 |
| TP                 | 2P           | Etisalat Staff          | TRIPLEPLAYCONSUMER  | T0102 |
| TP                 | 2P           | Key Retailer            | TRIPLEPLAYCONSUMER  | T0102 |
| TP                 | 2P           | Other VIP               | TRIPLEPLAYCONSUMER  | T0102 |
| TP                 | 2P           | Residential             | TRIPLEPLAYCONSUMER  | T0102 |
| TP                 | 2P           | Special Need Individual | TRIPLEPLAYCONSUMER  | T0102 |
| TP                 | 2P           | Staff Rebate            | TRIPLEPLAYCONSUMER  | T0102 |
| TP                 | 2P           | Visitors                | TRIPLEPLAYCONSUMER  | T0102 |
| TP                 | 3P           | Board Member            | TRIPLEPLAYCONSUMER  | T0102 |
| TP                 | 3P           | Consumer Via Retailer   | TRIPLEPLAYCONSUMER  | T0102 |
| TP                 | 3P           | Etisalat Staff          | TRIPLEPLAYCONSUMER  | T0102 |
| TP                 | 3P           | Key Retailer            | TRIPLEPLAYCONSUMER  | T0102 |
| TP                 | 3P           | Other VIP               | TRIPLEPLAYCONSUMER  | T0102 |
| TP                 | 3P           | Residential             | TRIPLEPLAYCONSUMER  | T0102 |
| TP                 | 3P           | Special Need Individual | TRIPLEPLAYCONSUMER  | T0102 |
| TP                 | 3P           | Staff Rebate            | TRIPLEPLAYCONSUMER  | T0102 |
| TP                 | 3P           | Visitors                | TRIPLEPLAYCONSUMER  | T0102 |
| TP                 | 0P           | Board Member            | TRIPLEPLAYCONSUMER  | T0102 |
| TP                 | 0P           | Consumer Via Retailer   | TRIPLEPLAYCONSUMER  | T0102 |
| TP                 | 0P           | Etisalat Staff          | TRIPLEPLAYCONSUMER  | T0102 |
| TP                 | 0P           | Key Retailer            | TRIPLEPLAYCONSUMER  | T0102 |
| TP                 | 0P           | Other VIP               | TRIPLEPLAYCONSUMER  | T0102 |
| TP                 | 0P           | Residential             | TRIPLEPLAYCONSUMER  | T0102 |
| TP                 | 0P           | Special Need Individual | TRIPLEPLAYCONSUMER  | T0102 |
| TP                 | 0P           | Staff Rebate            | TRIPLEPLAYCONSUMER  | T0102 |
| TP                 | 0P           | Visitors                | TRIPLEPLAYCONSUMER  | T0102 |
| R                  | HI           | Board Member            | ECOMPSHAMILCONSUMER | T0103 |
| R                  | HI           | Consumer Via Retailer   | ECOMPSHAMILCONSUMER | T0103 |
| R                  | HI           | Etisalat Staff          | ECOMPSHAMILCONSUMER | T0103 |
| R                  | HI           | Key Retailer            | ECOMPSHAMILCONSUMER | T0103 |
| R                  | HI           | Other VIP               | ECOMPSHAMILCONSUMER | T0103 |
| R                  | HI           | PRESTIGE                | ECOMPSHAMILCONSUMER | T0103 |
| R                  | HI           | Residential             | ECOMPSHAMILCONSUMER | T0103 |
| R                  | HI           | Special Need Individual | ECOMPSHAMILCONSUMER | T0103 |
| R                  | HI           | Staff Rebate            | ECOMPSHAMILCONSUMER | T0103 |
| R                  | HI           | Visitors                | ECOMPSHAMILCONSUMER | T0103 |
| R                  | HI           | Sheiks and notables     | ECOMPSHAMILCONSUMER | T0103 |
| I                  | DP           | Board Member            | ECOMPSHAMILCONSUMER | T0103 |
| I                  | DP           | Consumer Via Retailer   | ECOMPSHAMILCONSUMER | T0103 |
| I                  | DP           | Etisalat Staff          | ECOMPSHAMILCONSUMER | T0103 |
| I                  | DP           | Key Retailer            | ECOMPSHAMILCONSUMER | T0103 |
| I                  | DP           | Other VIP               | ECOMPSHAMILCONSUMER | T0103 |
| I                  | DP           | PRESTIGE                | ECOMPSHAMILCONSUMER | T0103 |
| I                  | DP           | Residential             | ECOMPSHAMILCONSUMER | T0103 |
| I                  | DP           | Special Need Individual | ECOMPSHAMILCONSUMER | T0103 |
| I                  | DP           | Staff Rebate            | ECOMPSHAMILCONSUMER | T0103 |
| I                  | DP           | Visitors                | ECOMPSHAMILCONSUMER | T0103 |
| I                  | DP           | Sheiks and notables     | ECOMPSHAMILCONSUMER | T0103 |
| I                  | DV           | Board Member            | ECOMPSHAMILCONSUMER | T0103 |
| I                  | DV           | Consumer Via Retailer   | ECOMPSHAMILCONSUMER | T0103 |
| I                  | DV           | Etisalat Staff          | ECOMPSHAMILCONSUMER | T0103 |
| I                  | DV           | Key Retailer            | ECOMPSHAMILCONSUMER | T0103 |
| I                  | DV           | Other VIP               | ECOMPSHAMILCONSUMER | T0103 |
| I                  | DV           | PRESTIGE                | ECOMPSHAMILCONSUMER | T0103 |
| I                  | DV           | Residential             | ECOMPSHAMILCONSUMER | T0103 |
| I                  | DV           | Special Need Individual | ECOMPSHAMILCONSUMER | T0103 |
| I                  | DV           | Staff Rebate            | ECOMPSHAMILCONSUMER | T0103 |
| I                  | DV           | Visitors                | ECOMPSHAMILCONSUMER | T0103 |
| I                  | DV           | Sheiks and notables     | ECOMPSHAMILCONSUMER | T0103 |
| I                  | DO           | Board Member            | ECOMPSHAMILCONSUMER | T0103 |
| I                  | DO           | Consumer Via Retailer   | ECOMPSHAMILCONSUMER | T0103 |
| I                  | DO           | Etisalat Staff          | ECOMPSHAMILCONSUMER | T0103 |
| I                  | DO           | Key Retailer            | ECOMPSHAMILCONSUMER | T0103 |
| I                  | DO           | Other VIP               | ECOMPSHAMILCONSUMER | T0103 |
| I                  | DO           | PRESTIGE                | ECOMPSHAMILCONSUMER | T0103 |
| I                  | DO           | Residential             | ECOMPSHAMILCONSUMER | T0103 |
| I                  | DO           | Special Need Individual | ECOMPSHAMILCONSUMER | T0103 |
| I                  | DO           | Staff Rebate            | ECOMPSHAMILCONSUMER | T0103 |
| I                  | DO           | Visitors                | ECOMPSHAMILCONSUMER | T0103 |
| I                  | DO           | Sheiks and notables     | ECOMPSHAMILCONSUMER | T0103 |
| A                  | MA           | Board Member            | ECOMPSHAMILCONSUMER | T0103 |
| T                  | VO           | Board Member            | TELEPHONECONSUMER   | T0100 |
| A                  | MA           | Consumer Via Retailer   | ECOMPSHAMILCONSUMER | T0103 |
| T                  | VO           | Consumer Via Retailer   | TELEPHONECONSUMER   | T0100 |
| A                  | MA           | Etisalat Staff          | ECOMPSHAMILCONSUMER | T0103 |
| T                  | VO           | Etisalat Staff          | TELEPHONECONSUMER   | T0100 |
| A                  | MA           | Key Retailer            | ECOMPSHAMILCONSUMER | T0103 |
| T                  | VO           | Key Retailer            | TELEPHONECONSUMER   | T0100 |
| A                  | MA           | Other VIP               | ECOMPSHAMILCONSUMER | T0103 |
| T                  | VO           | Other VIP               | TELEPHONECONSUMER   | T0100 |
| A                  | MA           | PRESTIGE                | ECOMPSHAMILCONSUMER | T0103 |
| T                  | VO           | PRESTIGE                | TELEPHONECONSUMER   | T0100 |
| A                  | MA           | Residential             | ECOMPSHAMILCONSUMER | T0103 |
| T                  | VO           | Residential             | TELEPHONECONSUMER   | T0100 |
| A                  | MA           | Special Need Individual | ECOMPSHAMILCONSUMER | T0103 |
| T                  | VO           | Special Need Individual | TELEPHONECONSUMER   | T0100 |
| A                  | MA           | Staff Rebate            | ECOMPSHAMILCONSUMER | T0103 |
| T                  | VO           | Staff Rebate            | TELEPHONECONSUMER   | T0100 |
| A                  | MA           | Visitors                | ECOMPSHAMILCONSUMER | T0103 |
| T                  | VO           | Visitors                | TELEPHONECONSUMER   | T0100 |
| T                  | VO           | Sheiks and notables     | TELEPHONECONSUMER   | T0100 |
| M                  | GS           | PRESTIGE                | MOBPRESTIGE         | T0151 |
| A                  | MA           | Sheiks and notables     | ECOMPSHAMILCONSUMER | T0103 |
| TP                 | 1P           | PRESTIGE                | TRIPPLAYPRESTIGE    | T0152 |
| M                  | GS           | Sheiks and notables     | MOBCONSUMER         | T0099 |
| A                  | YM           | Board Member            | ECOMPSHAMILCONSUMER | T0103 |
| TP                 | 0P           | Sheiks and notables     | TRIPLEPLAYCONSUMER  | T0102 |
| TP                 | 2P           | PRESTIGE                | TRIPPLAYPRESTIGE    | T0152 |
| A                  | YM           | Consumer Via Retailer   | ECOMPSHAMILCONSUMER | T0103 |
| TP                 | 1P           | Sheiks and notables     | TRIPLEPLAYCONSUMER  | T0102 |
| TP                 | 3P           | PRESTIGE                | TRIPPLAYPRESTIGE    | T0152 |
| A                  | YM           | Etisalat Staff          | ECOMPSHAMILCONSUMER | T0103 |
| TP                 | 0P           | PRESTIGE                | TRIPPLAYPRESTIGE    | T0152 |
| TP                 | 2P           | Sheiks and notables     | TRIPLEPLAYCONSUMER  | T0102 |
| A                  | YM           | Key Retailer            | ECOMPSHAMILCONSUMER | T0103 |
| TP                 | 3P           | Sheiks and notables     | TRIPLEPLAYCONSUMER  | T0102 |
| A                  | YM           | Other VIP               | ECOMPSHAMILCONSUMER | T0103 |
| A                  | YM           | PRESTIGE                | ECOMPSHAMILCONSUMER | T0103 |
| A                  | YM           | Residential             | ECOMPSHAMILCONSUMER | T0103 |
| A                  | YM           | Special Need Individual | ECOMPSHAMILCONSUMER | T0103 |
| A                  | YM           | Staff Rebate            | ECOMPSHAMILCONSUMER | T0103 |
| A                  | YM           | Visitors                | ECOMPSHAMILCONSUMER | T0103 |
| A                  | YM           | Sheiks and notables     | ECOMPSHAMILCONSUMER | T0103 |

[Click here](TemplateMapping.xls) to download in Excel format.
